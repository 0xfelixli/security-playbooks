"""SDK-native vulnerability-report deduplication."""

from __future__ import annotations

import json
import logging
from typing import TYPE_CHECKING, Any

from agents.model_settings import ModelSettings
from agents.models.interface import ModelTracing

from talon.config import load_settings
from talon.config.models import (
    DEFAULT_MODEL_RETRY,
    TalonProvider,
    configure_sdk_model_defaults,
)
from talon.core.model_text import extract_text
from talon.report.state import get_global_report_state


if TYPE_CHECKING:
    from collections.abc import Awaitable, Callable

    # How the LLM is invoked, injected into judge_duplicate so the dedup logic
    # itself carries no provider/SDK knowledge (openai model, Claude Agent SDK, …).
    LlmCall = Callable[[str, str], Awaitable[str]]


logger = logging.getLogger(__name__)

DEDUPE_SYSTEM_PROMPT = """You are an expert vulnerability report deduplication judge.
Your task is to determine if a candidate vulnerability report describes the SAME vulnerability
as any existing report.

CRITICAL DEDUPLICATION RULES:

1. SAME VULNERABILITY means:
   - Same root cause (e.g., "missing input validation" not just "SQL injection")
   - Same affected component/endpoint/file (exact match or clear overlap)
   - Same exploitation method or attack vector
   - Would be fixed by the same code change/patch

2. NOT DUPLICATES if:
   - Different endpoints even with same vulnerability type (e.g., SQLi in /login vs /search)
   - Different parameters in same endpoint (e.g., XSS in 'name' vs 'comment' field)
   - Different root causes (e.g., stored XSS vs reflected XSS in same field)
   - **Different CWE / vulnerability class, even at the SAME location** — a single
     endpoint or function commonly carries multiple independent bugs (e.g. Mass
     Assignment CWE-915/CWE-916 vs IDOR / Broken Access Control CWE-639 on the same
     update view; Path Traversal CWE-22 vs Unrestricted Upload CWE-434 on the same
     handler). Different CWE ⇒ different root cause ⇒ different fix ⇒ NOT a duplicate.
     Do NOT collapse them into one report.
   - Different severity levels due to different impact
   - One is authenticated, other is unauthenticated

3. ARE DUPLICATES even if:
   - Titles are worded differently
   - Descriptions have different level of detail
   - PoC uses different payloads but exploits same issue
   - One report is more thorough than another
   - Minor variations in technical analysis

COMPARISON GUIDELINES:
- Focus on the technical root cause, not surface-level similarities
- Same vulnerability type (SQLi, XSS) doesn't mean duplicate - location matters
- Consider the fix: would fixing one also fix the other?
- When uncertain, lean towards NOT duplicate

FIELDS TO ANALYZE:
- title, description: General vulnerability info
- target, endpoint, method: Exact location of vulnerability
- cwe: Weakness class — a DECISIVE discriminator. Two reports with different CWEs are
  almost never duplicates even when the location matches; treat differing CWE as
  strong evidence of NOT-duplicate unless one is a clear parent/child of the other
  describing the identical flaw.
- technical_analysis: Root cause details
- poc_description: How it's exploited
- impact: What damage it can cause

Respond with a single JSON object and nothing else:

{
  "is_duplicate": true,
  "duplicate_id": "vuln-0001",
  "confidence": 0.95,
  "reason": "Both reports describe SQL injection in /api/login via the username parameter"
}

Or, if not a duplicate:

{
  "is_duplicate": false,
  "duplicate_id": "",
  "confidence": 0.90,
  "reason": "Different endpoints: candidate is /api/search, existing is /api/login"
}

Rules:
- ``is_duplicate`` is a boolean.
- ``duplicate_id`` is the exact id from existing reports, or "" if not a duplicate.
- ``confidence`` is a number between 0 and 1.
- ``reason`` is a specific explanation mentioning endpoint/parameter/root cause.
- Output ONLY the JSON object — no surrounding prose, no code fences."""


def _prepare_report_for_comparison(report: dict[str, Any]) -> dict[str, Any]:
    relevant_fields = [
        "id",
        "title",
        "description",
        "impact",
        "target",
        "technical_analysis",
        "poc_description",
        "endpoint",
        "method",
        "cwe",
    ]

    cleaned = {}
    for field in relevant_fields:
        if report.get(field):
            value = report[field]
            if isinstance(value, str) and len(value) > 8000:
                value = value[:8000] + "...[truncated]"
            cleaned[field] = value

    return cleaned


def _report_location_tokens(report: dict[str, Any]) -> set[str]:
    """Normalized location signals for a report: endpoint, target, and any
    ``code_locations`` file paths. Used only by the deterministic pre-filter."""
    tokens: set[str] = set()
    for key in ("endpoint", "target"):
        value = report.get(key)
        if isinstance(value, str) and value.strip():
            tokens.add(value.strip().lower())
    locations = report.get("code_locations")
    if isinstance(locations, list):
        for loc in locations:
            if not isinstance(loc, dict):
                continue
            file_path = loc.get("file") or loc.get("path")
            if isinstance(file_path, str) and file_path.strip():
                tokens.add(file_path.strip().lower())
    return tokens


def _normalized_cwe_number(report: dict[str, Any]) -> str | None:
    """Digits of a report's CWE (e.g. ``CWE-89`` -> ``89``), or None if absent."""
    value = report.get("cwe")
    if not isinstance(value, str) or not value.strip():
        return None
    digits = "".join(ch for ch in value if ch.isdigit())
    return digits or None


def _is_provably_distinct(candidate: dict[str, Any], existing: dict[str, Any]) -> bool:
    """True only when the two cannot be the same bug on deterministic signals alone:
    BOTH a different CWE AND disjoint locations.

    Deliberately conservative — a missing CWE on either side, equal CWEs, missing
    location info, or ANY location overlap all return False so the LLM still judges the
    pair. The pre-filter can therefore only *keep* a report for LLM review that might
    have been dropped; it never drops a plausible duplicate (worst case: one extra
    report kept, never a missed finding). Dropping on (different CWE AND disjoint
    location) is safe even for parent/child CWEs — those describe the same flaw at the
    same location and thus share a location token, so they are NOT ruled distinct here.
    Mirrors the DEDUPE_SYSTEM_PROMPT rules where a different CWE and a different
    endpoint are each decisive not-duplicate signals.
    """
    cand_cwe = _normalized_cwe_number(candidate)
    exist_cwe = _normalized_cwe_number(existing)
    if cand_cwe is None or exist_cwe is None or cand_cwe == exist_cwe:
        return False
    cand_loc = _report_location_tokens(candidate)
    exist_loc = _report_location_tokens(existing)
    if not cand_loc or not exist_loc:
        return False
    return not (cand_loc & exist_loc)


def prefilter_existing(
    candidate: dict[str, Any], existing_reports: list[dict[str, Any]]
) -> list[dict[str, Any]]:
    """Drop existing reports that are provably a different bug from the candidate, so
    only plausible duplicates reach the (expensive, per-report) LLM judge. An empty
    result lets the caller skip the LLM entirely and treat the candidate as
    not-a-duplicate. Conservative — see :func:`_is_provably_distinct`."""
    return [r for r in existing_reports if not _is_provably_distinct(candidate, r)]


def _parse_dedupe_response(content: str) -> dict[str, Any]:
    text = content.strip()
    if text.startswith("```"):
        text = text.strip("`")
        if text.lower().startswith("json"):
            text = text[4:]
        text = text.strip()
    start = text.find("{")
    end = text.rfind("}")
    if start == -1 or end == -1 or end <= start:
        raise ValueError(f"No JSON object found in dedupe response: {content[:500]}")
    parsed = json.loads(text[start : end + 1])

    duplicate_id = str(parsed.get("duplicate_id") or "")[:64]
    reason = str(parsed.get("reason") or "")[:500]
    try:
        confidence = float(parsed.get("confidence", 0.0))
    except (TypeError, ValueError):
        confidence = 0.0

    return {
        "is_duplicate": bool(parsed.get("is_duplicate", False)),
        "duplicate_id": duplicate_id,
        "confidence": confidence,
        "reason": reason,
    }


async def judge_duplicate(
    candidate: dict[str, Any],
    existing_reports: list[dict[str, Any]],
    llm_call: LlmCall,
) -> dict[str, Any]:
    """Provider-agnostic dedup judgement.

    Builds the comparison prompt, runs it via the injected ``llm_call``
    ``(system, user) -> text``, and parses the verdict. Carries no provider/SDK
    knowledge, so it is unit-testable with a fake ``llm_call`` and reusable across
    runtimes. Raises ``ValueError`` on unparseable model output — the caller
    (``check_duplicate``) catches it and degrades to not-duplicate.
    """
    if not existing_reports:
        return {
            "is_duplicate": False,
            "duplicate_id": "",
            "confidence": 1.0,
            "reason": "No existing reports to compare against",
        }

    candidate_cleaned = _prepare_report_for_comparison(candidate)
    existing_cleaned = [_prepare_report_for_comparison(r) for r in existing_reports]
    comparison_data = {"candidate": candidate_cleaned, "existing_reports": existing_cleaned}
    user_msg = (
        f"Compare this candidate vulnerability against existing reports:\n\n"
        f"{json.dumps(comparison_data, indent=2)}\n\n"
        f"Respond with ONLY the JSON object described in the system prompt."
    )

    content = await llm_call(DEDUPE_SYSTEM_PROMPT, user_msg)
    if not content:
        return {
            "is_duplicate": False,
            "duplicate_id": "",
            "confidence": 0.0,
            "reason": "Empty response from LLM",
        }
    return _parse_dedupe_response(content)


async def check_duplicate(
    candidate: dict[str, Any], existing_reports: list[dict[str, Any]]
) -> dict[str, Any]:
    """talon-runtime dedup: run ``judge_duplicate`` through the openai-agents /
    LiteLLM model (``TalonProvider``). Degrades to not-duplicate — never blocks a
    report — when ``TALON_LLM`` is unset or the model call/parse fails.
    """
    if not existing_reports:
        return {
            "is_duplicate": False,
            "duplicate_id": "",
            "confidence": 1.0,
            "reason": "No existing reports to compare against",
        }

    try:
        settings = load_settings()
        model_name = settings.llm.model
        if not model_name:
            return {
                "is_duplicate": False,
                "duplicate_id": "",
                "confidence": 0.0,
                "reason": "TALON_LLM not configured; skipping dedupe check",
            }

        configure_sdk_model_defaults(settings)
        resolved_model = model_name.strip()
        model = TalonProvider().get_model(resolved_model)

        async def _openai_llm_call(system: str, user: str) -> str:
            response = await model.get_response(
                system_instructions=system,
                input=user,
                model_settings=ModelSettings(retry=DEFAULT_MODEL_RETRY, include_usage=True),
                tools=[],
                output_schema=None,
                handoffs=[],
                tracing=ModelTracing.DISABLED,
                previous_response_id=None,
                conversation_id=None,
                prompt=None,
            )
            report_state = get_global_report_state()
            if report_state is not None:
                report_state.record_sdk_usage(
                    agent_id="dedupe",
                    agent_name="dedupe",
                    model=resolved_model,
                    usage=response.usage,
                )
            return extract_text(response)

        result = await judge_duplicate(candidate, existing_reports, _openai_llm_call)
        logger.info(
            "Deduplication check: is_duplicate=%s, confidence=%.2f, reason=%s",
            result["is_duplicate"],
            result["confidence"],
            result["reason"][:100],
        )
    except Exception as e:
        logger.exception("Error during vulnerability deduplication check")
        return {
            "is_duplicate": False,
            "duplicate_id": "",
            "confidence": 0.0,
            "reason": f"Deduplication check failed: {e}",
            "error": str(e),
        }
    else:
        return result

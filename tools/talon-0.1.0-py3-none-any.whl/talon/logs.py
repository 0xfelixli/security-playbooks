"""Per-scan logging setup.

Message conventions (two layers — follow them when adding log lines):

- **Structured events**: lowercase ``subject.event key=val ...`` for the high-frequency
  machine-greppable stream, e.g. ``tool.call``, ``tool.done dt=1.2s``, ``turn.start``,
  ``agent.register``, ``agent.status``, ``agent.send``, ``wait:``, ``coverage gate:``.
- **Phase milestones**: a capitalized natural sentence for one-off lifecycle marks,
  e.g. ``Starting Talon scan ...``, ``Creating docker session ...``, ``Talon scan done``.
  Trailing details still use bare ``key=val`` (no parentheses).

Never repeat the ``scan_id`` in the message — each scan writes its own
``talon_runs/<run_name>/talon.log``, so the run identity is already the file's path.
The per-agent label is carried as a column (via :class:`_TalonContextFilter`).

Reading ``talon.log``:

- ``grep ' <agent_id>'`` — one agent's lines (incl. SDK logs emitted inside its task)
- ``grep 'tool.call'`` — the action stream; ``tool.done`` has per-call ``dt=``
- ``grep 'agent.status'`` — lifecycle transitions of the whole agent tree
- ``grep 'coverage gate'`` — why ``finish_scan`` was blocked / allowed

The file handler writes plain single-line records (grep-friendly); the stderr handler
adds per-agent colors, lifecycle highlights, and terminal-width wrapping when attached
to a TTY. ``TALON_DEBUG=1`` raises stderr from ERROR to DEBUG; the file always gets
DEBUG for ``talon.*`` and WARNING for the SDK.
"""

from __future__ import annotations

import contextlib
import logging
import os
import re
import shutil
import sys
import warnings
import zlib
from contextvars import ContextVar
from logging.handlers import RotatingFileHandler
from pathlib import Path  # noqa: TC003  used at runtime by ``setup_scan_logging``
from typing import TYPE_CHECKING


if TYPE_CHECKING:
    from collections.abc import Callable


_AGENT_ID: ContextVar[str | None] = ContextVar("talon_agent_id", default=None)


# Width of the agent column: 8-char id + ':' + up to 32 chars of slugified name.
# Roomy enough for the descriptive names root hands out ("Source-Aware Whitebox
# Auditor" etc.) to show in full instead of being clipped mid-word.
_AGENT_NAME_SLUG_MAX = 32
_AGENT_COL_WIDTH = 41


def _agent_token(agent_id: str, name: str | None) -> str:
    """Render the per-line agent label as ``<id>:<name-slug>``.

    The id stays the leading, fixed-width portion so ``grep ' <id>'`` still isolates one
    agent's lines; the slugified, truncated name rides along for readability without
    cross-referencing the ``agent.register`` line.
    """
    if not name or name == agent_id:
        return agent_id
    slug = "_".join(name.split())[:_AGENT_NAME_SLUG_MAX]
    return f"{agent_id}:{slug}"


def set_agent_id(agent_id: str | None, name: str | None = None) -> None:
    """Set or clear the agent label seen on every log record from this point.

    ``None`` clears (renders as ``-``); with ``name`` the label becomes ``<id>:<name-slug>``
    (see :func:`_agent_token`). Mutations are isolated to the current asyncio task and tasks
    created from it, so each child agent's task carries its own label automatically.
    """
    _AGENT_ID.set(_agent_token(agent_id, name) if agent_id is not None else None)


class _TalonContextFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        record.agent_id = (_AGENT_ID.get() or "-").ljust(_AGENT_COL_WIDTH)
        return True


_FORMAT = "%(asctime)s.%(msecs)03d %(levelname)-7s %(agent_id)s %(name)s: %(message)s"
_DATEFMT = "%Y-%m-%d %H:%M:%S"


class _TalonFormatter(logging.Formatter):
    """Formatter that indents continuation lines to align with the logger-name column.

    Lines after a ``\\n`` (exception context, multiline tool output) are indented to the
    ``%(name)s`` column so they read as part of their parent line, not from column 0.
    """

    def format(self, record: logging.LogRecord) -> str:
        text = super().format(record)
        if "\n" not in text:
            return text
        lines = text.split("\n")
        # Locate the logger name in the first rendered line and use its column offset
        # as the indent for all continuation lines.
        first = lines[0]
        name_prefix = record.name + ": "
        idx = first.find(name_prefix)
        indent = " " * idx if idx >= 0 else ""
        return "\n".join([lines[0]] + [indent + ln for ln in lines[1:]])


# ---------------------------------------------------------------------------
# ANSI color support — stream (terminal) formatter only; file stays plain.
# ---------------------------------------------------------------------------

_RESET = "\033[0m"
_DIM = "\033[2m"
_GREEN = "\033[32m"
_RED = "\033[31m"
_YELLOW_BOLD = "\033[1;33m"

# Per-agent palette: blues/cyans/magentas only — red/green/yellow are all
# reserved for lifecycle events (crashed / completed / coverage-gate BLOCKED).
_AGENT_PALETTE = (
    "\033[34m",  # blue
    "\033[36m",  # cyan
    "\033[35m",  # magenta
    "\033[94m",  # bright blue
    "\033[96m",  # bright cyan
    "\033[95m",  # bright magenta
)

# Patterns marking the most important lifecycle events. Internal spaces use ``\s+``, not
# a literal space: colorizing runs after wrapping, so a keyword like "-> completed" may
# straddle a wrap boundary and ``\s+`` matches the newline+indent so the highlight still
# fires. The group is just an anchor — _color_span_to_end colors from the match start to
# the end of the text regardless of the group's extent.
_RE_COMPLETED = re.compile(r"(->\s+completed\b)")
_RE_CRASHED = re.compile(r"(->\s+crashed\b)")
_RE_BLOCKED = re.compile(r"(coverage gate:\s+BLOCKED\b)")


def _agent_color(token: str) -> str:
    """Return a stable ANSI color code for an agent token.

    crc32, not ``hash()``: PYTHONHASHSEED randomizes string hashes per process, which
    would recolor every agent across a ``--resume`` and break visual tracking.
    """
    return _AGENT_PALETTE[zlib.crc32(token.encode()) % len(_AGENT_PALETTE)]


def _wrap_long_lines(text: str, record: logging.LogRecord) -> str:
    """Break lines that exceed terminal width and indent continuations to the name column.

    Only called for TTY stream output; file handler keeps single long lines for grep.
    """
    try:
        cols = shutil.get_terminal_size((200, 40)).columns
    except Exception:  # noqa: BLE001
        return text

    lines = text.split("\n")
    if all(len(ln) <= cols for ln in lines):
        return text

    # Indent for continuation lines: align with the start of the logger name, but cap the
    # indent at half the terminal width. A deep agent/name column would otherwise starve
    # the content width on a narrow terminal, wrapping the message into a useless sliver;
    # the cap keeps at least half the row for the message and force-breaks only when even
    # that leaves no room.
    first = lines[0]
    name_tag = record.name + ": "
    idx = first.find(name_tag)
    indent = " " * min(max(idx, 0), cols // 2)

    out: list[str] = []
    for raw_ln in lines:
        current = raw_ln
        while len(current) > cols:
            # Search for a word boundary within the printable portion of the line,
            # skipping the leading indent so we never break inside it.
            content_start = len(indent) if current.startswith(indent) else 0
            cut = current.rfind(" ", content_start, cols)
            if cut <= content_start:
                cut = cols  # no space found — force-break at the column limit
            out.append(current[:cut])
            current = indent + current[cut:].lstrip(" ")
        out.append(current)

    return "\n".join(out)


def _color_span_to_end(text: str, pattern: re.Pattern[str], color: str) -> str:
    """Color from the pattern match through the end of the text, line by line.

    The lifecycle regexes stop at ``\\n``, so on a wrapped message the content after the
    match (every continuation line) still belongs to the same event and gets colored.
    Per-line codes (not one span) keep each terminal row self-contained.
    """
    match = pattern.search(text)
    if match is None:
        return text
    head, tail = text[: match.start(1)], text[match.start(1) :]
    return head + "\n".join(color + line + _RESET for line in tail.split("\n"))


def _colorize(text: str, record: logging.LogRecord) -> str:
    """Apply ANSI codes to a fully-formatted log line (or multiline block)."""
    # 1. Color the agent_id token (before the padding spaces).
    raw_agent = getattr(record, "agent_id", "").rstrip()
    if raw_agent and raw_agent != "-":
        color = _agent_color(raw_agent)
        text = text.replace(raw_agent, color + raw_agent + _RESET, 1)

    # 2. Dim the logger name so it reads as metadata, not signal.
    name_tag = record.name + ": "
    text = text.replace(name_tag, _DIM + name_tag + _RESET, 1)

    # 3. Highlight key lifecycle events wherever they appear in the text.
    text = _color_span_to_end(text, _RE_COMPLETED, _GREEN)
    text = _color_span_to_end(text, _RE_CRASHED, _RED)
    return _color_span_to_end(text, _RE_BLOCKED, _YELLOW_BOLD)


class _TalonColorFormatter(_TalonFormatter):
    """Colorized formatter for TTY stream output; inherits continuation indenting.

    Wraps long lines at the terminal width before colorizing so that continuation
    lines are indented to the logger-name column rather than appearing at column 0.
    """

    def format(self, record: logging.LogRecord) -> str:
        text = _wrap_long_lines(super().format(record), record)
        return _colorize(text, record)


# Third-party loggers that get noisy at DEBUG. Capped so the file isn't
# drowned in their internals when TALON_DEBUG=1.
_NOISY_LIBS: tuple[str, ...] = (
    "httpx",
    "httpcore",
    "urllib3",
    "litellm",
    "openai",
    "anthropic",
)


_HANDLER_TAG = "_talon_scan_handler"

# Rotation bounds for talon.log: deep scans plus repeated --resume append into the
# same file, which grows without bound otherwise. 50 MB x 3 backups.
_LOG_MAX_BYTES = 50 * 1024 * 1024
_LOG_BACKUP_COUNT = 3


# ``openai.agents`` is the openai-agents SDK's canonical logger root.
_TRACKED_ROOTS: tuple[str, ...] = ("talon", "openai.agents")


def _remove_tagged_handlers(target: logging.Logger) -> None:
    for handler in list(target.handlers):
        if getattr(handler, _HANDLER_TAG, False):
            target.removeHandler(handler)
            with contextlib.suppress(Exception):
                handler.flush()
                handler.close()


def configure_dependency_logging() -> None:
    """Quiet dependency logging/warnings that obscure Talon scan logs."""
    with contextlib.suppress(Exception):
        import litellm

        litellm_logging = litellm._logging
        litellm_logging._disable_debugging()  # type: ignore[no-untyped-call]

    logging.getLogger("asyncio").setLevel(logging.CRITICAL)
    logging.getLogger("asyncio").propagate = False
    warnings.filterwarnings("ignore", category=RuntimeWarning, module="asyncio")


def setup_scan_logging(run_dir: Path, *, debug: bool | None = None) -> Callable[[], None]:
    """Attach scan-scoped handlers; return a teardown callable.

    Args:
        run_dir: Per-scan output directory. ``{run_dir}/talon.log`` is created if missing
            and opened append-mode (so re-runs of the same scan_id concatenate cleanly).
        debug: When ``True``, stderr runs at DEBUG instead of ERROR. ``None`` (default)
            reads ``TALON_DEBUG`` (``1``/``true``/``yes``/``on`` enables debug).

    Returns:
        A no-arg callable that flushes/closes/removes the handlers this call attached.
        Idempotent and safe to call from a ``finally`` block.
    """
    configure_dependency_logging()

    if debug is None:
        debug = (os.environ.get("TALON_DEBUG") or "").strip().lower() in {
            "1",
            "true",
            "yes",
            "on",
        }

    run_dir.mkdir(parents=True, exist_ok=True)
    log_path = run_dir / "talon.log"

    plain_formatter = _TalonFormatter(_FORMAT, datefmt=_DATEFMT)
    color_formatter = _TalonColorFormatter(_FORMAT, datefmt=_DATEFMT)
    context_filter = _TalonContextFilter()

    file_handler = RotatingFileHandler(
        log_path,
        maxBytes=_LOG_MAX_BYTES,
        backupCount=_LOG_BACKUP_COUNT,
        encoding="utf-8",
    )
    file_handler.setLevel(logging.DEBUG)
    file_handler.setFormatter(plain_formatter)
    file_handler.addFilter(context_filter)
    setattr(file_handler, _HANDLER_TAG, True)

    stream_handler = logging.StreamHandler()
    stream_handler.setLevel(logging.DEBUG if debug else logging.ERROR)
    # Use colors only when stderr is a real terminal; pipe/redirect stays plain.
    stream_handler.setFormatter(color_formatter if sys.stderr.isatty() else plain_formatter)
    stream_handler.addFilter(context_filter)
    setattr(stream_handler, _HANDLER_TAG, True)

    tracked_loggers = [logging.getLogger(name) for name in _TRACKED_ROOTS]
    for tracked in tracked_loggers:
        # Idempotency: drop handlers a previous (not torn down) setup attached, so a
        # re-entrant setup — resume paths, crashed teardown — never double-prints.
        _remove_tagged_handlers(tracked)
        # talon.* always at DEBUG. SDK loggers (openai.agents etc.) stay at WARNING
        # regardless of TALON_DEBUG — their internals ("Resetting current trace",
        # "Calling LLM", tracing spans) are SDK plumbing noise, not talon signal.
        is_talon = tracked.name.startswith("talon")
        tracked.setLevel(logging.DEBUG if is_talon else logging.WARNING)
        tracked.addHandler(file_handler)
        tracked.addHandler(stream_handler)
        tracked.propagate = False

    for name in _NOISY_LIBS:
        logging.getLogger(name).setLevel(logging.WARNING)

    def _teardown() -> None:
        for tracked in tracked_loggers:
            _remove_tagged_handlers(tracked)

    return _teardown

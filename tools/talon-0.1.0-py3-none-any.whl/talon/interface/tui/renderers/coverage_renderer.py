"""Compact TUI renderers for the coverage/inventory tool family.

Without these, the coverage tools fall through to the default renderer, which
``str()``-dumps the whole result and floods the panel with raw manifest units.
These show a one-line summary (counts, deltas, high-density files) instead.
"""

import json
from typing import Any, ClassVar

from rich.text import Text
from textual.widgets import Static

from .base_renderer import BaseToolRenderer
from .registry import register_tool_renderer


_ICON = "🗂"
_ACCENT = "bold #38bdf8"


def _as_dict(result: Any) -> dict[str, Any] | None:
    """The live view usually pre-parses tool output to a dict; tolerate a raw JSON string."""
    if isinstance(result, dict):
        return result
    if isinstance(result, str) and result.strip():
        try:
            parsed = json.loads(result)
        except (json.JSONDecodeError, ValueError):
            return None
        return parsed if isinstance(parsed, dict) else None
    return None


def _summary_counts(summary: dict[str, Any]) -> str:
    total = summary.get("total", "?")
    pending = summary.get("pending", 0)
    reviewed = summary.get("reviewed", 0)
    ruled = summary.get("ruled_out", 0)
    return f"{total} units · {pending} pending / {reviewed} reviewed / {ruled} ruled_out"


class _CoverageBase(BaseToolRenderer):
    css_classes: ClassVar[list[str]] = ["tool-call", "coverage-tool"]
    label: ClassVar[str] = "Coverage"

    @classmethod
    def _header(cls) -> Text:
        text = Text()
        text.append(f"{_ICON} ")
        text.append(cls.label, style=_ACCENT)
        return text

    @classmethod
    def _body(cls, text: Text, data: dict[str, Any]) -> None:
        """Override to append a compact one-line summary for this tool."""

    @classmethod
    def render(cls, tool_data: dict[str, Any]) -> Static:
        result = tool_data.get("result")
        text = cls._header()
        data = _as_dict(result)

        if data is None:
            # Still running, or an unparseable payload — keep it terse, never dump raw.
            status = tool_data.get("status", "running")
            text.append("  ")
            text.append("…" if status == "running" else str(status), style="dim")
        elif data.get("success") is False:
            text.append("  ")
            text.append(str(data.get("error", "failed")), style="#ef4444")
        else:
            cls._body(text, data)

        return Static(text, classes=cls.get_css_classes("completed"))


@register_tool_renderer
class ListCoverageRenderer(_CoverageBase):
    tool_name: ClassVar[str] = "list_coverage"

    @classmethod
    def _body(cls, text: Text, data: dict[str, Any]) -> None:
        summary = data.get("summary")
        text.append("  ")
        text.append(
            _summary_counts(summary) if isinstance(summary, dict) else "listed", style="dim"
        )
        dense = data.get("high_density_files")
        if isinstance(dense, list) and dense:
            top = ", ".join(
                f"{d.get('file')} ({d.get('pending_units')})"
                for d in dense[:3]
                if isinstance(d, dict)
            )
            text.append("\n  high-density: ", style="dim")
            text.append(top, style="#f59e0b")
            if len(dense) > 3:
                text.append(f" +{len(dense) - 3} more", style="dim")


@register_tool_renderer
class AddCoverageUnitsRenderer(_CoverageBase):
    tool_name: ClassVar[str] = "add_coverage_units"

    @classmethod
    def _body(cls, text: Text, data: dict[str, Any]) -> None:
        added = data.get("added", 0)
        skipped = data.get("skipped_duplicates", 0)
        text.append("  ")
        text.append(f"+{added} units", style="#22c55e")
        if skipped:
            text.append(f" ({skipped} dup skipped)", style="dim")
        summary = data.get("summary")
        if isinstance(summary, dict):
            text.append(f" · {_summary_counts(summary)}", style="dim")


@register_tool_renderer
class MarkUnitReviewedRenderer(_CoverageBase):
    tool_name: ClassVar[str] = "mark_unit_reviewed"
    label: ClassVar[str] = "Coverage disposition"

    @classmethod
    def _body(cls, text: Text, data: dict[str, Any]) -> None:
        updated = data.get("updated")
        n = len(updated) if isinstance(updated, list) else 0
        text.append("  ")
        text.append(f"✓ {n} dispositioned", style="#22c55e")
        summary = data.get("summary")
        if isinstance(summary, dict):
            text.append(f" · {summary.get('pending', 0)} pending left", style="dim")


@register_tool_renderer
class SeedStaticInventoryRenderer(_CoverageBase):
    tool_name: ClassVar[str] = "seed_static_inventory"
    label: ClassVar[str] = "Inventory seed"

    @classmethod
    def _body(cls, text: Text, data: dict[str, Any]) -> None:
        added = data.get("added", 0)
        scanner = data.get("scanner")
        text.append("  ")
        text.append(f"seeded {added} units", style="#22c55e")
        if isinstance(scanner, dict):
            scanned = scanner.get("files_scanned")
            if scanned is not None:
                text.append(f" · scanned {scanned} files", style="dim")
            if scanner.get("capped"):
                text.append(" (capped — files beyond limit uncovered!)", style="#f59e0b")


@register_tool_renderer
class SeedCoverageFromSemgrepRenderer(_CoverageBase):
    tool_name: ClassVar[str] = "seed_coverage_from_semgrep"
    label: ClassVar[str] = "Coverage seed (semgrep)"

    @classmethod
    def _body(cls, text: Text, data: dict[str, Any]) -> None:
        added = data.get("added", 0)
        text.append("  ")
        text.append(f"+{added} file units from semgrep scope", style="#22c55e")

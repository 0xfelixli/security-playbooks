"""Per-scan sandbox session lifecycle."""

from __future__ import annotations

import logging
import os
import posixpath
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Any

from agents.sandbox.manifest import EnvEntry, Environment, EnvValue, Manifest
from agents.sandbox.workspace_paths import SandboxPathGrant

from talon.config import load_settings
from talon.core import workspace_layout
from talon.runtime.backends import SessionBundle, get_backend, register_backend


logger = logging.getLogger(__name__)


_SESSION_CACHE: dict[str, SessionBundle] = {}


async def create_or_reuse(
    scan_id: str,
    *,
    local_sources: list[dict[str, Any]],
) -> SessionBundle:
    """Return the existing session bundle for ``scan_id`` or create a new one.

    Dispatches on ``TALON_RUNTIME_BACKEND`` through the backend registry: ``docker``
    (default) creates a container-backed session exposing each target at
    ``/workspace/<workspace_subdir>`` (strix layout); ``local`` CoW-clones sources into a
    host workspace under the run dir.
    """
    settings = load_settings()
    cached = _SESSION_CACHE.get(scan_id)
    if cached is not None:
        logger.info("Reusing existing %s session", cached["backend"])
        return cached

    backend = get_backend(settings.runtime.runtime_backend)
    bundle = await backend(scan_id, local_sources=local_sources)

    _SESSION_CACHE[scan_id] = bundle
    logger.info("%s session ready and cached", bundle["backend"])
    return bundle


def _cow_clone(src: Path, dst: Path) -> None:
    """Copy-on-write clone ``src`` to ``dst`` (APFS clonefile / reflink; plain copy fallback).

    ``dst`` is removed first: ``cp -R src <existing-dst>`` would nest the source as
    ``dst/<name>/…`` instead of making ``dst`` the clone.
    """
    if dst.exists():
        shutil.rmtree(dst)
    dst.parent.mkdir(parents=True, exist_ok=True)
    # macOS APFS clonefile, then Linux reflink, then a plain recursive copy for
    # cross-volume / non-CoW filesystems (correct but not space-shared).
    attempts = (["cp", "-c", "-R"], ["cp", "--reflink=auto", "-R"], ["cp", "-R"])
    for args in attempts:
        try:
            # Fixed flags + resolved paths; no shell, no untrusted tokens.
            subprocess.run(  # noqa: S603
                [*args, str(src), str(dst)], check=True, capture_output=True
            )
        except (subprocess.CalledProcessError, FileNotFoundError):
            shutil.rmtree(dst, ignore_errors=True)
            continue
        logger.info("Cloned source via %s: %s -> %s", " ".join(args), src, dst)
        return
    raise RuntimeError(f"failed to clone source tree {src} -> {dst}")


def _agent_sandbox_env(
    layout: workspace_layout.WorkspaceLayout,
) -> dict[str, str | EnvValue | EnvEntry]:
    """Environment overlaid onto every agent shell command in the local sandbox.

    The SDK builds each command's env from ``os.environ.copy()`` overlaid with these
    values. When talon runs via ``uv run``, the ambient env points at talon's *own*
    ``.venv`` (``VIRTUAL_ENV`` + ``.venv/bin`` on ``PATH``), which lives outside the
    sandbox's confined workspace. Both leaks break agent commands:

    - ``uv`` follows ``VIRTUAL_ENV`` and tries to rewrite ``pyvenv.cfg`` (a write outside
      the workspace → EPERM under ``deny file-write*``).
    - ``python``/``python3`` resolve to ``.venv/bin/python`` via PATH, and a venv
      interpreter *reads* ``pyvenv.cfg`` at startup — also denied → ``init_import_site``
      fatal, the interpreter can't even start.

    Fix: blank ``VIRTUAL_ENV``, set ``UV_NO_SYNC``, and strip talon's venv ``bin`` from
    ``PATH``. The audit tools the agent uses (semgrep, trivy, gitleaks, ast-grep, ruff)
    are on the system/homebrew PATH, so nothing is lost, and ``python`` now resolves to
    the system interpreter with no venv config to read.

    Same class of leak, third variable: the ambient ``TMPDIR`` (``/var/folders/.../T`` on
    macOS) is outside the workspace, so a sandboxed tool writing a temp file there hits
    EPERM (e.g. semgrep's ``git ls-files`` captures git's stderr to a temp file and dies).
    Redirect ``TMPDIR``/``TMP``/``TEMP`` into a workspace-local dir the sandbox allows;
    those temp files are then cleaned with the run's workspace.
    """
    tmp_dir = Path(layout.workspace_root) / ".talon-tmp"
    tmp_dir.mkdir(parents=True, exist_ok=True)
    env: dict[str, str | EnvValue | EnvEntry] = {
        "PYTHONUNBUFFERED": "1",
        "VIRTUAL_ENV": "",
        "UV_NO_SYNC": "1",
        "TMPDIR": str(tmp_dir),
        "TMP": str(tmp_dir),
        "TEMP": str(tmp_dir),
        # Path vars (TALON_WORKSPACE_ROOT / TALON_ARTIFACT_DIR) come from layout.env() —
        # the single source of path truth skills consume via $ART.
        **layout.env(),
    }
    # NOTE: no DEVELOPER_DIR override is needed. macOS /usr/bin git is an xcrun shim that
    # reads libxcrun + Xcode DVT frameworks and writes an xcrun_db cache; the read-open
    # grants (_darwin_read_grants) and temp write grant (_darwin_temp_write_grant) let it
    # run cleanly under either full Xcode or Command Line Tools. The two coherent rules —
    # reads open, writes confined to workspace+temp — cover it without per-tool cases.
    venv_bins: set[str] = set()
    virtual_env = os.environ.get("VIRTUAL_ENV")
    if virtual_env:
        venv_bins.add(str(Path(virtual_env) / "bin"))
    if sys.prefix != sys.base_prefix:  # talon is running inside a venv
        venv_bins.add(str(Path(sys.prefix) / "bin"))
    if venv_bins:
        kept = [
            p
            for p in os.environ.get("PATH", "").split(os.pathsep)
            if p and str(Path(p)) not in venv_bins
        ]
        env["PATH"] = os.pathsep.join(kept)
    return env


# System roots the macOS sandbox profile denies that audit tools legitimately need to
# READ: system libraries/frameworks, toolchains (Homebrew, /usr), and configs. Granted
# READ-ONLY so tools load and run while writes stay confined. Deliberately EXCLUDES:
#   - ``/Users`` — the user's private files; audited code lives in the workspace.
#   - the temp roots (``/var``/``/private``/``/tmp``) — a read-only grant here re-denies
#     writes, and since it's emitted AFTER the temp write grant it would clobber it
#     (last-match-wins). Temp writes are handled by the temp grant.
_DARWIN_READ_ROOTS = ("/Applications", "/Library", "/opt", "/usr", "/etc", "/Volumes")


def _darwin_read_grants() -> list[SandboxPathGrant]:
    """Read-only grants opening the system dirs audit tools need to read on macOS.

    The ``sandbox-exec`` profile denies reads under ``/Applications``, ``/usr``, etc.,
    breaking tools that must read shared libraries — e.g. ``/usr/bin/git`` is an ``xcrun``
    shim that ``dlopen``s ``libxcrun.dylib`` from those roots, dying with ``sandbox blocked
    open()`` and taking git-backed tooling (gitleaks, semgrep's ``git ls-files``) with it.
    Grant READ-ONLY so reads succeed; writes remain denied (isolation preserved).
    """
    if sys.platform != "darwin":
        return []
    return [
        SandboxPathGrant(
            path=root,
            read_only=True,
            description="system read access for audit tools",
        )
        for root in _DARWIN_READ_ROOTS
        if Path(root).exists()
    ]


def _darwin_temp_write_grant() -> list[SandboxPathGrant]:
    """Writable grant for the per-user system temp dir on macOS.

    Some tools ignore ``$TMPDIR`` and hardcode the confstr system temp
    (``/var/folders/.../T``): xcrun's cache DB (written by the ``/usr/bin/git`` shim) and
    BSD ``mktemp`` are the common offenders. The sandbox denies ``/var``, so those writes
    EPERM to stderr — and gitleaks treats ANY git stderr as failure, silently downgrading
    to a partial (no-history) scan. Redirecting ``TMPDIR`` can't help (these bypass it), so
    grant WRITE on the per-user temp dir itself; the source tree, HOME, and system dirs
    stay denied. ``extra_path_grants`` also grants the resolved path, covering the
    ``/var`` → ``/private/var`` symlink.
    """
    if sys.platform != "darwin":
        return []
    return [
        SandboxPathGrant(
            path=tempfile.gettempdir(),
            read_only=False,
            description="per-user system temp (xcrun_db / mktemp; TMPDIR-immune tools)",
        )
    ]


# Every root the macOS sandbox profile denies. The unrestricted escape hatch grants
# read+write on all of them (including /Users and the temp roots), collapsing the
# sandbox's write isolation. Superset of the default read-open + temp-write grants.
_DARWIN_ALL_DENIED_ROOTS = (
    "/Users",
    "/Volumes",
    "/Applications",
    "/Library",
    "/opt",
    "/etc",
    "/private",
    "/tmp",  # noqa: S108 — sandbox root path, not a temp-file location
    "/var",
    "/usr",
)


def _darwin_unrestricted_grants() -> list[SandboxPathGrant]:
    """Read+write grants on every denied root — the ``TALON_SANDBOX_UNRESTRICTED`` hatch.

    Opt-in only. Disables the sandbox's write isolation entirely: the agent's shell can
    read and write anywhere on the host, not just workspace + temp. SOLELY for auditing
    fully-trusted local code — on untrusted code this removes the only guard against a
    mistaken/prompt-injected agent mutating the host. Because grants are read+write there
    is no re-deny, so no ordering conflict with anything.
    """
    if sys.platform != "darwin":
        return []
    return [
        SandboxPathGrant(
            path=root,
            read_only=False,
            description="TALON_SANDBOX_UNRESTRICTED (fully-trusted code only)",
        )
        for root in _DARWIN_ALL_DENIED_ROOTS
        if Path(root).exists()
    ]


def _darwin_sandbox_grants(*, unrestricted: bool) -> list[SandboxPathGrant]:
    """Pick the sandbox path grants: default (read-open + temp-write) or unrestricted."""
    if unrestricted:
        logger.warning(
            "TALON_SANDBOX_UNRESTRICTED=1: sandbox WRITE isolation is DISABLED — the "
            "agent's shell can write anywhere on the host. Use only on fully-trusted code."
        )
        return _darwin_unrestricted_grants()
    return _darwin_read_grants() + _darwin_temp_write_grant()


async def _create_local(
    scan_id: str,
    *,
    local_sources: list[dict[str, Any]],
) -> SessionBundle:
    """Bring up a host-local session for static/whitebox review — no Docker.

    Backed by the SDK's ``UnixLocalSandboxClient``, which runs every ``session.exec`` via
    a host subprocess rooted at ``manifest.root``. Each source is CoW-cloned into
    ``<run_dir>/workspace/<workspace_subdir>``, matching the Docker backend's layout so the
    agent's relative ``<subdir>/`` path resolves identically on both. The clone means the
    agent's writes land on a copy, never the real repo (unconditional, not gated).

    ⚠️ Commands run with the current user's privileges. On macOS the SDK confines them to
    ``manifest.root`` via ``sandbox-exec``; on Linux there is no confinement. Only point
    this at code you trust.
    """
    usable = [
        src
        for src in local_sources
        if (src.get("source_path") or "").strip() and (src.get("workspace_subdir") or "").strip()
    ]
    if not usable:
        raise RuntimeError(
            "Talon local backend requires at least one source with a workspace_subdir. "
            "Route targets through assign_workspace_subdirs before creating the session."
        )

    settings = load_settings()

    # Clone every source into <run_dir>/workspace/<subdir>; clonefile makes this
    # near-instant on APFS.
    layout = workspace_layout.for_local(scan_id)
    workspace_root = layout.workspace_root
    for src in usable:
        subdir = str(src["workspace_subdir"]).strip()
        source_root = Path(src["source_path"]).expanduser().resolve()
        _cow_clone(source_root, Path(layout.source_path(subdir)))

    # No entries → session.start() only mkdirs the (already-cloned) root; no copy.
    manifest = Manifest(
        root=workspace_root,
        environment=Environment(value=_agent_sandbox_env(layout)),
        extra_path_grants=tuple(
            _darwin_sandbox_grants(unrestricted=settings.runtime.sandbox_unrestricted)
        ),
    )

    from agents.sandbox.sandboxes.unix_local import (  # noqa: PLC0415 — deferred: platform-specific sandbox backend
        UnixLocalSandboxClient,
        UnixLocalSandboxClientOptions,
    )

    logger.info(
        "Creating local (host) session workspace_root=%s sources=%d",
        workspace_root,
        len(usable),
    )
    client = UnixLocalSandboxClient()
    options = UnixLocalSandboxClientOptions(exposed_ports=())
    session = await client.create(options=options, manifest=manifest)
    await session.start()

    await _run_setup_command(session, workspace_root=workspace_root)

    return {
        "backend": "local",
        "client": client,
        "session": session,
        "workspace_clone": workspace_root,
        "layout": layout,
    }


def _container_env(
    layout: workspace_layout.WorkspaceLayout,
) -> dict[str, str | EnvValue | EnvEntry]:
    """Minimal environment for commands running inside the sandbox image.

    Path vars (``TALON_WORKSPACE_ROOT`` / ``TALON_ARTIFACT_DIR``) come from ``layout.env()``,
    the single source of path truth. Artifacts land at the writable workspace ROOT (via
    ``$ART``), separate from the read-only ``--mount`` source subdirs. TMPDIR is redirected
    to the workspace-local ``.talon-tmp`` dir so tool temp files are writable and cleaned
    with the workspace — matching the local backend's ``_agent_sandbox_env``.
    """
    tmp_dir = posixpath.join(layout.workspace_root, ".talon-tmp")
    return {
        "PYTHONUNBUFFERED": "1",
        "TMPDIR": tmp_dir,
        "TMP": tmp_dir,
        "TEMP": tmp_dir,
        **layout.env(),
    }


def _local_dir_size_mb(path: Path) -> int:
    total = 0
    for child in path.rglob("*"):
        try:
            if child.is_symlink():
                continue
            if child.is_file():
                total += child.stat().st_size
        except OSError:
            continue
    return total // (1024 * 1024)


def _build_session_entries(
    local_sources: list[dict[str, Any]],
    *,
    max_local_copy_mb: int,
) -> tuple[dict[str | Path, Any], list[dict[str, Any]]]:
    """Split local sources into copied manifest entries and host bind mounts.

    Mirrors strix: every source is exposed below ``/workspace`` at its assigned
    ``workspace_subdir``. ``--mount`` sources bypass SDK file streaming and become
    read-only Docker bind mounts at the same in-container path.
    """
    from agents.sandbox.entries import LocalDir  # noqa: PLC0415

    entries: dict[str | Path, Any] = {}
    bind_mounts: list[dict[str, Any]] = []

    for src in local_sources:
        workspace_subdir = str(src.get("workspace_subdir") or "").strip()
        host_path = str(src.get("source_path") or "").strip()
        if not workspace_subdir or not host_path:
            continue

        source_root = Path(host_path).expanduser().resolve()
        target = f"{workspace_layout.CONTAINER_WORKSPACE}/{workspace_subdir}"
        if src.get("mount"):
            bind_mounts.append({"source": str(source_root), "target": target, "read_only": True})
            continue

        size_mb = _local_dir_size_mb(source_root)
        if max_local_copy_mb > 0 and size_mb > max_local_copy_mb:
            raise RuntimeError(
                f"Docker LocalDir copy size is {size_mb} MB for {source_root}, above "
                f"TALON_MAX_LOCAL_COPY_MB={max_local_copy_mb}. "
                "Use --mount to bind-mount the source read-only."
            )
        entries[workspace_subdir] = LocalDir(src=source_root)

    return entries, bind_mounts


async def _create_docker(
    _scan_id: str,
    *,
    local_sources: list[dict[str, Any]],
) -> SessionBundle:
    """Bring up a Docker-backed session for static/whitebox review."""
    usable = [src for src in local_sources if (src.get("source_path") or "").strip()]
    if not usable:
        raise RuntimeError(
            "Talon Docker backend requires at least one local source. "
            "Point --target or --mount at a local directory."
        )

    settings = load_settings()
    from agents.sandbox.manifest import Environment  # noqa: PLC0415

    entries, bind_mounts = _build_session_entries(
        usable,
        max_local_copy_mb=settings.runtime.max_local_copy_mb,
    )
    if not entries and not bind_mounts:
        raise RuntimeError(
            "Talon Docker backend requires local sources with workspace_subdir. "
            "Route targets through assign_workspace_subdirs before creating the session."
        )

    # strix artifact layout: SAST artifacts go to the writable workspace ROOT
    # (``/workspace/.talon-source-aware`` = TALON_ARTIFACT_DIR); agents write there via
    # ``$ART``. The root is the container's writable overlay; each ``<subdir>`` source is a
    # read-only bind mount.
    #
    # Do NOT overlay a per-subdir writable dir (e.g. a tmpfs at
    # ``<subdir>/.talon-source-aware``) as a belt for models that write relative to the RO
    # source: runc must ``mkdir`` the mountpoint inside the RO bind mount first, which
    # EROFS-fails and takes the whole container down at start. A model that ignores $ART
    # just gets a recoverable EROFS on its write — far better than an unstartable container.

    layout = workspace_layout.for_docker()
    manifest = Manifest(
        root=layout.workspace_root,
        entries=entries,
        environment=Environment(value=_container_env(layout)),
    )

    logger.info(
        "Creating docker session image=%s workspace_root=%s sources=%d mounts=%d",
        settings.runtime.image,
        layout.workspace_root,
        len(usable),
        len(bind_mounts),
    )
    # Deferred: keep the hard docker-package dependency out of module import.
    from talon.runtime import docker_client  # noqa: PLC0415

    client, session = await docker_client.create_docker_session(
        image=settings.runtime.image,
        manifest=manifest,
        exposed_ports=(),
        bind_mounts=bind_mounts,
    )
    await _run_setup_command(session, workspace_root=layout.workspace_root)

    return {
        "backend": "docker",
        "client": client,
        "session": session,
        "workspace_clone": None,
        "layout": layout,
    }


async def _run_setup_command(
    session: Any, *, workspace_root: str = workspace_layout.CONTAINER_WORKSPACE
) -> None:
    """Run ``TALON_SETUP_CMD`` once in the session before agents start.

    Best-effort: a non-zero exit is logged loudly but does not abort the scan. Runs via
    ``bash -lc`` from ``workspace_root`` so it inherits the manifest env like agent shells.
    """
    settings = load_settings()
    cmd = (settings.runtime.setup_cmd or "").strip()
    if not cmd:
        return

    logger.info(
        "Running TALON_SETUP_CMD in session timeout=%ss cmd=%s",
        settings.runtime.setup_timeout,
        cmd,
    )
    try:
        result = await session.exec(
            "bash",
            "-lc",
            f"cd {workspace_root} && {cmd}",
            timeout=settings.runtime.setup_timeout,
        )
    except Exception:
        logger.exception("TALON_SETUP_CMD raised; continuing without setup")
        return

    if result.ok():
        logger.info("TALON_SETUP_CMD completed (exit 0)")
    else:
        stderr = result.stderr.decode("utf-8", errors="replace")[-2000:]
        logger.error("TALON_SETUP_CMD failed (exit %s):\n%s", result.exit_code, stderr)


async def cleanup(scan_id: str) -> None:
    """Tear down ``scan_id``'s session and drop its cache entry.

    Best-effort: any error during ``client.delete`` is logged and swallowed —
    a cleanup failure must never block the next scan.
    """
    bundle = _SESSION_CACHE.pop(scan_id, None)
    if bundle is None:
        logger.debug("No cached session to clean up for scan %s", scan_id)
        return

    try:
        await bundle["client"].delete(bundle["session"])
        logger.info("Cleaned up %s session", bundle.get("backend", "unknown"))
    except Exception:
        logger.exception("Failed to clean up session for scan %s", scan_id)

    # The local backend's CoW clone workspace is kept after the scan so you can inspect
    # what the agent read/wrote; it's removed manually (or when the run dir is cleaned).
    clone = bundle.get("workspace_clone")
    if clone:
        logger.info("Keeping clone workspace at %s", clone)


register_backend("docker", _create_docker)
register_backend("local", _create_local)

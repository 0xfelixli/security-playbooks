"""Sandbox backend registry.

A backend is a full session creator: given a scan id and its local sources, it
brings up a sandbox session and returns a :class:`SessionBundle`. Both built-in
backends live in :mod:`talon.runtime.session_manager` and register themselves
here at import time; ``create_or_reuse`` dispatches through :func:`get_backend`,
so adding a backend means registering one callable — no dispatch edits.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any, Protocol, TypedDict


if TYPE_CHECKING:
    from collections.abc import Awaitable

    from talon.core.workspace_layout import WorkspaceLayout


logger = logging.getLogger(__name__)


class SessionBundle(TypedDict):
    """Everything a live sandbox session hands to the rest of the scan.

    ``client``/``session`` stay ``Any``: they are SDK objects with different concrete
    types per backend (Docker vs unix-local), consumed only through their shared
    duck-typed surface (``session.exec``, ``client.delete``).
    """

    backend: str
    client: Any
    session: Any
    # Host path of the CoW-cloned workspace (local backend), or None when the
    # workspace lives inside a container (docker backend).
    workspace_clone: str | None
    layout: WorkspaceLayout


class SandboxBackend(Protocol):
    """Session creator contract: ``(scan_id, *, local_sources) -> SessionBundle``.

    ``scan_id`` is positional-only so implementations may name it freely (e.g. an
    underscore-prefixed name when a backend derives everything from the layout).
    """

    def __call__(
        self,
        scan_id: str,
        /,
        *,
        local_sources: list[dict[str, Any]],
    ) -> Awaitable[SessionBundle]: ...


_BACKENDS: dict[str, SandboxBackend] = {}


def get_backend(name: str) -> SandboxBackend:
    backend = _BACKENDS.get(name)
    if backend is None:
        supported = ", ".join(sorted(_BACKENDS))
        raise ValueError(f"Unknown TALON_RUNTIME_BACKEND: {name!r} (supported: {supported})")
    logger.debug("Selected sandbox backend: %s", name)
    return backend


def register_backend(name: str, backend: SandboxBackend) -> None:
    _BACKENDS[name] = backend
    # DEBUG: built-in registration fires at import time, before scan logging is up.
    logger.debug("Registered sandbox backend: %s", name)


def supported_backends() -> list[str]:
    return sorted(_BACKENDS)

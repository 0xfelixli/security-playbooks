"""Docker client extension matching strix container permissions and mounts."""

from __future__ import annotations

import contextlib
import logging
from typing import TYPE_CHECKING, Any

from agents.sandbox.sandboxes.docker import (
    DockerSandboxClient,
    _build_docker_volume_mounts,
    _docker_port_key,
    _manifest_requires_fuse,
    _manifest_requires_sys_admin,
)
from docker import errors as docker_errors  # type: ignore[import-untyped]
from docker.types import Mount as DockerSDKMount  # type: ignore[import-untyped]
from docker.utils import parse_repository_tag  # type: ignore[import-untyped]


if TYPE_CHECKING:
    import uuid

    from agents.sandbox.manifest import Manifest
    from agents.sandbox.session.sandbox_session import SandboxSession


logger = logging.getLogger(__name__)


async def create_docker_session(
    *,
    image: str,
    manifest: Manifest,
    exposed_ports: tuple[int, ...] = (),
    bind_mounts: list[dict[str, Any]] | None = None,
) -> tuple[TalonDockerSandboxClient, Any]:
    """Bring up a started session backed by the local Docker daemon."""
    import docker  # noqa: PLC0415
    from agents.sandbox.sandboxes.docker import DockerSandboxClientOptions  # noqa: PLC0415

    client = TalonDockerSandboxClient(docker.from_env())
    client.talon_bind_mounts = bind_mounts or []
    options = DockerSandboxClientOptions(image=image, exposed_ports=exposed_ports)
    session = await client.create(options=options, manifest=manifest)
    await session.start()
    return client, session


def _talon_mount(spec: dict[str, Any]) -> DockerSDKMount:
    """Build a docker Mount from a talon bind-mount spec (host bind, or in-memory tmpfs)."""
    if spec.get("type") == "tmpfs":
        # In-memory writable overlay, no host source.
        return DockerSDKMount(target=spec["target"], source=None, type="tmpfs")
    return DockerSDKMount(
        target=spec["target"],
        source=spec["source"],
        type="bind",
        read_only=spec.get("read_only", True),
    )


class TalonDockerSandboxClient(DockerSandboxClient):
    """SDK Docker client plus Talon's read-only source bind mounts."""

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        self.talon_bind_mounts: list[dict[str, Any]] = []

    async def _create_container(
        self,
        image: str,
        *,
        manifest: Manifest | None = None,
        exposed_ports: tuple[int, ...] = (),
        session_id: uuid.UUID | None = None,
    ) -> Any:
        # Verbatim SDK 0.14.6 body, except for the strix-aligned injections below.
        if not self.image_exists(image):
            repo, tag = parse_repository_tag(image)
            self.docker_client.images.pull(repo, tag=tag or None, all_tags=False)

        assert self.image_exists(image)
        environment: dict[str, str] | None = None
        if manifest:
            environment = await manifest.environment.resolve()
        create_kwargs: dict[str, Any] = {
            "image": image,
            "detach": True,
            "command": ["tail", "-f", "/dev/null"],
            "environment": environment,
        }
        if manifest is not None:
            docker_mounts = _build_docker_volume_mounts(manifest, session_id=session_id)
            if docker_mounts:
                create_kwargs["mounts"] = docker_mounts
            if _manifest_requires_fuse(manifest):
                create_kwargs.update(
                    devices=["/dev/fuse"],
                    cap_add=["SYS_ADMIN"],
                    security_opt=["apparmor:unconfined"],
                )
            elif _manifest_requires_sys_admin(manifest):
                create_kwargs.update(
                    cap_add=["SYS_ADMIN"],
                    security_opt=["apparmor:unconfined"],
                )
        if exposed_ports:
            create_kwargs["ports"] = {
                _docker_port_key(port): ("127.0.0.1", None) for port in exposed_ports
            }

        cap_add = create_kwargs.setdefault("cap_add", [])
        if not isinstance(cap_add, list):
            cap_add = list(cap_add)
            create_kwargs["cap_add"] = cap_add
        for cap in ("NET_ADMIN", "NET_RAW"):
            if cap not in cap_add:
                cap_add.append(cap)

        extra_hosts = create_kwargs.setdefault("extra_hosts", {})
        extra_hosts["host.docker.internal"] = "host-gateway"

        bind_mounts = getattr(self, "talon_bind_mounts", ())
        if bind_mounts:
            mounts = create_kwargs.setdefault("mounts", [])
            mounts.extend(_talon_mount(spec) for spec in bind_mounts)

        container = self.docker_client.containers.create(**create_kwargs)
        logger.info(
            "Sandbox container created: id=%s image=%s caps=%s bind_mounts=%d",
            container.short_id if hasattr(container, "short_id") else "?",
            image,
            cap_add,
            len(bind_mounts),
        )
        return container

    async def delete(self, session: SandboxSession) -> SandboxSession:
        container_id = getattr(getattr(session._inner, "state", None), "container_id", None)
        if container_id:
            with contextlib.suppress(docker_errors.NotFound, docker_errors.APIError):
                self.docker_client.containers.get(container_id).kill()
        return await super().delete(session)

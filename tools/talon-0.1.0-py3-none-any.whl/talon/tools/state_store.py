"""Shared persistence for agent-scratch state (coverage / todos / notes).

Each of those tool families is one scan-wide singleton: a dict mirrored to a JSON
file under ``{state_dir}/``, guarded by a lock, written atomically.
``PersistentJsonStore`` owns the shared half — the lock, path, atomic write, and safe
file read. Each tool module keeps its own instance and its own shape-specific hydration
(flat vs. nested): it calls :meth:`bind` to load the raw JSON, transforms it into
``self.data``, and calls :meth:`persist` after every mutation.
"""

from __future__ import annotations

import json
import logging
import tempfile
import threading
from pathlib import Path
from typing import Any


logger = logging.getLogger(__name__)


class PersistentJsonStore:
    """A scan-wide dict mirrored to ``{state_dir}/<filename>``, written atomically."""

    def __init__(self, filename: str) -> None:
        self._filename = filename
        self.data: dict[str, Any] = {}
        self.lock = threading.RLock()
        self.path: Path | None = None

    def bind(self, state_dir: Path) -> dict[str, Any] | None:
        """Point at ``{state_dir}/<filename>``, clear state, and return the raw JSON dict.

        Returns ``None`` when there is nothing to load (no prior file, unreadable, or
        not a JSON object). The caller transforms the raw dict into ``self.data`` under
        :attr:`lock`, since the flat-vs-nested shape differs per store.
        """
        self.path = state_dir / self._filename
        with self.lock:
            self.data.clear()
            if not self.path.exists():
                return None
            try:
                raw = json.loads(self.path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                logger.exception("%s is unreadable; starting with empty state", self.path)
                return None
        return raw if isinstance(raw, dict) else None

    def persist(self) -> None:
        """Atomically mirror :attr:`data` to disk (temp file + replace). No-op if unbound."""
        path = self.path
        if path is None:
            return
        try:
            # dumps under the lock so ``data`` is a consistent snapshot (RLock is reentrant,
            # so a holding caller won't deadlock). Write stays outside — payload is immutable
            # and ``replace`` is atomic.
            with self.lock:
                payload = json.dumps(self.data, ensure_ascii=False, default=str)
            path.parent.mkdir(parents=True, exist_ok=True)
            with tempfile.NamedTemporaryFile(
                mode="w",
                encoding="utf-8",
                dir=str(path.parent),
                prefix=f".{path.name}.",
                suffix=".tmp",
                delete=False,
            ) as tmp:
                tmp.write(payload)
                tmp_path = Path(tmp.name)
            tmp_path.replace(path)
        except Exception:
            logger.exception("persist to %s failed", path)

    def clear(self) -> None:
        """Drop all in-memory state (does not touch disk). Convenience for tests."""
        with self.lock:
            self.data.clear()

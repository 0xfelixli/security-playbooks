"""``finish_scan`` — root-agent termination + executive report persistence."""

from __future__ import annotations

import asyncio
import json
import logging
from typing import Any

from agents import RunContextWrapper, function_tool

from talon.core.agents import coordinator_from_context
from talon.core.lifecycle import SCAN_COMPLETED_KEY
from talon.tools.coverage.tools import compute_blocking_pending


logger = logging.getLogger(__name__)

_MAX_PENDING_LISTED = 25
# The recall gate keys on the derived coverage ROLE, not the raw kind: under the entrypoint
# gate (default on) every pending entry-role unit (route/handler/entrypoint/contract_fn)
# blocks finish regardless of class/confidence. Sinks gate via their vulnerability_class,
# files via strict_file_fallback — neither has its own role dimension here.


def _coverage_gate(
    *, parent_id: str | None, is_whitebox: bool = False, scan_mode: str = "deep"
) -> dict[str, Any] | None:
    """Block root finish until the coverage manifest is enumerated and dispositioned.

    Returns an error payload to short-circuit ``finish_scan``, or ``None`` to proceed.
    Only the root agent is gated; ``TALON_DISABLE_COVERAGE_GATE`` disables it entirely.
    ``quick`` mode is exempt (targeted testing, no exhaustive-enumeration obligation);
    recall is guaranteed only in ``standard``/``deep``.

    Three ways to fail:

    - **Empty manifest on a whitebox scan** — a source-available scan must register
      units before finishing. (Black-box scans pass on empty; manifest is optional.)
    - **High-signal pending units** — a registered unit with a vulnerability_class AND
      high/medium confidence is still undispositioned. Low-signal file-fallback units
      (no class) and low-confidence high-signal units don't block (advisory only).
    - **Undispositioned entrypoint units** (entrypoint gate, default on) — an enumerated
      attack-surface entry (route / handler / entrypoint / contract_fn) is still pending,
      regardless of vulnerability_class. Set ``TALON_ENTRYPOINT_GATE=false`` to fall back
      to the class-only gate.
    """
    # Only the root is gated; quick mode has no exhaustive-coverage obligation.
    if parent_id is not None or scan_mode == "quick":
        logger.debug("coverage gate: exempt (root=%s, scan_mode=%s)", parent_id is None, scan_mode)
        return None
    try:
        from talon.config import load_settings

        agent_settings = load_settings().agents
        if agent_settings.disable_coverage_gate:
            logger.debug("coverage gate: disabled via TALON_DISABLE_COVERAGE_GATE; allowing finish")
            return None
        strict_file_fallback = agent_settings.strict_file_fallback
        # getattr (not direct access) is load-bearing: several gate tests inject a minimal
        # settings double that omits this field, and prod AgentSettings always defines it,
        # so the default is only ever taken by those stubs.
        entrypoint_gate = getattr(agent_settings, "entrypoint_gate", True)

        from talon.tools.coverage.tools import manifest_is_empty

        if manifest_is_empty():
            logger.debug(
                "coverage gate: manifest empty (whitebox=%s) — %s",
                is_whitebox,
                "blocking finish" if is_whitebox else "allowing (black-box, manifest optional)",
            )
            return (
                {
                    "success": False,
                    SCAN_COMPLETED_KEY: False,
                    "error": (
                        "Coverage gate: no attack-surface units were registered for this "
                        "whitebox scan. Enumerate the surface first — call "
                        "seed_coverage_from_semgrep on your semgrep report, then "
                        "add_coverage_units for routes/handlers/sinks — review each, and "
                        "only then finish. This blocks finishing on an un-enumerated scan."
                    ),
                    "pending_count": 0,
                }
                if is_whitebox
                else None
            )
        breakdown = compute_blocking_pending(
            strict_file_fallback=strict_file_fallback,
            entrypoint_gate=entrypoint_gate,
        )
    except Exception:
        # Fail-CLOSED: a recall gate that errors cannot confirm the attack surface was
        # reviewed, so it must refuse finish, not silently pass an unaudited scan (the exact
        # failure this product exists to prevent). The explicit TALON_DISABLE_COVERAGE_GATE
        # escape hatch (checked above) remains the intentional override.
        logger.exception("coverage gate check errored; BLOCKING finish (fail-closed)")
        return {
            "success": False,
            SCAN_COMPLETED_KEY: False,
            "error": (
                "Coverage gate check failed with an internal error and cannot confirm the "
                "attack surface was fully reviewed. Refusing to finish (fail-closed) rather "
                "than pass a possibly-unaudited scan. Investigate the logged error; set "
                "TALON_DISABLE_COVERAGE_GATE=true only to deliberately override."
            ),
            "pending_count": 0,
            "gate_error": True,
        }

    # ``compute_blocking_pending`` owns the four-dimension partition (shared with the resume
    # recovery-frontier injection so the two can never drift); the gate consumes its result
    # for both the block decision and the diagnostic breakdown below.
    pending = breakdown.pending
    high_signal = breakdown.high_signal
    class_blocking = breakdown.class_blocking
    file_pending = breakdown.file_pending
    entrypoint_pending = breakdown.entrypoint_pending
    blocking_pending = breakdown.blocking
    if not blocking_pending:
        logger.debug(
            "coverage gate: passed — %d pending unit(s), 0 blocking "
            "(%d high-signal all dispositioned/advisory, strict_file_fallback=%s, "
            "entrypoint_gate=%s)",
            len(pending),
            len(high_signal),
            strict_file_fallback,
            entrypoint_gate,
        )
        return None

    integrity_pending = breakdown.integrity_pending
    blocking_ids = {u.get("unit_id") for u in blocking_pending}
    listed = blocking_pending[:_MAX_PENDING_LISTED]
    # Advisory = high-signal units that did NOT end up blocking (low-confidence and not an
    # entrypoint kind). Counts exclude anything already in the blocking set so the numbers
    # partition cleanly.
    advisory_count = sum(1 for u in high_signal if u.get("unit_id") not in blocking_ids)
    low_signal_count = sum(
        1
        for u in pending
        if not str(u.get("vulnerability_class") or "").strip()
        and u.get("unit_id") not in blocking_ids
    )
    # Count entrypoint/integrity units NOT already counted under class/file, so the four
    # dimensions partition the blocking set cleanly (no unit counted twice).
    _class_file_ids = {u.get("unit_id") for u in (*class_blocking, *file_pending)}
    entrypoint_count = sum(1 for u in entrypoint_pending if u.get("unit_id") not in _class_file_ids)
    _prior_ids = _class_file_ids | {u.get("unit_id") for u in entrypoint_pending}
    integrity_count = sum(1 for u in integrity_pending if u.get("unit_id") not in _prior_ids)
    # INFO, not DEBUG: the gate refusing finish_scan is the most common reason a scan
    # "mysteriously" keeps running — it must be visible in the default log.
    logger.info(
        "coverage gate: BLOCKED — %d blocking unit(s) pending "
        "(class=%d, entrypoint=%d, file_fallback=%d, integrity=%d, advisory=%d, low_signal=%d)",
        len(blocking_pending),
        len(class_blocking),
        entrypoint_count,
        len(file_pending),
        integrity_count,
        advisory_count,
        low_signal_count,
    )
    return {
        "success": False,
        SCAN_COMPLETED_KEY: False,
        "error": (
            f"Coverage gate: {len(blocking_pending)} attack-surface unit(s) are still "
            "pending review. Every high/medium-confidence unit with a vulnerability_class "
            "AND every enumerated entrypoint (route/handler/entrypoint/contract_fn) must be "
            "dispositioned via mark_unit_reviewed (reviewed or ruled_out) before finishing. "
            "Assign finders to the open units and disposition each with evidence read from "
            "its OWN file — a single shared note cannot clear units across many files. Use "
            "list_coverage to see the full list, then call finish_scan again."
            + (
                f" ({advisory_count} low-confidence unit(s) are advisory — review encouraged "
                "but not required to finish.)"
                if advisory_count
                else ""
            )
        ),
        "pending_count": len(blocking_pending),
        "entrypoint_pending_count": entrypoint_count,
        "integrity_pending_count": integrity_count,
        "advisory_pending_count": advisory_count,
        "low_signal_pending_count": low_signal_count,
        "pending_units": [
            {
                "unit_id": u.get("unit_id"),
                "kind": u.get("kind"),
                "location": u.get("location"),
                "title": u.get("title"),
            }
            for u in listed
        ],
        "truncated": len(blocking_pending) > len(listed),
    }


_MAX_UNOWNED_LISTED = 15


async def _source_coverage_check(  # noqa: PLR0911
    inner: dict[str, Any], *, parent_id: str | None, is_whitebox: bool, scan_mode: str
) -> dict[str, Any] | None:
    """Filesystem-coverage dimension: every in-scope source file must be owned by a unit.

    Re-derives the source denominator from the tree at finish time (independent of what
    seeding registered), and finds files claimed by no coverage unit. Always computes and
    records the gap; only blocks finish when ``TALON_STRICT_COVERAGE`` is on. Best-effort:
    a missing sandbox, an exec failure, or an empty walk degrades to a note, never a block
    on an infra hiccup. Root + whitebox + non-quick only, matching the disposition gate.
    """
    if parent_id is not None or scan_mode == "quick" or not is_whitebox:
        return None
    try:
        from talon.config import load_settings

        agent_settings = load_settings().agents
        if agent_settings.disable_coverage_gate:
            return None
        strict = bool(getattr(agent_settings, "strict_coverage", False))

        from talon.tools.coverage.tools import unowned_source_files
        from talon.tools.inventory.tools import list_source_inventory

        eligible, capped, err = await list_source_inventory(inner)
        if err or not eligible:
            logger.info("source-coverage check skipped: %s", err or "no eligible files found")
            return None
        unowned = unowned_source_files(eligible)
    except Exception:
        logger.exception("source-coverage check failed; not blocking finish")
        return None

    _record_source_coverage(total=len(eligible), unowned=unowned, capped=capped)
    if not unowned:
        logger.info("source-coverage: all %d in-scope file(s) owned by a unit", len(eligible))
        return None
    logger.info(
        "source-coverage: %d/%d in-scope file(s) owned by NO unit%s (strict=%s)",
        len(unowned),
        len(eligible),
        " [walk capped]" if capped else "",
        strict,
    )
    if not strict:
        return None
    listed = unowned[:_MAX_UNOWNED_LISTED]
    return {
        "success": False,
        SCAN_COMPLETED_KEY: False,
        "error": (
            f"Source-coverage gate: {len(unowned)} of {len(eligible)} in-scope source file(s) "
            "are owned by NO coverage unit — they were never enumerated for review. Register "
            "and review them (seed_static_inventory / add_coverage_units, then finders), or "
            "confirm they are genuinely out of scope. This is the filesystem denominator: a "
            "file no unit ever claimed is a file that could have been missed entirely."
            + (" (The eligible-file walk hit its cap, so more may be unlisted.)" if capped else "")
        ),
        "unowned_count": len(unowned),
        "source_files_total": len(eligible),
        "unowned_files": listed,
        "truncated": len(unowned) > len(listed),
    }


async def _auto_sweep_unauditable(
    inner: dict[str, Any], *, parent_id: str | None, is_whitebox: bool, scan_mode: str
) -> None:
    """Clear pending blocking units that are MACHINE-VERIFIED build artifacts, before gating.

    The recall-safe deadlock breaker: a residual minified chunk carrying a vulnerability_class
    can never be given a resolving file:line, so without this it blocks the gate forever. Only
    files double-proved unauditable in the sandbox are cleared (fail-closed toward review — see
    ``coverage.tools._verify_unauditable``); real source is untouched and still blocks. Off
    under ``TALON_AUTO_SKIP_UNAUDITABLE=false`` (paranoid runs keep them blocking). Root +
    whitebox + non-quick only, matching the disposition gate. Best-effort: never raises.
    """
    if parent_id is not None or scan_mode == "quick" or not is_whitebox:
        return
    try:
        from talon.config import load_settings

        agent_settings = load_settings().agents
        if agent_settings.disable_coverage_gate:
            return
        if not agent_settings.auto_skip_unauditable:
            logger.debug("unauditable auto-sweep: disabled via TALON_AUTO_SKIP_UNAUDITABLE")
            return

        from talon.tools.coverage.tools import sweep_unauditable

        result = await sweep_unauditable(inner)
    except Exception:
        logger.exception("unauditable auto-sweep failed; clearing nothing")
        return
    if result.get("cleared"):
        files = result.get("files") or []
        logger.warning(
            "coverage gate: auto-dispositioned %d blocking unit(s) across %d file(s) as "
            "structurally unauditable (build artifacts / minified bundles): %s%s",
            result["cleared"],
            len(files),
            ", ".join(files[:20]),
            " …" if len(files) > 20 else "",
        )
        _record_unauditable_sweep(result)


def _record_unauditable_sweep(result: dict[str, Any]) -> None:
    """Stash the auto-sweep tally into run.json telemetry so a scan that finished by skipping
    build artifacts is visible, never silently green."""
    try:
        from talon.report.state import get_global_report_state

        state = get_global_report_state()
        if state is None:
            return
        quality = state.run_record.setdefault("coverage_quality", {})
        quality["auto_unauditable_cleared"] = result.get("cleared", 0)
        quality["auto_unauditable_files"] = result.get("files") or []
    except Exception:
        logger.exception("recording unauditable-sweep telemetry failed (non-fatal)")


def _record_source_coverage(*, total: int, unowned: list[str], capped: bool) -> None:
    """Stash the filesystem-coverage gap into run.json telemetry (non-fatal)."""
    try:
        from talon.report.state import get_global_report_state

        state = get_global_report_state()
        if state is None:
            return
        quality = state.run_record.setdefault("coverage_quality", {})
        quality["source_files_total"] = total
        quality["source_files_unowned"] = len(unowned)
        quality["source_walk_capped"] = capped
    except Exception:
        logger.exception("recording source-coverage telemetry failed (non-fatal)")


def _do_finish(
    *,
    parent_id: str | None,
    executive_summary: str,
    methodology: str,
    technical_analysis: str,
    recommendations: str,
) -> dict[str, Any]:
    if parent_id is not None:
        return {
            "success": False,
            "error": (
                "This tool can only be used by the root/main agent. "
                "If you are a subagent, use agent_finish instead"
            ),
        }

    errors: list[str] = []
    if not executive_summary.strip():
        errors.append("Executive summary cannot be empty")
    if not methodology.strip():
        errors.append("Methodology cannot be empty")
    if not technical_analysis.strip():
        errors.append("Technical analysis cannot be empty")
    if not recommendations.strip():
        errors.append("Recommendations cannot be empty")
    if errors:
        return {"success": False, "error": "Validation failed", "errors": errors}

    try:
        from talon.report.state import get_global_report_state

        report_state = get_global_report_state()
        if report_state is None:
            logger.warning("No global report state; scan results not persisted")
            return {
                "success": True,
                SCAN_COMPLETED_KEY: True,
                "message": "Scan completed (not persisted)",
                "warning": "Results could not be persisted - report state unavailable",
            }
        try:
            from talon.tools.coverage.tools import coverage_quality_stats

            stats = coverage_quality_stats()
            report_state.run_record["coverage_quality"] = stats
            logger.info("coverage disposition quality: %s", stats)
        except Exception:
            logger.exception("coverage quality stats failed (non-fatal)")
        report_state.update_scan_final_fields(
            executive_summary=executive_summary.strip(),
            methodology=methodology.strip(),
            technical_analysis=technical_analysis.strip(),
            recommendations=recommendations.strip(),
        )
        vuln_count = len(report_state.vulnerability_reports)
    except (ImportError, AttributeError) as e:
        logger.exception("finish_scan: persistence failed")
        return {"success": False, "error": f"Failed to complete scan: {e!s}"}
    else:
        logger.info(
            "finish_scan: completed scan with %d vulnerability report(s)",
            vuln_count,
        )
        return {
            "success": True,
            SCAN_COMPLETED_KEY: True,
            "message": "Scan completed successfully",
            "vulnerabilities_found": vuln_count,
        }


@function_tool(timeout=60)
async def finish_scan(
    ctx: RunContextWrapper,
    executive_summary: str,
    methodology: str,
    technical_analysis: str,
    recommendations: str,
) -> str:
    """Finalize the scan — persist the customer-facing report.

    **Root-agent only.** Subagents must call ``agent_finish`` from the
    multi-agent graph tools instead. Calling this finalizes everything:

    1. Verifies you are the root agent.
    2. Writes the four narrative sections to the scan record.
    3. Marks the scan completed and stops execution.

    **Pre-flight checklist (mandatory — do not skip):**

    1. **Call ``view_agent_graph`` first.** Inspect every entry in the
       summary. If ANY agent is in ``running`` / ``waiting`` state,
       you MUST NOT call ``finish_scan`` yet —
       wrap them up first via ``send_message_to_agent`` (ask them to
       finish), ``wait_for_message`` (block until their report
       arrives), or ``stop_agent`` (graceful cancel). Only ``completed``
       / ``crashed`` / ``stopped`` agents are safe to leave behind.
       Calling ``finish_scan`` while children are alive orphans their
       work and produces an incomplete report.
    2. All vulnerabilities you found are filed via
       ``create_vulnerability_report`` (un-reported findings are not
       tracked and not credited).
    3. Don't double-report — one report per distinct vulnerability.

    **Calling this multiple times overwrites the previous report.**
    Make the single call comprehensive.

    **Customer-facing report rules** (this output is rendered into the
    final PDF the client sees):

    - Never mention internal infrastructure: no local/absolute paths
      (``/workspace/...``), no agent names, no sandbox/orchestrator/
      tooling references, no system prompts, no model-internal errors.
    - Tone: formal, third-person, objective, concise. This is a
      consultant deliverable, not an engineering log.
    - Each section has a specific role:

        - ``executive_summary`` — for non-technical leadership. Risk
          posture, business impact (data exposure / compliance /
          reputation), notable criticals, overarching remediation
          theme.
        - ``methodology`` — frameworks followed (OWASP WSTG, PTES,
          OSSTMM, NIST), engagement type (black/gray/white box), scope
          and constraints, categories of testing performed. **No**
          internal execution detail.
        - ``technical_analysis`` — consolidated findings overview with
          severity model and systemic root causes. Reference individual
          vuln reports for repro steps; don't duplicate raw evidence.
        - ``recommendations`` — prioritized actions grouped by urgency
          (Immediate / Short-term / Medium-term), each with concrete
          remediation steps. End with retest/validation guidance.

    Args:
        executive_summary: Business-level summary for leadership.
        methodology: Frameworks, scope, and approach.
        technical_analysis: Consolidated findings + systemic themes.
        recommendations: Prioritized, actionable remediation.
    """
    inner = ctx.context if isinstance(ctx.context, dict) else {}
    coordinator = coordinator_from_context(inner)
    me = inner.get("agent_id")
    parent_id = inner.get("parent_id")
    if coordinator is not None and parent_id is None and me is not None:
        active_agents = await coordinator.active_agents_except(me)
    else:
        active_agents = []

    if active_agents:
        logger.debug(
            "finish_scan: blocked — %d agent(s) still active: %s",
            len(active_agents),
            ", ".join(f"{a['name']}({a['agent_id']})={a['status']}" for a in active_agents),
        )
        return json.dumps(
            {
                "success": False,
                SCAN_COMPLETED_KEY: False,
                "error": (
                    "Cannot finish scan while child agents are still active. "
                    "Wait for completion, send them finish instructions, or stop them first"
                ),
                "active_agents": active_agents,
            },
            ensure_ascii=False,
            default=str,
        )

    is_whitebox = bool(inner.get("is_whitebox"))
    scan_mode = str(inner.get("scan_mode") or "deep")
    # Break the minified-artifact deadlock before gating: clear only machine-verified build
    # artifacts, leaving real source pending for the gate below.
    await _auto_sweep_unauditable(
        inner, parent_id=parent_id, is_whitebox=is_whitebox, scan_mode=scan_mode
    )
    gate = _coverage_gate(parent_id=parent_id, is_whitebox=is_whitebox, scan_mode=scan_mode)
    if gate is not None:
        return json.dumps(gate, ensure_ascii=False, default=str)

    source_gate = await _source_coverage_check(
        inner, parent_id=parent_id, is_whitebox=is_whitebox, scan_mode=scan_mode
    )
    if source_gate is not None:
        return json.dumps(source_gate, ensure_ascii=False, default=str)

    result = await asyncio.to_thread(
        _do_finish,
        parent_id=parent_id,
        executive_summary=executive_summary,
        methodology=methodology,
        technical_analysis=technical_analysis,
        recommendations=recommendations,
    )
    if (
        result.get("success")
        and result.get(SCAN_COMPLETED_KEY)
        and coordinator is not None
        and isinstance(me, str)
    ):
        await coordinator.set_status(me, "completed", reason="finish_scan")
    return json.dumps(result, ensure_ascii=False, default=str)

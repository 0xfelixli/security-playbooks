"""Map a semgrep JSON report's *findings* into classed coverage signal units.

Turns security-category results into ``kind=sink`` units carrying a ``vulnerability_class``
and ``confidence`` so the recall gate pulls them into review. The class mapping is grounded
in CWE definitions and generic rule-id keywords, never a specific target's findings
(no-overfit). Only high/medium findings are promoted; results dedupe per (file, class,
line) so distinct sites stay separate obligations; the total is capped (logged) so a noisy
report can't flood the gate.
"""

from __future__ import annotations

from typing import Any


# CWE number -> talon vulnerability_class, from CWE definitions (target-agnostic). Values
# reuse the scanner's existing class vocabulary so dedupe/reporting stay consistent.
_CWE_TO_CLASS: dict[str, str] = {
    "79": "XSS",
    "80": "XSS",
    "83": "XSS",
    "89": "SQL_INJECTION",
    "564": "SQL_INJECTION",
    "943": "NOSQL_INJECTION",
    "77": "RCE",
    "78": "RCE",
    "94": "RCE",
    "95": "RCE",
    "22": "PATH_TRAVERSAL",
    "23": "PATH_TRAVERSAL",
    "36": "PATH_TRAVERSAL",
    "98": "PATH_TRAVERSAL",
    "918": "SSRF",
    "601": "OPEN_REDIRECT",
    "611": "XXE",
    "776": "XXE",
    "502": "INSECURE_DESERIALIZATION",
    "1321": "PROTOTYPE_POLLUTION",
    "326": "WEAK_CRYPTO",
    "327": "WEAK_CRYPTO",
    "328": "WEAK_CRYPTO",
    "916": "WEAK_CRYPTO",
    "759": "WEAK_CRYPTO",
    "760": "WEAK_CRYPTO",
    "259": "HARDCODED_CREDENTIALS",
    "798": "HARDCODED_CREDENTIALS",
    "306": "MISSING_AUTHENTICATION",
    "285": "BFLA",
    "862": "BFLA",
    "863": "BFLA",
    "639": "IDOR",
    "352": "CSRF",
    "915": "MASS_ASSIGNMENT",
    "400": "REGEX_DOS",
    "1333": "REGEX_DOS",
    "90": "LDAP_INJECTION",
    "1236": "CSV_INJECTION",
    "319": "INSECURE_TRANSPORT",
    "295": "INSECURE_TRANSPORT",
    "614": "COOKIE_FLAGS",
    "1004": "COOKIE_FLAGS",
    "345": "JWT_VALIDATION",
    "347": "JWT_VALIDATION",
    "312": "PLAINTEXT_PASSWORD_STORAGE",
    "313": "PLAINTEXT_PASSWORD_STORAGE",
    "522": "PLAINTEXT_PASSWORD_STORAGE",
    "117": "LOG_INJECTION",
    "532": "LOG_INJECTION",
    "384": "SESSION_FIXATION",
    "434": "ARBITRARY_FILE_WRITE",
    "73": "PATH_TRAVERSAL",
    "116": "XSS",
    "20": "SECURITY_MISCONFIG",
    "88": "RCE",
    "200": "EXPOSURE",
    "209": "EXPOSURE",
    "668": "EXPOSURE",
    "287": "MISSING_AUTHENTICATION",
    "269": "BFLA",
    "732": "SECURITY_MISCONFIG",
    "942": "SECURITY_MISCONFIG",
    "16": "SECURITY_MISCONFIG",
    "362": "RACE_CONDITION",
    "367": "RACE_CONDITION",
    "330": "WEAK_CRYPTO",
    "338": "WEAK_CRYPTO",
    "256": "PLAINTEXT_PASSWORD_STORAGE",
    "311": "INSECURE_TRANSPORT",
    "1275": "COOKIE_FLAGS",
}

# Rule-id substring -> class, used only when no CWE resolves. Generic keywords, first
# match wins, so order longer/more-specific tokens before broad ones.
_CHECKID_KEYWORDS: tuple[tuple[str, str], ...] = (
    ("dangerouslysetinnerhtml", "XSS"),
    ("sql-injection", "SQL_INJECTION"),
    ("sqli", "SQL_INJECTION"),
    ("nosql", "NOSQL_INJECTION"),
    ("command-injection", "RCE"),
    ("code-injection", "RCE"),
    ("template-injection", "SSTI"),
    ("ssti", "SSTI"),
    ("ssrf", "SSRF"),
    ("open-redirect", "OPEN_REDIRECT"),
    ("open_redirect", "OPEN_REDIRECT"),
    ("path-traversal", "PATH_TRAVERSAL"),
    ("pathtraversal", "PATH_TRAVERSAL"),
    ("deserial", "INSECURE_DESERIALIZATION"),
    ("prototype", "PROTOTYPE_POLLUTION"),
    ("xxe", "XXE"),
    ("csrf", "CSRF"),
    ("hardcoded", "HARDCODED_CREDENTIALS"),
    ("weak-hash", "WEAK_CRYPTO"),
    ("weak-crypto", "WEAK_CRYPTO"),
    ("insecure-transport", "INSECURE_TRANSPORT"),
    ("jwt", "JWT_VALIDATION"),
    ("cookie", "COOKIE_FLAGS"),
    ("regex", "REGEX_DOS"),
    ("mass-assignment", "MASS_ASSIGNMENT"),
    ("xss", "XSS"),
    ("redirect", "OPEN_REDIRECT"),
)

# A security finding whose class we cannot resolve still gates — a security-category
# ERROR must not be silently dropped just because it is unmapped.
_FALLBACK_CLASS = "SEMGREP_SECURITY"

_CONFIDENCE_RANK = {"high": 3, "medium": 2, "low": 1}
_SEVERITY_TO_CONFIDENCE = {"ERROR": "high", "WARNING": "medium", "INFO": "low"}
# Default cap on promoted signal units so a huge report cannot make the gate unpassable.
DEFAULT_SIGNAL_CAP = 1500


def _as_dict(value: Any) -> dict[str, Any]:
    """Coerce an untrusted JSON value to a dict."""
    return value if isinstance(value, dict) else {}


def _cwe_digits(entry: Any) -> str:
    """Leading CWE number of an entry like ``"CWE-79: ..."`` or ``79`` (else "")."""
    head = str(entry).split(":", 1)[0]
    return "".join(ch for ch in head if ch.isdigit())


def _class_for(check_id: str, cwe_list: Any) -> str | None:
    if isinstance(cwe_list, list):
        for entry in cwe_list:
            cls = _CWE_TO_CLASS.get(_cwe_digits(entry))
            if cls:
                return cls
    cid = check_id.lower()
    for keyword, cls in _CHECKID_KEYWORDS:
        if keyword in cid:
            return cls
    return None


def _confidence_of(extra: dict[str, Any], metadata: dict[str, Any]) -> str:
    conf = str(metadata.get("confidence") or "").strip().lower()
    if conf in _CONFIDENCE_RANK:
        return conf
    severity = str(extra.get("severity") or "").strip().upper()
    return _SEVERITY_TO_CONFIDENCE.get(severity, "low")


def _is_security(metadata: dict[str, Any]) -> bool:
    if str(metadata.get("category") or "").strip().lower() == "security":
        return True
    return bool(metadata.get("cwe")) or bool(metadata.get("owasp"))


def semgrep_findings_to_units(
    data: Any, *, cap: int = DEFAULT_SIGNAL_CAP
) -> tuple[list[dict[str, Any]], dict[str, int]]:
    """Promote a parsed semgrep report's security findings to classed sink units.

    Returns ``(units, stats)``. Units are ``kind=sink`` with ``vulnerability_class`` and
    ``confidence`` set; ``stats`` reports what was seen, kept, and dropped for logging.
    Deterministic: deduped by (path, class, line) keeping the highest-confidence hit; if
    over ``cap``, highest-confidence units are kept and the overflow reported in
    ``stats['capped']``.
    """
    stats = {
        "results": 0,
        "kept": 0,
        "dropped_nonsecurity": 0,
        "dropped_low": 0,
        "dropped_no_path": 0,
        "capped": 0,
    }
    results = data.get("results") if isinstance(data, dict) else None
    if not isinstance(results, list):
        return [], stats

    by_key: dict[tuple[str, str, int], dict[str, Any]] = {}
    for result in results:
        if not isinstance(result, dict):
            continue
        stats["results"] += 1
        extra = _as_dict(result.get("extra"))
        metadata = _as_dict(extra.get("metadata"))
        if not _is_security(metadata):
            stats["dropped_nonsecurity"] += 1
            continue
        confidence = _confidence_of(extra, metadata)
        if confidence == "low":
            # Low/info security hits stay as plain file coverage — surfacing them as
            # blocking obligations would flood the gate with the report's long tail.
            stats["dropped_low"] += 1
            continue
        path = str(result.get("path") or "").strip()
        if not path:
            stats["dropped_no_path"] += 1
            continue
        check_id = str(result.get("check_id") or "")
        cls = _class_for(check_id, metadata.get("cwe")) or _FALLBACK_CLASS
        start = _as_dict(result.get("start"))
        try:
            line = int(start.get("line") or 0)
        except (TypeError, ValueError):
            line = 0
        location = f"{path}:{line}" if line else path
        key = (path, cls, line)
        existing = by_key.get(key)
        if (
            existing is not None
            and _CONFIDENCE_RANK[confidence]
            <= _CONFIDENCE_RANK[str(existing.get("confidence") or "low")]
        ):
            continue
        rule_tail = check_id.rsplit(".", 1)[-1] or "semgrep"
        by_key[key] = {
            "kind": "sink",
            "location": location,
            "title": f"{cls} — semgrep {rule_tail}",
            "vulnerability_class": cls,
            "confidence": confidence,
            "construct_type": "semgrep_finding",
            "evidence": {"check_id": check_id, "line": str(extra.get("lines") or "")[:180]},
        }

    units = list(by_key.values())
    if len(units) > cap:
        units.sort(key=lambda u: _CONFIDENCE_RANK[str(u.get("confidence") or "low")], reverse=True)
        stats["capped"] = len(units) - cap
        units = units[:cap]
    stats["kept"] = len(units)
    return units, stats

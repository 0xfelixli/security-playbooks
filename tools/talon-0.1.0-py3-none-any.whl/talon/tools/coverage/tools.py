"""Coverage manifest — scan-wide attack-surface units, mirrored to {state_dir}/coverage.json.

The manifest turns "did we review the whole attack surface?" from an LLM judgement into a
countable, gate-able checklist. Recon enumerates units (routes, handlers, sinks, contract
functions, entrypoints); every unit must be explicitly *dispositioned* (``reviewed`` or
``ruled_out``) before ``finish_scan`` is allowed.

Storage is scan-wide (like ``notes``, not ``todo``): coverage is a property of the whole
scan, and every agent contributes to and reads the same manifest.
"""

from __future__ import annotations

import asyncio
import json
import logging
import posixpath
import re
import shlex
import uuid
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any

from agents import RunContextWrapper, function_tool

from talon.tools.coverage.semgrep_seed import semgrep_findings_to_units
from talon.tools.state_store import PersistentJsonStore


if TYPE_CHECKING:
    from pathlib import Path


logger = logging.getLogger(__name__)


# The recall gate keys on a unit's ROLE, not its raw ``kind``. ``role_of`` derives this closed
# 3-value axis from ``kind`` — derived, never stored, so ``kind`` stays the dedup/resume key.
ROLE_ENTRY = "entry"
ROLE_SINK = "sink"
ROLE_FILE = "file"
_KIND_TO_ROLE = {
    "route": ROLE_ENTRY,
    "handler": ROLE_ENTRY,
    "entrypoint": ROLE_ENTRY,
    "contract_fn": ROLE_ENTRY,
    "sink": ROLE_SINK,
    "file": ROLE_FILE,
}
# Derived from the role map so a new kind can't be added without a role (else role_of returns
# None and the unit escapes every gate dimension).
VALID_KINDS = tuple(_KIND_TO_ROLE)
# Synthetic lens for classless entrypoints (cobra CLI / lambda): without it they vanish from
# the lens dashboard, leaving the coordinator no perspective to dispatch. Review intent lives
# in coordination/root_agent.md.
ENTRYPOINT_LENS = "ENTRYPOINT_REVIEW"


def is_synthetic_lens(value: str) -> bool:
    """Whether a lens label is the synthetic entrypoint placeholder vs a real
    vulnerability_class — lets the dashboard mark it apart."""
    return value == ENTRYPOINT_LENS


# "pending" blocks finish_scan; the two terminal dispositions clear the gate.
VALID_DISPOSITIONS = ["reviewed", "ruled_out"]
PENDING_STATUS = "pending"
# A confidence typo would fall through the high/medium blocking set and silently downgrade a
# hi-sig unit to advisory, so validate_unit rejects anything outside this set.
_CONFIDENCE_VALUES = frozenset({"high", "medium", "low"})
_REQUIRED_DISPOSITION_FIELDS = ("decision", "evidence", "checked")
# Ruling OUT a blocking unit demands one more field than marking it reviewed: an
# adversarial ``refutation`` (strongest case FOR the bug being real, then why it fails).
# This makes the exhaustive_sweeps Rule 5 Finder→Challenger→Judge step a hard requirement
# so ``ruled_out`` cannot rubber-stamp a false negative.
_REQUIRED_RULED_OUT_FIELDS = ("refutation",)

# Blocking constructs with no single code location (whole-scan gaps like scan_cap): still
# need a structured note, but exempt from the "cite a real file:line" rule below.
_LOCATIONLESS_CONSTRUCTS = frozenset({"scan_cap"})

# --- Structurally-unauditable escape (recall-safe) ---------------------------------------
# A blocking unit seeded onto a build artifact (a minified webpack chunk / vendored bundle)
# can never be given a resolving file:line, so it would block the gate forever. Such a file
# may be cleared ONLY on a DOUBLE proof, both halves machine-checked, fail-closed toward
# review: (1) its path/name marks it generated/bundled, AND (2) the sandbox measures a
# minified structure (one line far longer than hand-written source). Real source — anything
# missing either half — is never cleared; it stays pending for the gate to block on. Kept in
# sync with the inventory scanner's SKIP_DIRS: this is the runtime net for whatever slips
# past seed-time exclusion.
_GENERATED_PATH_PARTS = frozenset(
    {"node_modules", "vendor", "dist", "build", "out", ".next", "_next", ".output"}
)
_MINIFIED_NAME_SUFFIXES = (".min.js", ".bundle.js", "-bundle.js")
# Longest-line threshold for "minified". Hand-written source effectively never exceeds this;
# a webpack chunk runs to tens of thousands of chars. Paired with the path/name check so a
# long-lined data file living in real source is NOT auto-skipped.
_MINIFIED_MAX_LINE_LEN = 2000


def _has_generated_marker(path: str) -> bool:
    """The naming half of the unauditable double-proof: a build-output/vendor path component
    or a minified-bundle filename. Necessary but not sufficient — the sandbox must ALSO
    measure a minified structure before a file is treated as unauditable."""
    parts = path.split("/")
    if any(part in _GENERATED_PATH_PARTS for part in parts):
        return True
    name = parts[-1] if parts else path
    return name.endswith(_MINIFIED_NAME_SUFFIXES)


# Anti-batch-rubber-stamp: a single mark_unit_reviewed call may disposition blocking units
# spanning at most this many distinct source files. One shared note citing one file cannot
# honestly evidence review of hundreds of routes across hundreds of files (the failure mode
# observed in practice). Same-file batches (many units in one file) are unaffected — the cap
# is on distinct *files*, not units. Systemic coverage that legitimately spans files goes
# through the ``covered_by_report`` channel, which is exempt (and single-class constrained).
_MAX_BLOCKING_FILES_PER_CALL = 8
# Log a WARNING when one call dispositions at least this many blocking units, so a suspicious
# bulk disposition is visible in the default log even when it clears the (file-scoped) rules.
_BULK_DISPOSITION_WARN = 20


def unit_is_blocking(unit: dict[str, Any]) -> bool:
    """Explicit ``blocking`` flag: an integrity marker (unparsed-source / scan-cap) gates
    finish on its own, without faking a vulnerability_class. The finish gate imports this."""
    return bool(unit.get("blocking"))


# A file carrying at least this many coverage units is "high density". LLM recall degrades
# sharply as units-per-file rises (a single pass under-reports), so these files warrant a
# dedicated fresh-context re-sweep. Generic threshold — not tuned to any benchmark.
_HIGH_DENSITY_THRESHOLD = 5
_DEFAULT_LIST_LIMIT = 50
_MAX_LIST_LIMIT = 200
# Full unit records (include_details=true) are several hundred bytes each and every tool
# output is replayed into the agent's context every turn, so the detail page is capped far
# below the slim page — repeated fat pages accumulating in history once exhausted context.
_MAX_DETAIL_LIMIT = 20
# Slim projection returned by default: what an agent needs to select, disposition, and
# partition units — nothing more. Fields absent from a unit are omitted, not nulled.
_SLIM_UNIT_FIELDS = ("kind", "location", "status", "vulnerability_class", "construct_type")

_store = PersistentJsonStore("coverage.json")


def hydrate_coverage_from_disk(state_dir: Path) -> None:
    """Point storage at ``{state_dir}/coverage.json`` and load any prior state.

    Called once per scan from the runner so a resumed scan keeps its manifest and the gate
    still sees prior pending units.
    """
    raw = _store.bind(state_dir)
    if raw is None:
        return
    with _store.lock:
        coerced = 0
        for uid, unit in raw.items():
            if not (isinstance(uid, str) and isinstance(unit, dict)):
                continue
            # hydrate bypasses _normalize_one_unit, so re-run the invariant check — a
            # hand-edited/version-skewed manifest could otherwise inject a gate-escaping unit.
            # An invalid unit is coerced to a blocking obligation so it surfaces rather than
            # vanishing, and resume never crashes on one bad unit.
            stored = unit
            try:
                validate_unit(unit)
            except (ValueError, TypeError) as exc:
                # Expected, handled case — error (not exception): the message + coercion are
                # the signal, a stack trace would be noise.
                logger.error(  # noqa: TRY400
                    "coverage hydrate: unit %s failed validation (%s); coercing to a blocking "
                    "obligation so it cannot silently escape the recall gate",
                    uid,
                    exc,
                )
                stored = {**unit, "blocking": True}
                coerced += 1
            _store.data[uid] = stored
        loaded = len(_store.data)
    if coerced:
        logger.warning("coverage hydrate: %d invalid unit(s) coerced to blocking", coerced)
    logger.info(
        "coverage manifest hydrated from %s (%d unit(s))",
        _store.path,
        loaded,
    )


def _unit_dedupe_key(
    kind: str,
    location: str,
    construct_type: str | None = None,
    vulnerability_class: str | None = None,
) -> str:
    return "::".join(
        [
            kind.strip().lower(),
            location.strip(),
            (construct_type or "").strip().lower(),
            (vulnerability_class or "").strip().upper(),
        ]
    )


def _existing_keys() -> dict[str, str]:
    """Map dedupe-key -> unit_id for everything already in the manifest."""
    return {
        _unit_dedupe_key(
            unit.get("kind", ""),
            unit.get("location", ""),
            unit.get("construct_type"),
            unit.get("vulnerability_class"),
        ): uid
        for uid, unit in _store.data.items()
    }


def validate_unit(unit: dict[str, Any]) -> None:
    """Enforce the gate-bearing discriminant invariants; raise ``ValueError`` on any failure.
    Applied on every write AND on hydrate, so a resumed or hand-edited ``coverage.json`` can't
    inject a gate-escaping unit past the seed-time checks.
    """
    kind = str(unit.get("kind") or "").strip().lower()
    if kind not in VALID_KINDS:
        raise ValueError(f"Invalid kind '{kind}'. Must be one of: {', '.join(VALID_KINDS)}")
    if not str(unit.get("location") or "").strip():
        raise ValueError("Each unit must include a non-empty 'location'")
    # A sink gates only via its vulnerability_class, so a classless sink escapes every gate
    # dimension. Reject fail-closed: name the danger class, or register under an entry kind.
    if kind == "sink" and not str(unit.get("vulnerability_class") or "").strip():
        raise ValueError(
            "A 'sink' unit must carry a non-empty 'vulnerability_class' (a classless sink "
            "would silently escape the recall gate). Name the danger class, e.g. SQL_INJECTION."
        )
    confidence = unit.get("confidence")
    conf = str(confidence).strip().lower() if confidence is not None else ""
    if conf and conf not in _CONFIDENCE_VALUES:
        raise ValueError(
            f"Invalid confidence '{confidence}'. Must be high/medium/low — a typo here silently "
            "downgrades a high-signal unit to advisory (non-blocking) at the recall gate."
        )
    status = unit.get("status")
    stat = str(status).strip().lower() if status is not None else ""
    if stat and stat not in (*VALID_DISPOSITIONS, PENDING_STATUS):
        raise ValueError(
            f"Invalid status '{status}'. Must be one of: {PENDING_STATUS}, "
            f"{', '.join(VALID_DISPOSITIONS)}."
        )
    blocking = unit.get("blocking")
    if blocking is not None and not isinstance(blocking, bool):
        raise ValueError("'blocking' must be a boolean (an integrity marker gates on it).")


def _normalize_one_unit(item: Any) -> dict[str, Any]:
    """Validate and normalize a single unit dict (kind/location/title + field cleanup)."""
    if not isinstance(item, dict):
        raise TypeError("Each unit must be an object with 'kind' and 'location'")
    location = str(item.get("location", "")).strip()
    unit = dict(item)
    unit.update(
        {
            "kind": str(item.get("kind", "")).strip().lower(),
            "location": location,
            "title": str(item.get("title", "")).strip() or location,
        }
    )
    for key in ("construct_type", "vulnerability_class", "framework", "confidence"):
        if key in unit and unit[key] is not None:
            unit[key] = str(unit[key]).strip()
    if "blocking" in unit:
        unit["blocking"] = bool(unit["blocking"])
    validate_unit(unit)  # single source of the discriminant invariants
    return unit


def _normalize_units(raw_units: Any) -> list[dict[str, Any]]:
    """Accept a JSON string, a list of dicts, or a single dict — like ``todo``."""
    if raw_units is None:
        return []
    data: Any = raw_units
    if isinstance(raw_units, str):
        stripped = raw_units.strip()
        if not stripped:
            return []
        try:
            data = json.loads(stripped)
        except json.JSONDecodeError as e:
            raise ValueError("Units must be valid JSON") from e
    if isinstance(data, dict):
        data = [data]
    if not isinstance(data, list):
        raise TypeError("Units must be a list of unit objects")
    return [_normalize_one_unit(item) for item in data]


def _normalize_ids(raw_ids: Any) -> list[str]:
    if raw_ids is None:
        return []
    if isinstance(raw_ids, str):
        stripped = raw_ids.strip()
        if not stripped:
            return []
        try:
            data = json.loads(stripped)
        except json.JSONDecodeError:
            data = stripped.split(",") if "," in stripped else [stripped]
        if isinstance(data, list):
            return [str(item).strip() for item in data if str(item).strip()]
        return [str(data).strip()]
    if isinstance(raw_ids, list):
        return [str(item).strip() for item in raw_ids if str(item).strip()]
    return [str(raw_ids).strip()]


def role_of(unit: dict[str, Any]) -> str | None:
    """The unit's coverage role (``ROLE_ENTRY``/``ROLE_SINK``/``ROLE_FILE``), derived from its
    stored ``kind``. ``None`` for an unknown/blank kind. Never stored — kind is the source of
    truth, so this adds no persistence/dedup surface."""
    return _KIND_TO_ROLE.get(str(unit.get("kind") or "").strip().lower())


def is_entry(unit: dict[str, Any]) -> bool:
    """The attack-surface entry dimension the recall gate blocks on — the umbrella predicate
    that replaces hand-testing ``kind in ENTRYPOINT_KINDS`` (so ``entrypoint`` as a kind leaf no
    longer reads the same as the entry dimension)."""
    return role_of(unit) == ROLE_ENTRY


def _requires_structured_note(unit: dict[str, Any]) -> bool:
    """Whether a unit's disposition must be an auditable structured note.

    True for the blocking tiers — high-signal units (with a ``vulnerability_class``),
    entry-role units (route/handler/entrypoint/contract_fn) even without a class, and
    explicit ``blocking`` integrity markers — so the gate can't be cleared with a bare
    "looks fine". Low-signal file units stay free-text.
    """
    if str(unit.get("vulnerability_class") or "").strip():
        return True
    if unit_is_blocking(unit):
        return True
    return is_entry(unit)


@dataclass(frozen=True)
class Lens:
    """A review perspective a unit dispatches under. ``synthetic`` marks the ``ENTRYPOINT_LENS``
    placeholder apart from a real ``vulnerability_class`` so hi-sig accounting and the dashboard
    can tell them apart."""

    value: str
    synthetic: bool


def lens_of(unit: dict[str, Any]) -> Lens | None:
    """The review lens a unit dispatches under, for the dashboard and slice planning.

    A real ``vulnerability_class`` when the unit carries one; else the synthetic
    ``ENTRYPOINT_LENS`` for a classless entrypoint (so it still gets a perspective and shows
    pending); else ``None`` (a bare file fallback). Synthetic lenses do NOT feed the hi-sig
    tally — callers key that off ``synthetic``.
    """
    vuln_class = str(unit.get("vulnerability_class") or "").strip()
    if vuln_class:
        return Lens(vuln_class, synthetic=False)
    if is_entry(unit):
        return Lens(ENTRYPOINT_LENS, synthetic=True)
    return None


def _missing_fields_error(data: dict[str, Any], status: str) -> str | None:
    """Message naming any required structured field the note omits, else ``None``."""
    required: tuple[str, ...] = _REQUIRED_DISPOSITION_FIELDS
    if status == "ruled_out":
        required = required + _REQUIRED_RULED_OUT_FIELDS
    missing = [field for field in required if not str(data.get(field) or "").strip()]
    if not missing:
        return None
    if "refutation" in missing:
        return (
            f"Disposition note missing required field(s): {', '.join(missing)}. "
            "Ruling out a blocking unit requires a 'refutation' "
            "field: state the STRONGEST case for the bug being real (the exploit "
            "path a Finder would build), then explain concretely why it fails "
            "(the Challenger→Judge step of exhaustive_sweeps Rule 5). A bare "
            "'looks fine' is not a refutation."
        )
    return f"Disposition note missing required field(s): {', '.join(missing)}"


def _missing_other_classes_error(data: dict[str, Any]) -> str | None:
    """Message when a located, non-systemic disposition omits ``other_classes_checked``.

    Rule 1 of ``exhaustive_sweeps`` says one site often carries several independent bugs,
    but nothing previously forced that check past the ONE candidate a unit already names.
    Mirrors the ``refutation`` field: non-empty is the whole check, same rigor as the rest
    of this module — real teeth come from the adversarial Challenger/Judge pass, not from
    grading this field's prose.
    """
    if str(data.get("other_classes_checked") or "").strip():
        return None
    return (
        "Disposition note missing required field 'other_classes_checked': at this exact "
        "site, name the OTHER vulnerability classes you considered (see "
        "`coordination/exhaustive_sweeps` Rule 1 — one site often carries several "
        "independent bugs) and why each does not apply, or state 'none plausible for this "
        "construct' if the site's shape genuinely rules them out. Repeating this unit's own "
        "class is not a check of OTHER classes."
    )


def _validate_disposition_note(  # noqa: PLR0911
    unit: dict[str, Any], note: str, status: str, *, covered_by_report: bool = False
) -> str | None:
    """Require structured, location-backed evidence for blocking units.

    Low-signal file units keep free-text notes. Blocking units need a JSON note with
    decision/evidence/checked AND at least one real ``file:line`` (existence-checked by
    ``_validate_note_locations``); ``ruled_out`` also needs an adversarial ``refutation``.
    ``_LOCATIONLESS_CONSTRUCTS`` markers skip the location rule.

    Unless ``covered_by_report`` (systemic-coverage channel), a blocking unit with a
    concrete source file must be evidenced against *that* file — a shared note citing an
    unrelated file cannot clear it. This is what stops one note from batch-clearing units
    spread across many files.

    That same non-systemic, located case must also name ``other_classes_checked`` — the
    other vulnerability classes considered at this exact site — so closing the ONE candidate
    a unit names does not silently skip the rest of Rule 1.
    """
    if not _requires_structured_note(unit):
        return None
    try:
        data = json.loads(note)
    except json.JSONDecodeError:
        return (
            "This coverage unit is a blocking obligation (it carries a vulnerability_class "
            "or is an enumerated entrypoint), so it requires a JSON disposition note with "
            "decision, evidence, and checked fields"
        )
    if not isinstance(data, dict):
        return "Disposition note must be a JSON object"
    fields_error = _missing_fields_error(data, status)
    if fields_error is not None:
        return fields_error
    locationless = str(unit.get("construct_type") or "").strip().lower() in _LOCATIONLESS_CONSTRUCTS
    if locationless or covered_by_report:
        return None
    # Anti-rubber-stamp: a blocking disposition must cite real code, not just prose.
    if not _extract_note_locations(note):
        return (
            "Disposition note must cite at least one concrete file:line you actually "
            "reviewed (e.g. the source and the sink) inside 'evidence' (or 'refutation' "
            "when ruling out). A disposition with no code location is a rubber stamp — "
            "re-read the code and cite the exact location(s)."
        )
    # Anti-batch-rubber-stamp: the note must cite THIS unit's own source file, so a single
    # note cannot honestly clear units belonging to files it never touched.
    if not _note_cites_own_file(unit, note):
        own = _unit_own_file(unit)
        return (
            f"Disposition note does not cite this unit's own source file ({own}). A blocking "
            "unit must be evidenced against its own code — cite a concrete "
            f"{own}:line you actually reviewed inside 'evidence' (or 'refutation' when ruling "
            "out). One shared note cannot clear units across unrelated files; disposition "
            "each file's units with evidence from that file, or use covered_by_report for a "
            "genuinely systemic finding."
        )
    return _missing_other_classes_error(data)


# A repo-relative path with a file extension, followed by ``:line`` (optionally
# ``:start-end``). Matches the source/sink triple the disposition-note convention asks
# for (e.g. ``views.py:42``, ``app/utils/redirect.py:88-90``). Deliberately requires an
# extension so tokens like ``msg:sender`` or ``http://…`` are not mistaken for locations.
#
# The second alternative carves out the extensionless build-file family (``Dockerfile`` /
# ``docker/pg/Dockerfile`` / ``Dockerfile.prod``) so a Dockerfile entrypoint unit can be
# dispositioned. Kept in sync with ``_unit_own_file``'s ``startswith("Dockerfile")`` special
# case: without it, that carve-out makes ``own_file`` recognise a Dockerfile while this
# extractor cannot, so an enumerated Dockerfile entrypoint could NEVER be given a citation
# the gate accepts — deadlocking the recall gate forever.
_FILE_LINE_RE = re.compile(
    r"(?<![\w/])([\w./\-]+\.[A-Za-z0-9]+|[\w./\-]*Dockerfile(?:\.[\w\-]+)?):(\d+)(?:-(\d+))?"
)
_MAX_LOCATION_CHECKS = 25


def _extract_note_locations(note: str) -> list[tuple[str, int, int]]:
    """Pull ``file:line`` / ``file:start-end`` references out of a disposition note.

    Deduped, capped, and defensive — this is a best-effort audit of the evidence the
    agent cites, not a parser of a rigid schema.
    """
    seen: dict[tuple[str, int, int], None] = {}
    for m in _FILE_LINE_RE.finditer(note):
        path = m.group(1)
        if ".." in path or path.startswith("/"):
            continue
        start = int(m.group(2))
        end = int(m.group(3)) if m.group(3) else start
        if start < 1 or end < start:
            continue
        seen.setdefault((path, start, end), None)
        if len(seen) >= _MAX_LOCATION_CHECKS:
            break
    return list(seen.keys())


# A unit location whose file part carries an extension (``foo.py:42`` → ``foo.py``) has a
# concrete source file the disposition must be anchored to. Route-string locations
# (``/api/users/{id}``) and locationless markers have none, so the own-file rule is skipped
# for them (they fall back to the generic "cite at least one location" rule).
_HAS_EXTENSION_RE = re.compile(r"\.[A-Za-z0-9]+$")


def _unit_own_file(unit: dict[str, Any]) -> str | None:
    """The source file a blocking unit must be evidenced against, or None.

    Returns the file part of the unit's ``location`` when it looks like a real path with an
    extension; None for route strings / locationless constructs, where the own-file rule
    does not apply. Extensionless build files (``Dockerfile``, ``Dockerfile.prod``, ...) are
    special-cased to match ``_is_eligible_source_file``'s ``startswith("Dockerfile")`` rule —
    without this, a Dockerfile is a valid denominator entry (scanner.py) but could never be
    counted as owned here, deadlocking ``TALON_STRICT_COVERAGE`` regardless of disposition.
    """
    file = _file_of(str(unit.get("location", "")).strip())
    if not file or file.startswith("<"):
        return None
    basename = file.rsplit("/", 1)[-1]
    if basename.startswith("Dockerfile"):
        return file
    return file if _HAS_EXTENSION_RE.search(file) else None


def _paths_refer_same_file(unit_file: str, cited: str) -> bool:
    """Whether a cited ``file`` path plausibly refers to the same source as ``unit_file``.

    Tolerant of a leading path-prefix difference (an agent may cite ``src/x/foo.py`` while
    the manifest stores ``repo/src/x/foo.py`` after ``cd``-ing into a subdir), but still
    rejects a genuinely different file — the suffix must align on a ``/`` boundary, so
    ``server/api/foo.py`` never matches ``server/api/bar.py``.
    """
    u = unit_file.strip().lstrip("./")
    c = cited.strip().lstrip("./")
    if not u or not c:
        return False
    return u == c or u.endswith("/" + c) or c.endswith("/" + u)


def _note_cites_own_file(unit: dict[str, Any], note: str) -> bool:
    """Whether the note cites at least one ``file:line`` inside the unit's own source file."""
    own = _unit_own_file(unit)
    if own is None:
        return True  # no concrete own-file to anchor to; generic location rule still applies
    return any(_paths_refer_same_file(own, path) for path, _, _ in _extract_note_locations(note))


async def _validate_note_locations(
    note: str, ctx_inner: dict[str, Any], *, fail_closed: bool = False
) -> str | None:
    """Confirm the ``file:line`` refs a disposition note cites actually exist.

    Soft anti-rubber-stamp: it does NOT require the note to cite a location, but any
    location it *does* cite must resolve (file present, line within range), so a fabricated
    ``evidence`` is rejected instead of silently accepted. No-op when there is no sandbox
    (unit tests, black-box) so it never blocks a legitimate disposition.

    ``fail_closed`` (set for ``ruled_out``) flips the infra-error behavior: ruling out a
    unit DROPS a review obligation, so if the existence check cannot complete we refuse the
    disposition rather than clear it on an unverified check (codejury invariant 4 — a failed
    check must never confirm a deletion). A plain ``reviewed`` stays fail-open, since it does
    not drop anything.
    """
    refs = _extract_note_locations(note)
    if not refs:
        return None
    session = ctx_inner.get("sandbox_session")
    if session is None:
        return None
    workspace_root = ctx_inner["workspace_layout"].workspace_root
    files = sorted({path for path, _, _ in refs})
    # Count lines with awk NR, not `wc -l`: wc -l counts newline BYTES, so a non-empty file
    # with no trailing newline (a minified JS bundle is one such line) reports 0 and a
    # legitimate ``:1`` citation is wrongly rejected as out-of-range. awk's NR counts the
    # final unterminated line, so a one-line bundle correctly reports 1.
    script = "; ".join(
        f"if [ -f {q} ]; then echo {q}':'$(awk 'END{{print NR}}' {q}); else echo {q}':MISSING'; fi"
        for q in (shlex.quote(f) for f in files)
    )
    try:
        result = await session.exec(
            "bash", "-lc", f"cd {shlex.quote(workspace_root)} && {script}", timeout=20
        )
    except Exception:
        logger.exception("disposition note location check: exec failed")
        if fail_closed:
            return (
                "Could not verify the cited code locations (sandbox error), and ruling a unit "
                "out drops a review obligation — refusing to clear it on an unverified check. "
                "Retry once the sandbox is responsive, or mark it reviewed if you did analyze it."
            )
        return None  # a plain 'reviewed' does not drop anything: never block on an infra hiccup
    line_counts: dict[str, int | None] = {}
    for out_line in _decode_stream(result, "stdout").splitlines():
        raw_path, sep, count = out_line.rpartition(":")
        if not sep:
            continue
        count = count.strip()
        line_counts[raw_path] = None if count == "MISSING" else int(count) if count.isdigit() else 0
    problems: list[str] = []
    for path, start, end in refs:
        total = line_counts.get(path)
        if total is None:
            problems.append(f"{path}:{start} — file not found in the workspace")
        elif start > total:
            problems.append(f"{path}:{start} — file has only {total} line(s)")
        elif end > total:
            problems.append(f"{path}:{start}-{end} — end line past EOF ({total} line(s))")
    if problems:
        return (
            "Disposition note cites code locations that do not resolve against the "
            "source: " + "; ".join(problems) + ". Cite the real file:line you reviewed "
            "(re-read the code); do not attach fabricated or stale locations."
        )
    return None


# awk NR counts the final unterminated line (a one-line bundle → 1, unlike wc -l which counts
# newline bytes); the length scan reports the longest line so a minified blob is unambiguous.
_LINE_SHAPE_AWK = "awk '{ if (length>m) m=length } END { print NR, m+0 }'"


async def _measure_line_shapes(
    files: list[str], session: Any, workspace_root: str
) -> dict[str, tuple[int, int] | None] | None:
    """(line count, longest line) per file via one sandbox exec; ``None`` value = missing file.

    Returns ``None`` (not a dict) when the exec itself fails, so the caller can fail closed."""
    script = "; ".join(
        f"if [ -f {q} ]; then echo {q}':'$({_LINE_SHAPE_AWK} {q}); else echo {q}':MISSING'; fi"
        for q in (shlex.quote(f) for f in files)
    )
    try:
        result = await session.exec(
            "bash", "-lc", f"cd {shlex.quote(workspace_root)} && {script}", timeout=20
        )
    except Exception:
        logger.exception("unauditable verify: exec failed")
        return None
    measured: dict[str, tuple[int, int] | None] = {}
    for out_line in _decode_stream(result, "stdout").splitlines():
        raw_path, sep, payload = out_line.rpartition(":")
        if not sep:
            continue
        payload = payload.strip()
        if payload == "MISSING":
            measured[raw_path] = None
            continue
        nl, _, ml = payload.partition(" ")
        measured[raw_path] = (int(nl) if nl.isdigit() else 0, int(ml) if ml.isdigit() else 0)
    return measured


async def _verify_unauditable(
    files: list[str], ctx_inner: dict[str, Any]
) -> dict[str, tuple[bool, str]]:
    """Machine-verify which ``files`` carry no auditable source. Fail-closed toward review.

    A file clears (``True``) ONLY on the double proof: (1) ``_has_generated_marker`` (a
    build-output/vendor path or bundle name) AND (2) the sandbox measures a minified
    structure (longest line ≥ ``_MINIFIED_MAX_LINE_LEN``). Everything else — non-generated
    path, readable structure, missing file, no sandbox, exec error — is returned
    ``(False, reason)`` so the caller keeps auditing it. Real source can never clear this.
    """
    verdict: dict[str, tuple[bool, str]] = {}
    candidates: list[str] = []
    for f in files:
        if _has_generated_marker(f):
            candidates.append(f)
        else:
            verdict[f] = (False, "not a build-output/bundle path — treated as source")
    if not candidates:
        return verdict
    session = ctx_inner.get("sandbox_session")
    layout = ctx_inner.get("workspace_layout")
    measured = (
        await _measure_line_shapes(candidates, session, layout.workspace_root)
        if session is not None and layout is not None
        else None
    )
    if measured is None:
        detail = "sandbox error measuring file structure (fail-closed)"
        if session is None or layout is None:
            detail = "no sandbox to verify file structure (fail-closed)"
        for f in candidates:
            verdict[f] = (False, detail)
        return verdict
    for f in candidates:
        verdict[f] = _classify_shape(f, measured.get(f))
    return verdict


def _classify_shape(path: str, shape: tuple[int, int] | None) -> tuple[bool, str]:
    """Verdict for one measured file: unauditable only when it measures minified."""
    if shape is None:
        return (False, "file not found in workspace (fail-closed)")
    nlines, maxlen = shape
    if maxlen >= _MINIFIED_MAX_LINE_LEN:
        return (
            True,
            f"{path}: build artifact / minified bundle ({nlines} line(s), longest {maxlen} chars)",
        )
    return (False, f"readable structure ({nlines} line(s), longest {maxlen} chars) — audit it")


def _summary() -> dict[str, int]:
    counts = {"total": len(_store.data), PENDING_STATUS: 0}
    for status in VALID_DISPOSITIONS:
        counts[status] = 0
    for unit in _store.data.values():
        status = unit.get("status", PENDING_STATUS)
        counts[status] = counts.get(status, 0) + 1
    return counts


@dataclass(frozen=True)
class CoverageProgress:
    """Layered coverage tally for the progress dashboard.

    The three kind buckets (entrypoints / sinks / file) are MUTUALLY EXCLUSIVE and sum to
    ``total`` (every unit has exactly one kind). ``hi_sig`` is an ORTHOGONAL cross-kind
    view (units carrying a ``vulnerability_class``), so it overlaps the buckets and is NOT
    additive with them. ``*_done`` counts dispositioned units (reviewed + ruled_out).

    The split keeps the dashboard from conflating the blocking attack surface (entrypoints,
    hi-sig) with the non-blocking whole-file fallback tier, which is seeded wide and would
    otherwise dominate the denominator and fake a "mostly skipped" progress bar.
    """

    total: int
    dispositioned: int
    pending: int
    entrypoints_total: int
    entrypoints_done: int
    sinks_total: int
    sinks_done: int
    file_total: int
    file_done: int
    hi_sig_total: int
    hi_sig_done: int
    # Per-lens (done, total), keyed by lens label. Superset of the hi-sig set: also folds in
    # the synthetic ENTRYPOINT_LENS bucket (``is_synthetic_lens`` tells them apart).
    by_lens: dict[str, tuple[int, int]] = field(default_factory=dict)


def coverage_progress() -> CoverageProgress:
    """Aggregate a layered tally for the progress dashboard.

    Buckets units by kind (blocking entrypoints, sinks, non-blocking file fallback) and,
    orthogonally, counts high-signal units (those carrying a ``vulnerability_class``).
    Read under the lock so it never races an in-flight disposition.
    """
    with _store.lock:
        total = len(_store.data)
        dispositioned = 0
        ep_total = ep_done = sink_total = sink_done = file_total = file_done = 0
        hi_total = hi_done = 0
        cls_acc: dict[str, list[int]] = {}
        for unit in _store.data.values():
            status = unit.get("status", PENDING_STATUS)
            is_done = status in ("reviewed", "ruled_out")
            dispositioned += int(is_done)
            role = role_of(unit)
            if role == ROLE_ENTRY:
                ep_total += 1
                ep_done += int(is_done)
            elif role == ROLE_SINK:
                sink_total += 1
                sink_done += int(is_done)
            elif role == ROLE_FILE:
                file_total += 1
                file_done += int(is_done)
            lens = lens_of(unit)
            if lens:
                if not lens.synthetic:  # hi-sig = real-class lenses only, synthetic excluded
                    hi_total += 1
                    hi_done += int(is_done)
                acc = cls_acc.setdefault(lens.value, [0, 0])
                acc[0] += int(is_done)
                acc[1] += 1
    return CoverageProgress(
        total=total,
        dispositioned=dispositioned,
        pending=total - dispositioned,
        entrypoints_total=ep_total,
        entrypoints_done=ep_done,
        sinks_total=sink_total,
        sinks_done=sink_done,
        file_total=file_total,
        file_done=file_done,
        hi_sig_total=hi_total,
        hi_sig_done=hi_done,
        by_lens={k: (v[0], v[1]) for k, v in cls_acc.items()},
    )


def coverage_quality_stats() -> dict[str, Any]:
    """Disposition-quality telemetry for the run record (a health metric, not a gate).

    Answers "how much did note-reuse do the heavy lifting?" over dispositioned blocking
    units: how many share a note, the largest such cluster, and how many were cleared via
    the ``covered_by_report`` systemic channel. A healthy deep scan has mostly distinct,
    per-file notes; a run dominated by one note across hundreds of units is the batch
    rubber-stamp pattern this surfaces so it is visible in eval/backtest triage.
    """
    with _store.lock:
        note_counts: dict[str, int] = {}
        covered = 0
        blocking_done = 0
        for unit in _store.data.values():
            if unit.get("status", PENDING_STATUS) not in ("reviewed", "ruled_out"):
                continue
            if not _requires_structured_note(unit):
                continue
            blocking_done += 1
            if str(unit.get("covered_by_report") or "").strip():
                covered += 1
            note = str(unit.get("disposition_note") or "").strip()
            note_counts[note] = note_counts.get(note, 0) + 1
    reused = {note: n for note, n in note_counts.items() if n > 1}
    return {
        "blocking_dispositioned": blocking_done,
        "distinct_notes": len(note_counts),
        "max_note_reuse": max(note_counts.values(), default=0),
        "units_sharing_a_note": sum(reused.values()),
        "covered_by_report": covered,
    }


def owned_files() -> set[str]:
    """Every source file that appears as (the file part of) some coverage unit's location.

    The manifest-side half of the filesystem-coverage check: a file is "owned" when at least
    one unit — of any kind or status — sits in it. Compared against the tree-derived eligible
    set to find files no unit ever claimed. Only file-shaped locations count (route strings
    and locationless markers have no file)."""
    with _store.lock:
        owned: set[str] = set()
        for unit in _store.data.values():
            own = _unit_own_file(unit)
            if own is not None:
                owned.add(own)
    return owned


def unowned_source_files(eligible: list[str]) -> list[str]:
    """Eligible source files claimed by no coverage unit — the filesystem-coverage gap.

    Exact set-difference first (seeded ``kind=file`` units share the scanner's ``_rel``
    namespace, so the common case is exact); a suffix-tolerant second pass over only the
    remainder absorbs prefix differences from semgrep/agent-added units without an O(n*m)
    scan of the whole tree. Order-preserving."""
    owned = owned_files()
    exact_unowned = [f for f in eligible if f not in owned]
    if not exact_unowned or not owned:
        return exact_unowned
    return [f for f in exact_unowned if not any(_paths_refer_same_file(f, o) for o in owned)]


def pending_units() -> list[dict[str, Any]]:
    """Units still awaiting disposition — consumed by the finish_scan gate."""
    with _store.lock:
        return [
            {**unit, "unit_id": uid}
            for uid, unit in _store.data.items()
            if unit.get("status", PENDING_STATUS) == PENDING_STATUS
        ]


def manifest_is_empty() -> bool:
    with _store.lock:
        return not _store.data


def pending_count_for_scope(prefixes: list[str]) -> int:
    """Count pending units whose location starts with any of ``prefixes``.

    Cheap, lock-scoped, in-process — no JSON tool-call round trip. Used by the execution
    loop to check a subagent's bound coverage_scope for objective forward progress (see
    _run_cycle's stream-event loop), the same "read the manifest directly" pattern as
    ``_pending_high_signal_units`` in core/execution.py. An empty/falsy ``prefixes`` list
    means no scope was bound; callers should skip the check entirely rather than call this
    (a unit never matches an empty prefix list, so it always returns 0).
    """
    clean_prefixes = [p for p in prefixes if p]
    if not clean_prefixes:
        return 0
    with _store.lock:
        return sum(
            1
            for unit in _store.data.values()
            if unit.get("status", PENDING_STATUS) == PENDING_STATUS
            and any(str(unit.get("location", "")).startswith(p) for p in clean_prefixes)
        )


def pending_count_total() -> int:
    """Count every pending unit in the manifest, regardless of location.

    Root's implicit "scope" is the whole repo — there is no common path prefix to pass
    into ``pending_count_for_scope`` (whose empty-prefix-list case means "no scope bound"
    and always returns 0). Used by the execution loop as root's scan-wide progress signal.
    """
    with _store.lock:
        return sum(
            1
            for unit in _store.data.values()
            if unit.get("status", PENDING_STATUS) == PENDING_STATUS
        )


# Only high/medium-confidence high-signal units block finishing; low-confidence ones are
# advisory only (deliberately wide seeding must not stall a scan).
_BLOCKING_CONFIDENCES: frozenset[str] = frozenset({"high", "medium"})


@dataclass(frozen=True)
class BlockingPending:
    """The recall gate's blocking-tier partition of the pending manifest.

    Shared by ``finish_scan``'s coverage gate and the resume recovery-frontier injection so the
    two can't drift. ``blocking`` is the union (by ``unit_id``) the gate refuses finish on; the
    component lists back its diagnostic breakdown.
    """

    pending: list[dict[str, Any]]
    high_signal: list[dict[str, Any]]
    class_blocking: list[dict[str, Any]]
    file_pending: list[dict[str, Any]]
    entrypoint_pending: list[dict[str, Any]]
    integrity_pending: list[dict[str, Any]]
    blocking: list[dict[str, Any]]


def compute_blocking_pending(
    *,
    strict_file_fallback: bool,
    entrypoint_gate: bool,
    pending: list[dict[str, Any]] | None = None,
) -> BlockingPending:
    """Partition the pending manifest into the recall gate's blocking tiers.

    Mirrors the four dimensions the gate enforces: high-signal classed units at
    high/medium confidence, whole-file fallback units (``strict_file_fallback``), enumerated
    entrypoints (``entrypoint_gate``), and explicit integrity markers. ``pending`` lets a
    caller pass a precomputed snapshot; when ``None`` it reads ``pending_units()`` itself.
    """
    units = pending_units() if pending is None else pending
    high_signal = [u for u in units if str(u.get("vulnerability_class") or "").strip()]
    class_blocking = [
        u
        for u in high_signal
        if str(u.get("confidence") or "medium").strip().lower() in _BLOCKING_CONFIDENCES
    ]
    file_pending = (
        [
            u
            for u in units
            if role_of(u) == ROLE_FILE and not str(u.get("vulnerability_class") or "").strip()
        ]
        if strict_file_fallback
        else []
    )
    entrypoint_pending = [u for u in units if is_entry(u)] if entrypoint_gate else []
    integrity_pending = [u for u in units if unit_is_blocking(u)]
    blocking_by_id = {
        u.get("unit_id"): u
        for u in (*class_blocking, *file_pending, *entrypoint_pending, *integrity_pending)
    }
    return BlockingPending(
        pending=units,
        high_signal=high_signal,
        class_blocking=class_blocking,
        file_pending=file_pending,
        entrypoint_pending=entrypoint_pending,
        integrity_pending=integrity_pending,
        blocking=list(blocking_by_id.values()),
    )


def _file_of(location: str) -> str:
    """Strip the trailing ``:line`` from a unit location to get the file path."""
    return location.rsplit(":", 1)[0] if ":" in location else location


def pending_units_by_file(
    pending: list[dict[str, Any]] | None = None,
) -> dict[str, list[dict[str, Any]]]:
    """Group still-pending units by their file path (for high-density analysis).

    ``pending`` lets a caller pass a precomputed snapshot to avoid re-scanning the
    manifest (see ``_list_impl``); when ``None`` it reads ``pending_units()`` itself.
    """
    units = pending_units() if pending is None else pending
    grouped: dict[str, list[dict[str, Any]]] = {}
    for unit in units:
        grouped.setdefault(_file_of(str(unit.get("location", ""))), []).append(unit)
    return grouped


def pending_units_by_dir(
    depth: int = 1, pending: list[dict[str, Any]] | None = None
) -> list[dict[str, Any]]:
    """Group still-pending units into cohesive clusters by top-level directory.

    Returns exhaustive_sweeps Rule-0's partition deterministically so slice tasks are
    concrete and non-overlapping. ``depth`` is how many leading path segments define a
    cluster (1 = top-level package/dir). Densest cluster first. ``classes_present`` lets a
    slice agent see which vulnerability classes it must cover.
    """
    units = pending_units() if pending is None else pending
    clusters: dict[str, dict[str, Any]] = {}
    for unit in units:
        file = _file_of(str(unit.get("location", "")))
        parts = file.split("/")
        key = "/".join(parts[:depth]) if len(parts) > depth else (parts[0] if parts else file)
        cluster = clusters.setdefault(
            key,
            {"cluster": key, "files": set(), "pending_units": 0, "classes_present": set()},
        )
        cluster["files"].add(file)
        cluster["pending_units"] += 1
        lens = lens_of(unit)
        if lens:
            cluster["classes_present"].add(lens.value)
    grouped = [
        {
            "cluster": cluster["cluster"],
            "files": sorted(cluster["files"]),
            "pending_units": cluster["pending_units"],
            "classes_present": sorted(cluster["classes_present"]),
        }
        for cluster in clusters.values()
    ]
    grouped.sort(key=lambda entry: entry["pending_units"], reverse=True)
    return grouped


def _compact_dir_clusters(clusters: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Drop per-file lists from cluster summaries returned to the LLM."""
    return [
        {
            "cluster": cluster["cluster"],
            "file_count": len(cluster.get("files") or []),
            "pending_units": cluster["pending_units"],
            "classes_present": cluster["classes_present"],
        }
        for cluster in clusters
    ]


def high_density_files(
    threshold: int = _HIGH_DENSITY_THRESHOLD, pending: list[dict[str, Any]] | None = None
) -> list[dict[str, Any]]:
    """Files with >= ``threshold`` pending units, densest first.

    These are where single-pass review most under-reports; the orchestrator should
    assign each a dedicated fresh-context re-sweep (see ``exhaustive_sweeps``). ``pending``
    forwards a precomputed snapshot to avoid re-scanning the manifest.
    """
    counts = [
        (path, len(units))
        for path, units in pending_units_by_file(pending).items()
        if len(units) >= threshold
    ]
    counts.sort(key=lambda pair: pair[1], reverse=True)
    return [{"file": path, "pending_units": count} for path, count in counts]


# Deterministic slice sizing. A "review-worthy" unit (classed / entrypoint / blocking) is
# what a slice agent must deep-review; low-signal file-fallback units are the wide sweep
# tier and do not drive slice count. Each slice targets roughly this many worthy units so
# one agent can deep-review it without collapsing back into sampling — small enough to force
# reading, large enough not to explode the agent count / root spawn overhead.
_DEFAULT_SLICE_UNITS = 15
_DEFAULT_SLICE_MAX_FILES = 8


def _slice_worthy_pending(pending: list[dict[str, Any]] | None = None) -> list[dict[str, Any]]:
    """Pending units that warrant a deep-review owner (the blocking tier)."""
    units = pending_units() if pending is None else pending
    return [
        u
        for u in units
        if u.get("status", PENDING_STATUS) == PENDING_STATUS and _requires_structured_note(u)
    ]


def plan_slices(
    target_units: int = _DEFAULT_SLICE_UNITS,
    *,
    dense_threshold: int = _HIGH_DENSITY_THRESHOLD,
    max_files: int = _DEFAULT_SLICE_MAX_FILES,
    pending: list[dict[str, Any]] | None = None,
) -> list[dict[str, Any]]:
    """Deterministically partition the review-worthy surface into balanced, cohesive slices.

    The atom is a small file cluster, not a whole subsystem: a dense file (>= ``dense_threshold``
    worthy units) becomes its own dedicated-re-sweep slice (single-pass review under-counts
    dense files — see ``exhaustive_sweeps`` Rule 3.5); the remaining files are packed in path
    order (so a slice stays directory-cohesive and its ``trace_symbol`` work stays local) up
    to ``target_units`` worthy units or ``max_files`` files, whichever comes first.

    Returns one dict per slice: ``files`` (pass as ``coverage_scope``), ``units`` (worthy
    count), ``classes_present`` (map these to lens skills when spawning), and ``kind``
    (``dense-file`` | ``cluster``). Densest single-file slices first, then clusters in path
    order — a stable worklist the coordinator drains while keeping the pipeline saturated.
    Low-signal file-fallback units are intentionally excluded: they are the wide sweep tier,
    not deep-review slices.
    """
    worthy = _slice_worthy_pending(pending)
    by_file: dict[str, list[dict[str, Any]]] = {}
    for unit in worthy:
        by_file.setdefault(_file_of(str(unit.get("location", ""))), []).append(unit)

    def _classes(units: list[dict[str, Any]]) -> list[str]:
        return sorted({lens.value for u in units if (lens := lens_of(u))})

    slices: list[dict[str, Any]] = []
    dense = {f: us for f, us in by_file.items() if len(us) >= dense_threshold}
    for file in sorted(dense, key=lambda f: len(dense[f]), reverse=True):
        units = dense[file]
        slices.append(
            {
                "kind": "dense-file",
                "files": [file],
                "units": len(units),
                "classes_present": _classes(units),
            }
        )

    cur_files: list[str] = []
    cur_units: list[dict[str, Any]] = []

    def _flush() -> None:
        if cur_files:
            slices.append(
                {
                    "kind": "cluster",
                    "files": list(cur_files),
                    "units": len(cur_units),
                    "classes_present": _classes(cur_units),
                }
            )

    for file in sorted(f for f in by_file if f not in dense):
        units = by_file[file]
        would_exceed = len(cur_units) + len(units) > target_units or len(cur_files) >= max_files
        if cur_files and would_exceed:
            _flush()
            cur_files, cur_units = [], []
        cur_files.append(file)
        cur_units.extend(units)
    _flush()

    for i, slice_ in enumerate(slices):
        slice_["slice"] = i
    return slices


def _add_units_impl(units: Any, source: str) -> dict[str, Any]:
    with _store.lock:
        try:
            parsed = _normalize_units(units)
        except (ValueError, TypeError) as e:
            return {"success": False, "error": str(e), "added": 0}
        if not parsed:
            return {"success": False, "error": "No units provided", "added": 0}

        existing = _existing_keys()
        added: list[str] = []
        skipped = 0
        timestamp = datetime.now(UTC).isoformat()
        for unit in parsed:
            key = _unit_dedupe_key(
                unit["kind"],
                unit["location"],
                unit.get("construct_type"),
                unit.get("vulnerability_class"),
            )
            if key in existing:
                skipped += 1
                continue
            unit_id = str(uuid.uuid4())[:6]
            stored_unit = dict(unit)
            stored_unit.update(
                {
                    "kind": unit["kind"],
                    "location": unit["location"],
                    "title": unit["title"],
                    "status": PENDING_STATUS,
                    "disposition_note": "",
                    "source": source,
                    "created_at": timestamp,
                    "updated_at": timestamp,
                }
            )
            _store.data[unit_id] = stored_unit
            existing[key] = unit_id
            added.append(unit_id)
        _store.persist()
        return {
            "success": True,
            "added": len(added),
            "skipped_duplicates": skipped,
            "unit_ids": added,
            "summary": _summary(),
        }


def _report_exists(report_id: str) -> bool:
    """Whether a filed vulnerability report with ``report_id`` exists in the scan state.

    Imported lazily (report state is a separate subsystem; keeps coverage tools importable
    in isolation for unit tests). Returns False when there is no scan report state.
    """
    from talon.report.state import (  # noqa: PLC0415 — deferred: avoids tools↔report import cycle
        get_global_report_state,
    )

    state = get_global_report_state()
    if state is None:
        return False
    return any(r.get("id") == report_id for r in state.get_existing_vulnerabilities())


def _covered_by_report_error(
    units: list[dict[str, Any]], status: str, report_id: str
) -> str | None:
    """Validate the systemic-coverage channel; message on failure, else None.

    The ``covered_by_report`` channel exempts a disposition from the own-file citation and
    per-call file cap so a genuinely systemic finding (e.g. app-wide missing authentication)
    can cover its whole class in one call. To stop it becoming a blanket amnesty it is
    tightly constrained: the report must be filed, the status must be ``reviewed``, and every
    covered unit must share ONE vulnerability_class — so a systemic claim can never sweep
    away unrelated dimensions (the way an auth finding must not also clear injection units).
    """
    if status != "reviewed":
        return (
            "covered_by_report only applies to a 'reviewed' disposition — the units ARE "
            "vulnerable and covered by a filed systemic report, not ruled out. Use a normal "
            "ruled_out disposition (with refutation) for units you are dismissing."
        )
    if not _report_exists(report_id):
        return (
            f"covered_by_report references report '{report_id}', which is not a filed report. "
            "File the systemic finding via create_vulnerability_report first, then reference "
            "its returned id here."
        )
    classes = {str(u.get("vulnerability_class") or "").strip().upper() for u in units}
    classes.discard("")
    if len(classes) > 1:
        return (
            "covered_by_report must cover a single vulnerability_class in one call (got: "
            f"{', '.join(sorted(classes))}). A systemic finding covers one class; disposition "
            "each class separately so an unrelated dimension is not silently cleared."
        )
    return None


def _blocking_file_cap_error(blocking_units: list[dict[str, Any]]) -> str | None:
    """Message when one call touches blocking units across too many distinct files, else None."""
    files = {own for own in (_unit_own_file(u) for u in blocking_units) if own is not None}
    if len(files) <= _MAX_BLOCKING_FILES_PER_CALL:
        return None
    return (
        f"This call dispositions blocking units across {len(files)} distinct files "
        f"(max {_MAX_BLOCKING_FILES_PER_CALL} per call). One note cannot evidence review of "
        "that many files — split by file/subsystem and cite each file's own code, or use "
        "covered_by_report for a genuinely systemic finding."
    )


def _ruleout_confirmation_error(
    blocking_units: list[dict[str, Any]], dispositioned_by: str | None, confirmed_by: str | None
) -> str | None:
    """Message when a blocking unit is ruled out without independent confirmation, else None.

    codejury's deletion rule: dropping a review obligation needs a second, independent read,
    not one agent's opinion. When the requirement is on, ruling out a blocking unit demands a
    ``confirmed_by`` that is present and DISTINCT from the agent doing the disposition, so a
    lone finder can never delete its own obligation. Recall-safe: uncertainty stays pending.
    """
    if not blocking_units:
        return None
    who = (confirmed_by or "").strip()
    if not who:
        return (
            "Ruling out a blocking unit requires independent confirmation: pass confirmed_by "
            "with the id of a DIFFERENT agent (a challenger) that also read the code and agrees "
            "the unit is not exploitable. A single agent cannot drop its own review obligation "
            "(recall-safe). Mark it reviewed instead if you only analyzed it, or spawn a "
            "challenger to confirm the ruleout."
        )
    if dispositioned_by and who == dispositioned_by.strip():
        return (
            "confirmed_by must be a DIFFERENT agent than the one ruling the unit out — an agent "
            "confirming its own refutation is not independent confirmation. Have a challenger "
            "agent read the code and supply its id."
        )
    return None


def _mark_reviewed_impl(  # noqa: PLR0911, PLR0912
    unit_ids: Any,
    status: str,
    note: str,
    covered_by_report: str | None = None,
    *,
    dispositioned_by: str | None = None,
    confirmed_by: str | None = None,
    require_ruleout_confirmation: bool = False,
) -> dict[str, Any]:
    with _store.lock:
        status_norm = (status or "").strip().lower()
        if status_norm not in VALID_DISPOSITIONS:
            return {
                "success": False,
                "error": f"Invalid status. Must be one of: {', '.join(VALID_DISPOSITIONS)}",
            }
        if not note or not note.strip():
            return {
                "success": False,
                "error": "A disposition note is required (what you checked / why it's ruled out)",
            }
        ids = _normalize_ids(unit_ids)
        if not ids:
            return {"success": False, "error": "No unit_ids provided"}
        report_ref = (covered_by_report or "").strip() or None
        confirmer = (confirmed_by or "").strip() or None

        resolved = [(uid, _store.data[uid]) for uid in ids if uid in _store.data]
        missing = [uid for uid in ids if uid not in _store.data]
        blocking_units = [u for _, u in resolved if _requires_structured_note(u)]

        if report_ref is not None:
            ref_error = _covered_by_report_error(blocking_units, status_norm, report_ref)
            if ref_error is not None:
                return {"success": False, "error": ref_error, "updated": [], "missing": missing}
        else:
            cap_error = _blocking_file_cap_error(blocking_units)
            if cap_error is not None:
                return {"success": False, "error": cap_error, "updated": [], "missing": missing}

        if status_norm == "ruled_out" and require_ruleout_confirmation:
            confirm_error = _ruleout_confirmation_error(blocking_units, dispositioned_by, confirmer)
            if confirm_error is not None:
                return {"success": False, "error": confirm_error, "updated": [], "missing": missing}

        updated: list[str] = []
        timestamp = datetime.now(UTC).isoformat()
        stored_note = note.strip()
        for uid, unit in resolved:
            note_error = _validate_disposition_note(
                unit, stored_note, status_norm, covered_by_report=report_ref is not None
            )
            if note_error:
                return {
                    "success": False,
                    "error": note_error,
                    "updated": updated,
                    "missing": missing,
                }
            unit["status"] = status_norm
            unit["disposition_note"] = stored_note
            unit["updated_at"] = timestamp
            if report_ref is not None:
                unit["covered_by_report"] = report_ref
            if dispositioned_by:
                unit["dispositioned_by"] = dispositioned_by
            if confirmer is not None:
                unit["confirmed_by"] = confirmer
            updated.append(uid)
        _store.persist()
        blocking_updated = sum(1 for _, u in resolved if _requires_structured_note(u))
        if blocking_updated >= _BULK_DISPOSITION_WARN:
            logger.warning(
                "bulk disposition: %d blocking unit(s) cleared in one call "
                "(status=%s, covered_by_report=%s) — verify this is genuine per-file review, "
                "not a batch rubber-stamp",
                blocking_updated,
                status_norm,
                report_ref or "no",
            )
        return {
            "success": not missing or bool(updated),
            "updated": updated,
            "missing": missing,
            "summary": _summary(),
        }


def _unauditable_note(detail: str, *, origin: str) -> str:
    """Machine-authored disposition note for an auto-cleared unauditable unit. The gate-
    clearing authority is the sandbox measurement in ``detail`` (distinct per file), NOT this
    prose — so these notes do not read as a shared batch rubber-stamp."""
    return json.dumps(
        {
            "decision": "reviewed_no_finding: build artifact / minified bundle, not source",
            "unauditable": True,
            "origin": origin,
            "evidence": detail,
        },
        ensure_ascii=False,
    )


def _resolve_unit_files(unit_ids: Any) -> tuple[dict[str, str], list[str]]:
    """Map each id to its own source file for the unauditable channel; collect problems.

    Returns ``(uid -> own_file, problem_messages)``. A unit that is unknown or has no
    concrete source file (route string / locationless) is not eligible and is reported as a
    problem rather than silently skipped.
    """
    files: dict[str, str] = {}
    problems: list[str] = []
    with _store.lock:
        for uid in _normalize_ids(unit_ids):
            unit = _store.data.get(uid)
            if unit is None:
                problems.append(f"{uid} (unknown unit id)")
                continue
            own = _unit_own_file(unit)
            if own is None:
                problems.append(f"{uid} (no concrete source file — not eligible)")
                continue
            files[uid] = own
    return files, problems


def _apply_unauditable(reasons_by_uid: dict[str, str]) -> tuple[int, dict[str, int]]:
    """Set the given units ``reviewed`` with a machine note; persist. Returns (count, summary).

    Idempotent and race-safe: only still-``pending`` units are touched, so a concurrent
    disposition is never overwritten."""
    if not reasons_by_uid:
        with _store.lock:
            return 0, _summary()
    timestamp = datetime.now(UTC).isoformat()
    with _store.lock:
        cleared = 0
        for uid, reason in reasons_by_uid.items():
            unit = _store.data.get(uid)
            if unit is None or unit.get("status", PENDING_STATUS) != PENDING_STATUS:
                continue
            unit["status"] = "reviewed"
            unit["disposition_note"] = reason
            unit["disposition_source"] = "structurally_unauditable"
            unit["updated_at"] = timestamp
            cleared += 1
        if cleared:
            _store.persist()
        return cleared, _summary()


def _pending_unauditable_candidates() -> list[tuple[str, str]]:
    """(unit_id, own_file) for every pending BLOCKING unit with a concrete source file.

    A deliberately wide candidate set — verification, not this filter, is the gate, and
    ``_verify_unauditable`` only ever clears machine-proved build artifacts, so a
    non-artifact candidate simply stays pending."""
    with _store.lock:
        out: list[tuple[str, str]] = []
        for uid, unit in _store.data.items():
            if unit.get("status", PENDING_STATUS) != PENDING_STATUS:
                continue
            if not _requires_structured_note(unit):
                continue
            own = _unit_own_file(unit)
            if own:
                out.append((uid, own))
        return out


async def sweep_unauditable(ctx_inner: dict[str, Any]) -> dict[str, Any]:
    """Auto-disposition pending blocking units whose files are machine-verified unauditable.

    Recall-safe by construction (see ``_verify_unauditable``): only files double-proved as
    build artifacts are cleared, fail-closed on any doubt; real source stays pending. Called
    by the finish gate so a residual minified chunk cannot deadlock the scan.
    """
    candidates = await asyncio.to_thread(_pending_unauditable_candidates)
    if not candidates:
        return {"cleared": 0, "files": [], "unit_ids": []}
    verdict = await _verify_unauditable(sorted({own for _, own in candidates}), ctx_inner)
    reasons_by_uid: dict[str, str] = {}
    cleared_files: set[str] = set()
    for uid, own in candidates:
        ok, detail = verdict.get(own, (False, "not verified"))
        if ok:
            reasons_by_uid[uid] = _unauditable_note(detail, origin="gate_auto")
            cleared_files.add(own)
    if not reasons_by_uid:
        return {"cleared": 0, "files": [], "unit_ids": []}
    cleared, _ = await asyncio.to_thread(_apply_unauditable, reasons_by_uid)
    return {"cleared": cleared, "files": sorted(cleared_files), "unit_ids": list(reasons_by_uid)}


def _matches_filter(
    unit: dict[str, Any],
    *,
    status_filter: str | None,
    path_prefix: str | None,
    vulnerability_class: str | None,
    kind: str | None,
    include_low_signal: bool,
) -> bool:
    if status_filter is not None and unit.get("status", PENDING_STATUS) != status_filter:
        return False
    if path_prefix is not None and not str(unit.get("location", "")).startswith(path_prefix):
        return False
    if vulnerability_class is not None:
        actual_class = str(unit.get("vulnerability_class") or "").strip().upper()
        if actual_class != vulnerability_class:
            return False
    if kind is not None and str(unit.get("kind") or "").strip().lower() != kind:
        return False
    return include_low_signal or bool(str(unit.get("vulnerability_class") or "").strip())


def _coerce_page(value: int | str | None, default: int) -> int:
    try:
        return int(value) if value is not None else default
    except (TypeError, ValueError):
        return default


def _slim_unit(uid: str, unit: dict[str, Any]) -> dict[str, Any]:
    slim: dict[str, Any] = {"unit_id": uid}
    for fname in _SLIM_UNIT_FIELDS:
        value = unit.get(fname)
        if value is not None and str(value).strip():
            slim[fname] = value
    return slim


def _list_impl(
    status: str | None = None,
    *,
    limit: int | str | None = _DEFAULT_LIST_LIMIT,
    offset: int | str | None = 0,
    path_prefix: str | None = None,
    vulnerability_class: str | None = None,
    kind: str | None = None,
    include_low_signal: bool = True,
    include_units: bool = True,
    include_details: bool = False,
    include_clusters: bool = False,
) -> dict[str, Any]:
    with _store.lock:
        status_filter = (status or "").strip().lower() or None
        class_filter = (vulnerability_class or "").strip().upper() or None
        kind_filter = (kind or "").strip().lower() or None
        path_filter = (path_prefix or "").strip() or None
        max_limit = _MAX_DETAIL_LIMIT if include_details else _MAX_LIST_LIMIT
        page_limit = max(0, min(_coerce_page(limit, _DEFAULT_LIST_LIMIT), max_limit))
        page_offset = max(0, _coerce_page(offset, 0))
        matched = [
            (uid, unit)
            for uid, unit in _store.data.items()
            if _matches_filter(
                unit,
                status_filter=status_filter,
                path_prefix=path_filter,
                vulnerability_class=class_filter,
                kind=kind_filter,
                include_low_signal=include_low_signal,
            )
        ]
        matched.sort(
            key=lambda pair: (
                pair[1].get("status", ""),
                pair[1].get("kind", ""),
                pair[1].get("location", ""),
            )
        )
        filtered_count = len(matched)
        page_pairs = matched[page_offset : page_offset + page_limit] if include_units else []
        page = [
            {**unit, "unit_id": uid} if include_details else _slim_unit(uid, unit)
            for uid, unit in page_pairs
        ]
        next_offset = page_offset + len(page)
        has_more = include_units and next_offset < filtered_count
        result = {
            "success": True,
            "units": page,
            "filtered_count": filtered_count,
            "returned_count": len(page),
            "offset": page_offset,
            "limit": page_limit,
            "has_more": has_more,
            "next_offset": next_offset if has_more else None,
            "summary": _summary(),
        }
        if include_clusters:
            # Share one pending snapshot across both cluster views (each would otherwise
            # rebuild the full list). Safe: already inside _store.lock.
            pending_snapshot = pending_units()
            result["pending_units_by_dir"] = _compact_dir_clusters(
                pending_units_by_dir(pending=pending_snapshot)
            )
            result["high_density_files"] = high_density_files(pending=pending_snapshot)
        return result


def _decode_stream(result: Any, attr: str) -> str:
    raw = getattr(result, attr, None)
    return raw.decode("utf-8", errors="replace") if raw else ""


# One semgrep run has one cwd, so a small path sample pins the prefix for the whole report.
_PREFIX_SAMPLE = 20


def _apply_source_prefix(prefix: str, path: str) -> str:
    if not prefix:
        return path
    return posixpath.normpath(f"{prefix}/{path}")


async def _detect_source_prefix(session: Any, workspace_root: str, sample_paths: list[str]) -> str:
    """Subdir prefix that makes semgrep's (cwd-relative) paths resolve under the workspace root.

    Probes ``.`` and each top-level dir; returns ``""`` if root-relative already or nothing
    resolves (don't guess). Aligns semgrep paths with the scanner's so units reconcile.
    """
    samples = [p for p in dict.fromkeys(sample_paths) if p][:_PREFIX_SAMPLE]
    if not samples:
        return ""
    quoted = " ".join(shlex.quote(p) for p in samples)
    script = (
        f"cd {shlex.quote(workspace_root)} || exit 1\n"
        "for pref in . $(ls -1p 2>/dev/null | sed -n 's:/$::p'); do\n"
        "  n=0\n"
        f'  for p in {quoted}; do [ -f "$pref/$p" ] && n=$((n+1)); done\n'
        '  echo "$n|$pref"\n'
        "done\n"
    )
    try:
        result = await session.exec("bash", "-lc", script, timeout=30)
    except Exception:
        logger.exception("semgrep path prefix detection: exec failed")
        return ""
    best_n, best_pref = 0, "."
    for line in _decode_stream(result, "stdout").splitlines():
        cnt, sep, pref = line.partition("|")
        if not sep or not cnt.strip().isdigit():
            continue
        n = int(cnt.strip())
        # Highest resolve count wins; ties prefer the shorter prefix (``.``) — never add a
        # spurious prefix when root-relative already works.
        if n > best_n or (n == best_n and len(pref) < len(best_pref)):
            best_n, best_pref = n, pref
    if best_n == 0:
        return ""
    return "" if best_pref in ("", ".") else best_pref


async def _normalize_semgrep_paths(session: Any, workspace_root: str, data: Any) -> tuple[str, int]:
    """Rewrite ``data``'s result/scanned paths to workspace-root-relative in place; return
    ``(prefix, rewritten_count)`` (``prefix`` is ``""`` when no change was needed)."""
    if not isinstance(data, dict):
        return "", 0
    results = data.get("results")
    results = results if isinstance(results, list) else []
    paths_obj = data.get("paths") if isinstance(data.get("paths"), dict) else None
    scanned = paths_obj.get("scanned") if paths_obj else None
    scanned = scanned if isinstance(scanned, list) else []

    sample = [str((r or {}).get("path", "")).strip() for r in results if isinstance(r, dict)]
    sample += [str(p).strip() for p in scanned]
    prefix = await _detect_source_prefix(session, workspace_root, sample)
    if not prefix:
        return "", 0

    count = 0
    for r in results:
        if isinstance(r, dict) and str(r.get("path", "")).strip():
            r["path"] = _apply_source_prefix(prefix, str(r["path"]).strip())
            count += 1
    if paths_obj is not None and scanned:
        paths_obj["scanned"] = [_apply_source_prefix(prefix, str(p).strip()) for p in scanned]
        count += len(scanned)
    return prefix, count


async def _seed_from_semgrep_impl(  # noqa: PLR0911, PLR0912
    ctx_inner: dict[str, Any], semgrep_json_path: str
) -> dict[str, Any]:
    session = ctx_inner.get("sandbox_session")
    if session is None:
        return {"success": False, "error": "No sandbox session in context", "added": 0}
    workspace_root = ctx_inner["workspace_layout"].workspace_root
    safe_path = semgrep_json_path.strip()
    if not safe_path:
        return {"success": False, "error": "semgrep_json_path is empty", "added": 0}
    try:
        result = await session.exec(
            "bash",
            "-lc",
            f"cd {shlex.quote(workspace_root)} && cat -- {shlex.quote(safe_path)}",
            timeout=30,
        )
    except Exception as e:
        logger.exception("seed_coverage_from_semgrep: exec failed")
        return {"success": False, "error": f"Failed to read semgrep json: {e!s}", "added": 0}

    stdout = _decode_stream(result, "stdout")
    if getattr(result, "exit_code", 1) != 0 or not stdout.strip():
        exit_code = getattr(result, "exit_code", "?")
        stderr = _decode_stream(result, "stderr")
        return {
            "success": False,
            "error": f"Could not read {safe_path} (exit={exit_code}): {stderr[:200]}",
            "added": 0,
        }
    try:
        data = json.loads(stdout)
    except json.JSONDecodeError as e:
        return {"success": False, "error": f"semgrep json is not valid JSON: {e!s}", "added": 0}

    # Align semgrep's paths with the scanner's so the same file's units reconcile instead of
    # splitting into two non-matching views (``services/x`` vs ``crAPI/services/x``).
    prefix, rewritten = await _normalize_semgrep_paths(session, workspace_root, data)
    if prefix:
        logger.info(
            "seed_coverage_from_semgrep: normalized %d path(s) under source prefix %r "
            "to workspace-root-relative (aligns with static-inventory paths)",
            rewritten,
            prefix,
        )

    paths: list[str] = []
    scanned = (((data.get("paths") or {}).get("scanned")) if isinstance(data, dict) else None) or []
    if isinstance(scanned, list) and scanned:
        paths = [str(p) for p in scanned]
    else:
        results = data.get("results") if isinstance(data, dict) else None
        if isinstance(results, list):
            seen: set[str] = set()
            for r in results:
                p = str((r or {}).get("path", "")).strip() if isinstance(r, dict) else ""
                if p and p not in seen:
                    seen.add(p)
                    paths.append(p)
    # Classed signal units from the actual findings (kind=sink, vulnerability_class +
    # confidence), so semgrep's rule hits become gate-enforced review obligations instead
    # of being discarded. File-coverage units below remain the baseline denominator.
    signal_units, signal_stats = semgrep_findings_to_units(data)

    file_units = [{"kind": "file", "location": p, "title": p} for p in paths]
    if not file_units and not signal_units:
        return {"success": True, "added": 0, "message": "No scanned paths found in semgrep json"}

    added = 0
    if signal_units:
        signal_result = await asyncio.to_thread(_add_units_impl, signal_units, "semgrep")
        added += int(signal_result.get("added", 0))
    if file_units:
        file_result = await asyncio.to_thread(_add_units_impl, file_units, "seed")
        added += int(file_result.get("added", 0))

    logger.info(
        "seed_coverage_from_semgrep: %d file unit(s) + %d classed signal unit(s) "
        "(from %d results: %d non-security, %d low-confidence, %d capped)",
        len(file_units),
        signal_stats["kept"],
        signal_stats["results"],
        signal_stats["dropped_nonsecurity"],
        signal_stats["dropped_low"],
        signal_stats["capped"],
    )
    return {
        "success": True,
        "added": added,
        "signal_units": signal_stats["kept"],
        "file_units": len(file_units),
        "semgrep_stats": signal_stats,
    }


@function_tool(timeout=30)
async def add_coverage_units(ctx: RunContextWrapper, units: str) -> str:
    """Register attack-surface units in the scan-wide coverage manifest.

    Use this during/after reconnaissance to record everything that must be reviewed:
    routes, request handlers, dangerous sinks, smart-contract functions, and entrypoints.
    Every registered unit later has to be dispositioned via ``mark_unit_reviewed`` before
    the scan can finish — so register the real attack surface, not noise.

    Duplicate units (same ``kind`` + ``location`` + optional ``construct_type`` +
    optional ``vulnerability_class``) are skipped automatically, so it is safe to
    register incrementally and to re-run enumeration. Use ``construct_type`` and
    ``vulnerability_class`` to model construct-by-risk coverage, e.g. one handler
    location can have separate BFLA and CSRF units.

    Args:
        units: A JSON array of unit objects. Each object needs:
            - ``kind``: one of route | handler | sink | contract_fn | entrypoint | file
            - ``location``: ``"path/to/file.py:42"`` or a path / route string
            - ``title`` (optional): short human label; defaults to ``location``
            - ``construct_type`` (optional): e.g. ``redirect_sink`` or ``admin_view``
            - ``vulnerability_class`` (optional): e.g. ``OPEN_REDIRECT`` or ``BFLA``
            - ``confidence`` (optional): ``high`` | ``medium`` | ``low``, defaults to
              ``medium``. Only ``high``/``medium`` units carrying a ``vulnerability_class``
              block ``finish_scan``'s recall gate; ``low`` is advisory (visible for
              audit context but never blocks). Set it deliberately — a weak signal you
              tag ``low`` won't force a disposition, and a strong one you leave at the
              default ``medium`` will.
            Example:
            ``[{"kind":"sink","location":"views.py:88","construct_type":"redirect_sink",
            "vulnerability_class":"OPEN_REDIRECT","title":"redirect path review",
            "confidence":"high"}]``
    """
    return json.dumps(
        await asyncio.to_thread(_add_units_impl, units, "agent"),
        ensure_ascii=False,
        default=str,
    )


async def _mark_unauditable(unit_ids: Any, status_norm: str, inner: dict[str, Any]) -> str:
    """Handle the ``structurally_unauditable`` channel: verify then clear, or refuse.

    Every named unit's file must be machine-proved a build artifact; if ANY is real source
    (or unverifiable) the whole call is refused, so the flag can never partially rubber-stamp
    source. Recall-safe: a refusal leaves everything pending.
    """
    if status_norm not in ("", "reviewed"):
        return json.dumps(
            {
                "success": False,
                "error": (
                    "structurally_unauditable is a 'reviewed' disposition (the file carries no "
                    "auditable source) — pass status='reviewed', not ruled_out."
                ),
            },
            ensure_ascii=False,
        )
    files_by_uid, problems = await asyncio.to_thread(_resolve_unit_files, unit_ids)
    if not files_by_uid:
        return json.dumps(
            {
                "success": False,
                "error": "No unit is eligible for structurally_unauditable: "
                + ("; ".join(problems) if problems else "no unit ids provided"),
            },
            ensure_ascii=False,
        )
    verdict = await _verify_unauditable(sorted(set(files_by_uid.values())), inner)
    reasons_by_uid: dict[str, str] = {}
    rejected: list[str] = list(problems)
    for uid, own in files_by_uid.items():
        ok, detail = verdict.get(own, (False, "not verified"))
        if ok:
            reasons_by_uid[uid] = _unauditable_note(detail, origin="agent")
        else:
            rejected.append(f"{own} ({detail})")
    if rejected:
        return json.dumps(
            {
                "success": False,
                "error": (
                    "structurally_unauditable refused — these are NOT machine-verified build "
                    "artifacts and must be reviewed as source: " + "; ".join(rejected[:8])
                ),
            },
            ensure_ascii=False,
        )
    cleared, summary = await asyncio.to_thread(_apply_unauditable, reasons_by_uid)
    return json.dumps(
        {"success": True, "updated": list(reasons_by_uid), "cleared": cleared, "summary": summary},
        ensure_ascii=False,
        default=str,
    )


@function_tool(timeout=30)
async def mark_unit_reviewed(
    ctx: RunContextWrapper,
    unit_ids: str,
    status: str,
    note: str,
    covered_by_report: str | None = None,
    confirmed_by: str | None = None,
    structurally_unauditable: bool = False,
) -> str:
    """Disposition one or more coverage units after reviewing them.

    This is how the coverage gate is cleared. ``reviewed`` means you actively analyzed
    the unit (regardless of whether a vulnerability was found — file any finding via
    ``create_vulnerability_report`` separately). ``ruled_out`` means the unit is not a
    real attack surface or is out of scope. A note is mandatory: state what you checked
    or why it is ruled out.

    **Evidence is per-file, not per-call.** For a blocking unit the note must cite a
    ``file:line`` inside *that unit's own source file*. One shared note therefore cannot
    clear units spread across unrelated files: disposition each file's units with evidence
    read from that file. A single call may span at most a handful of distinct files —
    batch units that live in the SAME file, not a whole subsystem under one note.

    A blocking unit's ``note`` is a JSON object — copy this shape so the first call clears
    the gate instead of bouncing on a missing field (add ``"refutation"`` for ``ruled_out``)::

        {"decision": "reviewed", "evidence": "app/api/users.py:42 owner-checked before query",
         "checked": "traced ?id from route to SQL", "other_classes_checked": "SQLi: parameterized"}

    Args:
        unit_ids: A unit id, a comma-separated list, or a JSON array of ids
            (from ``list_coverage`` / ``add_coverage_units``).
        status: ``reviewed`` or ``ruled_out``.
        note: Short justification — what you analyzed, or why it's ruled out. For
            blocking units — those carrying a ``vulnerability_class`` AND every
            enumerated entrypoint (route/handler/entrypoint/contract_fn), even with no
            class — this must be a JSON object string with ``decision``, ``evidence``,
            and ``checked`` fields, and ``evidence`` must cite at least one concrete
            ``file:line`` **inside the unit's own file** that you actually reviewed (a
            disposition with no cited location, or one citing only unrelated files, is
            rejected as a rubber stamp). When ``status`` is ``ruled_out`` on such a unit
            you must ALSO include a ``refutation`` field: the strongest exploit case for
            the bug being real, then why it concretely fails (adversarial
            self-challenge — Rule 5). Such a unit (unless ``covered_by_report``) must
            ALSO include ``other_classes_checked``: the OTHER vulnerability classes you
            considered at this same site and why they don't apply — or ``"none plausible
            for this construct"`` — so closing out the one candidate this unit names
            never silently skips the rest of exhaustive_sweeps Rule 1. Any ``file:line``
            / ``file:start-end`` reference you cite is verified against the real source
            (file exists, line within range) — a call citing a nonexistent or
            out-of-range location is rejected, so cite locations you actually re-read.
            Low-signal whole-file fallback units (kind=file, no class) may still use a
            concise free-text note.
        covered_by_report: Optional — for a genuinely systemic finding only (e.g.
            app-wide missing authentication). Pass the ``vuln-NNNN`` id of the already
            filed report that covers these units. This exempts the call from the own-file
            citation and the per-call file cap, so one systemic report can cover its whole
            class in a single call — but it is tightly constrained: the report must exist,
            ``status`` must be ``reviewed``, and every unit in the call must share ONE
            vulnerability_class (so a systemic claim cannot sweep away unrelated
            dimensions). Do NOT use this to avoid per-file review of distinct bugs.
        confirmed_by: Optional — the id of an INDEPENDENT agent (a challenger) that also
            read the code and agrees when you ``ruled_out`` a blocking unit. Ruling out
            drops a review obligation, so under the (opt-in) confirmation requirement a
            blocking unit cannot be ruled out by a lone agent: supply a challenger's id
            distinct from your own. Ignored for ``reviewed``.
        structurally_unauditable: Set true ONLY for a unit seeded onto a build artifact /
            minified bundle (a webpack chunk, a vendored ``*.min.js``) that carries no
            auditable source. The tool VERIFIES this in the sandbox — the file must both sit
            on a generated/bundle path AND measure as one enormous line — and refuses if the
            file is real, readable source (you must review those normally). Use it to clear
            noise the seeder should never have registered, not to skip hard code. Forces a
            ``reviewed`` disposition; ``note`` may be brief (the machine measurement is the
            evidence).
    """
    inner = ctx.context if isinstance(ctx.context, dict) else {}
    status_norm = (status or "").strip().lower()
    if structurally_unauditable:
        return await _mark_unauditable(unit_ids, status_norm, inner)
    # ruled_out drops a review obligation, so an unverified location check must NOT clear it.
    location_error = await _validate_note_locations(
        note or "", inner, fail_closed=status_norm == "ruled_out"
    )
    if location_error:
        return json.dumps({"success": False, "error": location_error}, ensure_ascii=False)
    require_confirmation = False
    try:
        from talon.config import (  # noqa: PLC0415 — deferred: avoids tools↔config import cost at module load
            load_settings,
        )

        require_confirmation = bool(
            getattr(load_settings().agents, "ruleout_requires_confirmation", False)
        )
    except Exception:
        logger.exception("could not load ruleout_requires_confirmation setting; defaulting off")
    return json.dumps(
        await asyncio.to_thread(
            _mark_reviewed_impl,
            unit_ids,
            status,
            note,
            covered_by_report,
            dispositioned_by=str(inner.get("agent_id") or "") or None,
            confirmed_by=confirmed_by,
            require_ruleout_confirmation=require_confirmation,
        ),
        ensure_ascii=False,
        default=str,
    )


@function_tool(timeout=30)
async def list_coverage(
    ctx: RunContextWrapper,
    status: str | None = None,
    limit: int = _DEFAULT_LIST_LIMIT,
    offset: int = 0,
    path_prefix: str | None = None,
    vulnerability_class: str | None = None,
    kind: str | None = None,
    include_low_signal: bool = True,
    include_units: bool = True,
    include_details: bool = False,
    include_clusters: bool = False,
) -> str:
    """List a page of coverage units plus the reviewed/total summary.

    Call this to see what is still ``pending`` before attempting ``finish_scan``.
    Pending units with ``vulnerability_class`` block the finish gate; low-signal file
    fallback units without a class are reported but do not block. The manifest is
    scan-wide and may be large, so this tool is paginated: follow ``has_more`` /
    ``next_offset`` until your selected slice is exhausted. Units come back as a slim
    projection (id/kind/location/status/class); every byte returned here is replayed
    into your context on every later turn, so keep pages small and targeted.

    Args:
        status: Optional filter — ``pending`` | ``reviewed`` | ``ruled_out``.
        limit: Page size, capped at 200 (20 with ``include_details``). Defaults to 50.
        offset: Zero-based page offset for continuing a filtered listing.
        path_prefix: Optional location prefix, e.g. ``"fides/src/fides/api"``.
        vulnerability_class: Optional class filter, e.g. ``"BFLA"`` or ``"XSS"``.
        kind: Optional kind filter — route | handler | sink | contract_fn | entrypoint | file.
        include_low_signal: When false, omit units with no ``vulnerability_class``.
        include_units: When false, return only the summary counts.
        include_details: When true, return full unit records (title, disposition_note,
            timestamps) instead of the slim projection; page size is capped at 20.
        include_clusters: When true, also return ``pending_units_by_dir`` (directory
            clusters for slice partitioning) and ``high_density_files``.
    """
    return json.dumps(
        await asyncio.to_thread(
            _list_impl,
            status,
            limit=limit,
            offset=offset,
            path_prefix=path_prefix,
            vulnerability_class=vulnerability_class,
            kind=kind,
            include_low_signal=include_low_signal,
            include_units=include_units,
            include_details=include_details,
            include_clusters=include_clusters,
        ),
        ensure_ascii=False,
        default=str,
    )


@function_tool(timeout=30)
async def plan_review_slices(
    ctx: RunContextWrapper, target_units: int = _DEFAULT_SLICE_UNITS
) -> str:
    """Partition the pending review surface into balanced, cohesive slices to fan out over.

    Call this ONCE after seeding, before spawning finders, to turn the manifest into a
    ready-made worklist. It packs the review-worthy pending units (those carrying a
    vulnerability_class or being an enumerated entrypoint — NOT the low-signal file-fallback
    sweep tier) into small file clusters of about ``target_units`` units each, and gives every
    dense file (a hotspot single-pass review under-counts) its own dedicated slice.

    Spawn ONE ``create_agent`` per returned slice: pass the slice's ``files`` as
    ``coverage_scope`` and load ``source_aware_sast`` plus the vuln skills matching the
    slice's ``classes_present`` as that finder's lenses. Keep the whole slice list in flight
    up to your concurrency cap and refill as agents complete (see ``exhaustive_sweeps`` Rule
    0). Deterministic and read-only — same manifest gives the same slices.

    Args:
        target_units: Rough number of review-worthy units per cluster slice (default 15).
            Smaller → more, finer agents; larger → fewer, broader agents.

    Returns JSON: ``{"slices": [...], "slice_count": N, "worthy_units": M}`` where each slice
    has ``slice`` (index), ``kind`` (``dense-file`` | ``cluster``), ``files``, ``units``, and
    ``classes_present``.
    """
    bounded = max(1, min(int(target_units or _DEFAULT_SLICE_UNITS), 200))
    slices = await asyncio.to_thread(plan_slices, bounded)
    return json.dumps(
        {
            "success": True,
            "slices": slices,
            "slice_count": len(slices),
            "worthy_units": sum(s["units"] for s in slices),
        },
        ensure_ascii=False,
        default=str,
    )


@function_tool(timeout=60)
async def seed_coverage_from_semgrep(ctx: RunContextWrapper, semgrep_json_path: str) -> str:
    """Seed coverage units from a semgrep JSON report.

    Run after your semgrep pass to bootstrap the manifest deterministically. Registers
    two tiers from the report in the sandbox:

    - one ``kind=file`` unit per scanned file (``paths.scanned``, falling back to unique
      ``results[].path``) — the coverage-denominator floor; and
    - one classed ``kind=sink`` signal unit per (file, vulnerability_class) for each
      high/medium-confidence **security** finding, carrying ``vulnerability_class`` and
      ``confidence`` so the recall gate pulls it into review. Low/info and non-security
      hits stay as plain file coverage; the promoted set is capped and the counts logged.

    Add any finer-grained units semgrep did not surface yourself via ``add_coverage_units``.

    Args:
        semgrep_json_path: Path to the semgrep JSON output inside the sandbox. Pass the
            **absolute** artifact path ``$TALON_ARTIFACT_DIR/semgrep.json`` (i.e.
            ``/workspace/.talon-source-aware/semgrep.json``). A relative path is resolved
            from the **workspace root**, NOT your shell cwd — so a ``../…`` path built
            while ``cd``'d into a source subdir will not resolve.
    """
    inner = ctx.context if isinstance(getattr(ctx, "context", None), dict) else {}
    return json.dumps(
        await _seed_from_semgrep_impl(inner, semgrep_json_path),
        ensure_ascii=False,
        default=str,
    )

"""Sink catalog — declarative sink declarations parsed from ``rules/*.md`` frontmatter.

Rules ↔ scanner anti-drift. A rule doc may declare a ``sinks:`` list in its YAML
frontmatter (compact JSON on one line). Each declaration is a **contract**: the scanner
must recognise the declared ``example`` into the declared ``class``, enforced by
``tests/test_rules_catalog_parity.py`` so "the doc lists X as a sink but the scanner
never implemented it" becomes a CI failure instead of a silent recall gap.

stdlib-only (``json`` + ``re`` + ``pathlib``): the scanner ships into the sandbox image
with no third-party deps, hence parsing the one ``sinks:`` line as JSON rather than
pulling in a YAML library.

This module only *reads and validates* declarations (for the gate).
"""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any


# Semantic predicates the scanner engine provides. A declaration names the predicate its
# sink needs; the parity gate rejects any predicate not listed here, so a typo or an
# unimplemented predicate fails loudly rather than silently passing.
KNOWN_PREDICATES = frozenset(
    {
        "always",  # any call to a listed name is a sink
        "command_sink",  # eval/exec/os.system family
        "non_literal_first_arg",  # first arg is not a string literal (SSTI, dynamic serve)
        "dynamic_string",  # first arg built at runtime: f-string / concat / .format
        "deser",  # native-object deserializer (pickle/yaml.load/…)
        "jwt_decode",  # jwt.decode without verification / allowlist / alg=none
        "dynamic_url",  # outbound request whose URL is not a literal
        "xml_parse",  # XML parser whose entity handling needs review
        "tls_verify_false",  # TLS verification disabled at the call site
        "request_derived",  # sink whose argument carries request/untrusted data
        "weak_crypto",  # broken hash / risky cipher construction
        "nosql_dict",  # mongo-style query dict with $where or request data
        "xss_output",  # unescaped output (mark_safe/format_html/innerHTML)
        "redirect",  # redirect target is request-derived
        "decorator",  # decorator marker (csrf_exempt / shared_task)
        "plaintext_write",  # password written without a one-way hash/KDF
        "secret_literal",  # credential embedded as a string literal
        "line_regex",  # line-level regex match (JS/Go/PHP/IaC, no AST)
    }
)

_REQUIRED_FIELDS = ("calls", "class", "predicate", "example")

_FRONTMATTER = re.compile(r"^---\s*\n(.*?)\n---\s*\n", re.DOTALL)
_SINKS_LINE = re.compile(r"^sinks:\s*(.+)$", re.MULTILINE)


def _default_rules_dir() -> Path:
    # talon/tools/inventory/catalog.py -> parents[2] == talon/
    return Path(__file__).resolve().parents[2] / "skills" / "rules"


def load_sink_declarations(rules_dir: Path | None = None) -> list[dict[str, Any]]:
    """Parse every ``rules/*.md`` frontmatter ``sinks:`` block into flat declarations.

    Each returned dict carries the declared fields plus ``_rule`` (the source rule stem).
    Raises ``ValueError`` on malformed JSON so a broken declaration fails at load, not
    silently drops a sink from the contract.
    """
    rules_dir = rules_dir or _default_rules_dir()
    declarations: list[dict[str, Any]] = []
    # rglob: rules/*.md were physically split into rules/<kind>/ sub-folders; the sink
    # contract still spans the whole tree (all sink-declaring rules are vulnerability kind).
    for md in sorted(rules_dir.rglob("*.md")):
        frontmatter = _FRONTMATTER.match(md.read_text(encoding="utf-8"))
        if frontmatter is None:
            continue
        line = _SINKS_LINE.search(frontmatter.group(1))
        if line is None:
            continue
        try:
            decls = json.loads(line.group(1))
        except json.JSONDecodeError as e:
            raise ValueError(f"{md.name}: malformed 'sinks:' JSON: {e}") from e
        if not isinstance(decls, list):
            raise TypeError(f"{md.name}: 'sinks:' must be a JSON array")
        for decl in decls:
            if not isinstance(decl, dict):
                raise TypeError(
                    f"{md.name}: each 'sinks' entry must be a JSON object, got {decl!r}"
                )
            decl["_rule"] = md.stem
            declarations.append(decl)
    return declarations


def validation_errors(declarations: list[dict[str, Any]]) -> list[str]:
    """Structural check for the gate: required fields present, predicate known."""
    errors: list[str] = []
    for decl in declarations:
        rule = decl.get("_rule", "?")
        errors.extend(
            f"{rule}: sink declaration missing '{field}': {decl}"
            for field in _REQUIRED_FIELDS
            if not decl.get(field)
        )
        predicate = decl.get("predicate")
        if predicate and predicate not in KNOWN_PREDICATES:
            errors.append(
                f"{rule}: unknown predicate {predicate!r} — add it to the scanner engine "
                f"and KNOWN_PREDICATES, or fix the declaration"
            )
    return errors

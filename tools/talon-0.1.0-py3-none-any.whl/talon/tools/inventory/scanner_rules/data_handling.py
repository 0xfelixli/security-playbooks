"""insecure_deserialization.md / xxe.md / path_traversal.md / arbitrary_file_write.md sinks."""

from __future__ import annotations

import ast

from talon.tools.inventory.scanner_rules.helpers import ScanHelpersMixin


# insecure_deserialization.md: native-object deserializers that execute on load.
_PICKLE_MODULES = frozenset({"pickle", "cpickle", "_pickle", "dill"})

# xxe.md: XML parser modules whose entity handling must be reviewed. defusedxml is the
# safe shape and never emits.
_XML_MODULE_SEGMENTS = frozenset(
    {"etree", "elementtree", "minidom", "sax", "pulldom", "xmltodict", "lxml"}
)
_XML_PARSE_METHODS = frozenset({"parse", "fromstring", "parsestring", "iterparse", "xml"})

# path_traversal.md: file-serving responses where the path is not a literal.
_FILE_SERVE_CALLS = frozenset({"send_file", "send_from_directory", "FileResponse"})

# arbitrary_file_write.md: filesystem writes whose destination can be attacker-chosen.
_FILE_WRITE_CALLS = frozenset(
    {"shutil.copy", "shutil.copyfile", "shutil.copytree", "shutil.move", "os.rename", "os.replace"}
)


class DataHandlingSinksMixin(ScanHelpersMixin):
    def _add_deserialization_sink(self, node: ast.Call, name: str, lower: str) -> None:
        """insecure_deserialization.md: native-object deserializers execute on load."""
        segments = lower.split(".")
        last = segments[-1]
        if last in {"load", "loads"} and any(seg in _PICKLE_MODULES for seg in segments[:-1]):
            self.scanner._add(
                "sink",
                self.path,
                node.lineno,
                "deserialization",
                "INSECURE_DESERIALIZATION",
                f"{name} native object deserialization review",
                {"callee": name},
                confidence="high",
            )
        if lower in {"marshal.load", "marshal.loads", "jsonpickle.decode"}:
            self.scanner._add(
                "sink",
                self.path,
                node.lineno,
                "deserialization",
                "INSECURE_DESERIALIZATION",
                f"{name} native object deserialization review",
                {"callee": name},
                confidence="high",
            )
        if lower == "shelve.open":
            self.scanner._add(
                "sink",
                self.path,
                node.lineno,
                "deserialization",
                "INSECURE_DESERIALIZATION",
                f"{name} pickle-backed storage review",
                {"callee": name},
                confidence="medium",
            )
        if segments[:1] == ["yaml"] and last in {"load", "unsafe_load", "full_load"}:
            loader = self._kwarg(node, "Loader")
            loader_name = self._name(loader) if loader is not None else ""
            if "Safe" in loader_name:
                return
            self.scanner._add(
                "sink",
                self.path,
                node.lineno,
                "deserialization",
                "INSECURE_DESERIALIZATION",
                f"{name} unsafe YAML load review",
                {"callee": name, "loader": loader_name or None},
                confidence="medium" if last == "full_load" else "high",
            )

    def _add_xml_sink(self, node: ast.Call, name: str, lower: str) -> None:
        """xxe.md: XML parse call whose entity handling must be reviewed."""
        if "defusedxml" in lower:
            return
        segments = lower.split(".")
        last = segments[-1]
        # ``et`` is dropped from the module set (too short → collided with any obj.et.*);
        # instead accept it only as the top-level ElementTree alias (ET.parse/ET.fromstring).
        is_xml_module = (
            any(seg in _XML_MODULE_SEGMENTS for seg in segments[:-1]) or segments[0] == "et"
        )
        if last in _XML_PARSE_METHODS and is_xml_module:
            self.scanner._add(
                "sink",
                self.path,
                node.lineno,
                "xml_parse",
                "XXE",
                f"{name} XML external entity handling review",
                {"callee": name},
                confidence="medium",
            )
        if last == "xmlparser":
            resolve = self._kwarg(node, "resolve_entities")
            if isinstance(resolve, ast.Constant) and resolve.value is True:
                self.scanner._add(
                    "sink",
                    self.path,
                    node.lineno,
                    "xml_parse",
                    "XXE",
                    f"{name} external entity resolution enabled review",
                    {"callee": name, "resolve_entities": True},
                    confidence="high",
                )

    def _add_path_and_write_sinks(self, node: ast.Call, name: str, lower: str) -> None:
        """path_traversal.md + arbitrary_file_write.md additions beyond open()."""
        segments = name.split(".")
        last = segments[-1]
        first = self._first_arg(node)
        request_derived = self._contains_request_data(node)
        if (
            (last in _FILE_SERVE_CALLS or name in _FILE_SERVE_CALLS)
            and not isinstance(first, ast.Constant)
            and first is not None
        ):
            self.scanner._add(
                "sink",
                self.path,
                node.lineno,
                "file_path",
                "PATH_TRAVERSAL",
                f"{name} dynamic file serving review",
                {"callee": name, "request_derived_input": request_derived},
                confidence="high" if request_derived else "medium",
            )
        if lower.endswith("path.join") and request_derived:
            self.scanner._add(
                "sink",
                self.path,
                node.lineno,
                "file_path",
                "PATH_TRAVERSAL",
                f"{name} request-derived path construction review",
                {"callee": name, "request_derived_input": True},
                confidence="high",
            )
        if last == "extractall":
            self.scanner._add(
                "sink",
                self.path,
                node.lineno,
                "archive_extract",
                "PATH_TRAVERSAL",
                f"{name} archive extraction (zip-slip) review",
                {"callee": name},
                confidence="medium",
            )
        if (name in _FILE_WRITE_CALLS or last in {"write_text", "write_bytes"}) and (
            request_derived
        ):
            self.scanner._add(
                "sink",
                self.path,
                node.lineno,
                "file_write",
                "ARBITRARY_FILE_WRITE",
                f"{name} request-derived file write review",
                {"callee": name, "request_derived_input": True},
                confidence="high",
            )

"""Shared AST helpers every sink-detection mixin relies on via ``self``."""

from __future__ import annotations

import ast
from typing import TYPE_CHECKING


if TYPE_CHECKING:
    from pathlib import Path

    from talon.tools.inventory.scanner import InventoryScanner


class ScanContext:
    """Instance attributes ``PythonVisitor.__init__`` sets, declared here so every
    mixin's methods type-check against ``self`` without each mixin needing its own
    ``__init__``."""

    scanner: InventoryScanner
    path: Path
    _http_client_vars: set[str]


# Request-object attributes that expose untrusted input. Matched after a ``request`` segment
# so ``self.request.GET`` (CBV/DRF) and bare ``request.GET`` both resolve, and header / cookie
# / file / DRF query_params sources are covered — not only Django/Flask form-style access.
_REQUEST_ATTRS = frozenset(
    {
        "POST",
        "GET",
        "data",
        "body",
        "args",
        "form",
        "json",
        "headers",
        "cookies",
        "files",
        "query_params",
        "values",
    }
)


class ScanHelpersMixin(ScanContext):
    def _name(self, node: ast.AST) -> str:
        if isinstance(node, ast.Name):
            return node.id
        if isinstance(node, ast.Attribute):
            parent = self._name(node.value)
            return f"{parent}.{node.attr}" if parent else node.attr
        if isinstance(node, ast.Call):
            return self._name(node.func)
        if isinstance(node, ast.Subscript):
            return self._name(node.value)
        return ""

    def _call_name(self, node: ast.Call) -> str:
        return self._name(node.func)

    def _contains_request_data(self, node: ast.AST) -> bool:
        """True when a ``request.<attr>`` / ``self.request.<attr>`` source appears in the
        subtree — covers CBV/DRF ``self.request`` and header/cookie/file/query sources, not
        only bare Django/Flask ``request.GET``-style access."""
        for child in ast.walk(node):
            parts = self._name(child).split(".")
            for i in range(len(parts) - 1):
                if parts[i] == "request" and parts[i + 1] in _REQUEST_ATTRS:
                    return True
        return False

    @staticmethod
    def _literal_all(node: ast.AST) -> bool:
        return isinstance(node, ast.Constant) and node.value == "__all__"

    @staticmethod
    def _is_dynamic_string(node: ast.AST | None) -> bool:
        """True when a string is BUILT at runtime: f-string, '+'/'%' concat, .format()."""
        if node is None:
            return False
        if isinstance(node, ast.JoinedStr):
            return True
        if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Add | ast.Mod):
            return True
        return (
            isinstance(node, ast.Call)
            and isinstance(node.func, ast.Attribute)
            and node.func.attr == "format"
        )

    @staticmethod
    def _first_arg(node: ast.Call) -> ast.AST | None:
        return node.args[0] if node.args else None

    @staticmethod
    def _positional_arg(node: ast.Call, index: int) -> ast.AST | None:
        return node.args[index] if len(node.args) > index else None

    @staticmethod
    def _kwarg(node: ast.Call, name: str) -> ast.AST | None:
        for keyword in node.keywords:
            if keyword.arg == name:
                return keyword.value
        return None

    @staticmethod
    def _string_literal(node: ast.AST) -> str | None:
        if isinstance(node, ast.Constant) and isinstance(node.value, str):
            return node.value
        return None

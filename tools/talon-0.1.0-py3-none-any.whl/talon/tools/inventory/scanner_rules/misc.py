"""race_condition.md (mktemp) / regex_dos.md / cors_misconfiguration.md sinks."""

from __future__ import annotations

import ast

from talon.tools.inventory.scanner_rules.helpers import ScanHelpersMixin


# regex_dos.md: regex compiled from request data.
_REGEX_COMPILE_CALLS = frozenset({"re.compile", "re.match", "re.search", "re.fullmatch"})


class MiscSinksMixin(ScanHelpersMixin):
    def _add_misc_sinks(self, node: ast.Call, name: str) -> None:
        """race_condition.md (mktemp), regex_dos.md, fastapi CORS wildcard."""
        lower = name.lower()
        if lower == "tempfile.mktemp" or lower.endswith(".mktemp"):
            self.scanner._add(
                "sink",
                self.path,
                node.lineno,
                "temp_file",
                "RACE_CONDITION",
                f"{name} predictable temp file (TOCTOU) review",
                {"callee": name},
                confidence="medium",
            )
        if name in _REGEX_COMPILE_CALLS and self._contains_request_data(node):
            self.scanner._add(
                "sink",
                self.path,
                node.lineno,
                "regex_compile",
                "REGEX_DOS",
                f"{name} request-derived regex pattern review",
                {"callee": name, "request_derived_input": True},
                confidence="high",
            )
        origins = self._kwarg(node, "allow_origins")
        if origins is not None and any(
            isinstance(child, ast.Constant) and child.value == "*" for child in ast.walk(origins)
        ):
            credentials = self._kwarg(node, "allow_credentials")
            with_credentials = isinstance(credentials, ast.Constant) and credentials.value is True
            self.scanner._add(
                "sink",
                self.path,
                node.lineno,
                "cors_config",
                "SECURITY_MISCONFIG",
                f"{name} wildcard CORS origin review",
                {"callee": name, "allow_credentials": with_credentials},
                confidence="high" if with_credentials else "medium",
            )

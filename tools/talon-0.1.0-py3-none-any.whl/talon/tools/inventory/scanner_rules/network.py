"""ssrf.md / insecure_transport.md sinks and outbound-HTTP-client binding tracking."""

from __future__ import annotations

import ast

from talon.tools.inventory.scanner_rules.crypto_auth import JWT_MODULE_SEGMENTS
from talon.tools.inventory.scanner_rules.helpers import ScanHelpersMixin


# ssrf.md: outbound HTTP clients where the URL is not a literal.
_HTTP_CLIENT_MODULES = frozenset({"requests", "httpx", "aiohttp", "urllib3"})
_HTTP_CLIENT_METHODS = frozenset(
    {"get", "post", "put", "delete", "patch", "head", "options", "request", "ws_connect"}
)
# Constructors that return a reusable client/session bound to a variable. A later
# ``client.get(url)`` on such a binding is an outbound request the module-root match
# cannot see (the call root is the variable, not the module); this is the dominant idiom
# for httpx.Client, requests.Session, and all of aiohttp. Matched on the constructor's
# lowercased dotted name; bindings tracked per-file in PythonVisitor.
_HTTP_CLIENT_CONSTRUCTORS = frozenset(
    {
        "requests.session",
        "httpx.client",
        "httpx.asyncclient",
        "aiohttp.clientsession",
        "urllib3.poolmanager",
        "urllib3.proxymanager",
    }
)


class NetworkSinksMixin(ast.NodeVisitor, ScanHelpersMixin):
    """Inherits ``ast.NodeVisitor`` (in addition to the shared ``PythonVisitor``
    base) so ``visit_With``/``visit_AsyncWith`` are recognized as dispatch
    overrides rather than flagged by naming-convention lint."""

    def visit_With(self, node: ast.With) -> None:
        self._track_with_client(node)
        self.generic_visit(node)

    def visit_AsyncWith(self, node: ast.AsyncWith) -> None:
        self._track_with_client(node)
        self.generic_visit(node)

    def _track_with_client(self, node: ast.With | ast.AsyncWith) -> None:
        """``with aiohttp.ClientSession() as s:`` binds ``s`` to a client — the aiohttp
        (and common httpx) idiom, which is a With item, not an Assign."""
        for item in node.items:
            if isinstance(item.context_expr, ast.Call) and item.optional_vars is not None:
                self._track_http_client_binding(item.context_expr, [item.optional_vars])

    def _track_http_client_binding(self, call: ast.Call, targets: list[ast.expr]) -> None:
        if self._call_name(call).lower() not in _HTTP_CLIENT_CONSTRUCTORS:
            return
        for target in targets:
            name = self._name(target)
            if name:
                self._http_client_vars.add(name.lower())

    def _add_ssrf_sink(self, node: ast.Call, name: str, lower: str) -> None:
        """ssrf.md: outbound request whose URL is not a fixed literal."""
        segments = lower.split(".")
        method = segments[-1]
        receiver = lower.rsplit(".", 1)[0] if "." in lower else ""
        # A method call on a variable bound to an HTTP client/session constructor
        # (httpx.Client / requests.Session / aiohttp.ClientSession) — the module-root
        # match below cannot see these because the root is the variable name.
        is_bound_client = (
            method in _HTTP_CLIENT_METHODS and bool(receiver) and receiver in self._http_client_vars
        )
        is_http_client = (
            (
                len(segments) >= 2
                and segments[0] in _HTTP_CLIENT_MODULES
                and method in _HTTP_CLIENT_METHODS
            )
            or is_bound_client
            or (
                method == "urlopen"
                and (len(segments) == 1 or "urllib" in segments or "request" in segments)
            )
        )
        if not is_http_client:
            return
        # ``request("GET", url)`` / ``ws_connect(url)`` carry the URL as the 2nd / 1st
        # positional; ``get(url)`` as the 1st. Prefer the explicit ``url=`` kwarg.
        positional_url = (
            self._positional_arg(node, 1) if method == "request" else self._first_arg(node)
        )
        url = self._kwarg(node, "url") or positional_url
        if url is None:
            return
        if isinstance(url, ast.Constant):
            # insecure_transport.md: fixed plaintext-HTTP endpoint.
            if isinstance(url.value, str) and url.value.startswith("http://"):
                self.scanner._add(
                    "sink",
                    self.path,
                    node.lineno,
                    "outbound_request",
                    "INSECURE_TRANSPORT",
                    f"{name} plaintext HTTP endpoint review",
                    {"callee": name},
                    confidence="medium",
                )
            return
        request_derived = self._contains_request_data(node)
        self.scanner._add(
            "sink",
            self.path,
            node.lineno,
            "outbound_request",
            "SSRF",
            f"{name} outbound request with dynamic URL review",
            {"callee": name, "request_derived_input": request_derived},
            confidence="high" if request_derived else "medium",
        )

    def _add_transport_sink(self, node: ast.Call, name: str, lower: str) -> None:
        """insecure_transport.md: TLS verification disabled at a call site."""
        segments = lower.split(".")
        # Only jwt.decode's verify=False belongs to JWT_VALIDATION; scope the exclusion to
        # callee==decode. A verify=False on any OTHER call whose dotted path merely
        # *contains* a jwt-ish segment (e.g. jwt.session.get(url, verify=False)) is a
        # genuine TLS bug and must NOT be swallowed here.
        if segments[-1] == "decode" and any(seg in JWT_MODULE_SEGMENTS for seg in segments[:-1]):
            return
        verify = self._kwarg(node, "verify")
        if isinstance(verify, ast.Constant) and verify.value is False:
            self.scanner._add(
                "sink",
                self.path,
                node.lineno,
                "tls_config",
                "INSECURE_TRANSPORT",
                f"{name} certificate verification disabled review",
                {"callee": name, "verify": False},
                confidence="high",
            )
        cert_reqs = self._kwarg(node, "cert_reqs")
        if cert_reqs is not None and self._name(cert_reqs).endswith("CERT_NONE"):
            self.scanner._add(
                "sink",
                self.path,
                node.lineno,
                "tls_config",
                "INSECURE_TRANSPORT",
                f"{name} CERT_NONE certificate policy review",
                {"callee": name},
                confidence="high",
            )
        if segments[-1] == "_create_unverified_context":
            self.scanner._add(
                "sink",
                self.path,
                node.lineno,
                "tls_config",
                "INSECURE_TRANSPORT",
                f"{name} unverified TLS context review",
                {"callee": name},
                confidence="high",
            )

"""xss.md / open_redirect.md / mass_assignment.md / command_injection.md /
information_exposure.md / log_injection.md sinks — output encoding, redirects, write-path
exposure, and unsanitized log writes."""

from __future__ import annotations

import ast

from talon.tools.inventory.scanner_rules.helpers import ScanHelpersMixin


# CWE-200 sensitive data exposure: response/serialization constructors that can emit a
# whole data object outward. Flagged only when the argument is a whole-object DUMP
# (``.__dict__`` / ``vars()`` / an unbounded ``.values()``), i.e. no field allowlist.
_RESPONSE_CTORS = {"JsonResponse", "Response", "jsonify", "HttpResponse"}
_UNBOUNDED_QUERY_METHODS = ("values", "values_list")

# command_injection.md: full subprocess surface + os.exec*/os.spawn* families.
_COMMAND_SINK_CALLS = frozenset(
    {
        "eval",
        "exec",
        "os.system",
        "subprocess.call",
        "subprocess.run",
        "subprocess.check_output",
        "subprocess.check_call",
        "subprocess.getoutput",
        "subprocess.getstatusoutput",
        "popen",
    }
)
# code_injection.md: dynamic code loading beyond eval/exec.
_DYNAMIC_CODE_CALLS = frozenset({"compile", "__import__"})

# log_injection.md (CWE-117): untrusted input written into a log record. Parameterisation
# does NOT sanitize a log message (lazy %-args are still not CR/LF-neutralized), so the sink
# is any logging call carrying request-derived input — not only concatenated ones.
_LOG_METHODS = frozenset(
    {"debug", "info", "warning", "warn", "error", "critical", "exception", "fatal", "log"}
)


def _is_logger_receiver(receiver: str) -> bool:
    lower = receiver.lower()
    return lower in {"log", "logger", "logging"} or lower.endswith(("logger", "_log"))


class WebOutputSinksMixin(ScanHelpersMixin):
    def _dumps_whole_object(self, node: ast.Call) -> bool:
        # A whole-object dump anywhere in the argument subtree: ``x.__dict__``,
        # ``vars(x)``, or an unbounded ``.values()`` / ``.values_list()`` (no field args).
        for child in ast.walk(node):
            if isinstance(child, ast.Attribute) and child.attr == "__dict__":
                return True
            if isinstance(child, ast.Call):
                callee = self._call_name(child)
                if callee == "vars":  # exact builtin only; endswith matched get_vars/env_vars
                    return True
                if (
                    isinstance(child.func, ast.Attribute)
                    and child.func.attr in _UNBOUNDED_QUERY_METHODS
                    and not child.args
                ):
                    return True
        return False

    def _add_response_exposure(self, node: ast.Call, name: str) -> None:
        is_response_ctor = name in _RESPONSE_CTORS or name.endswith(
            (".JsonResponse", ".Response", ".jsonify")
        )
        if is_response_ctor and self._dumps_whole_object(node):
            self.scanner._add(
                "sink",
                self.path,
                node.lineno,
                "response_body",
                "EXPOSURE",
                f"{name} whole-object response exposure review",
                {"callee": name, "field_policy": "unbounded"},
                confidence="medium",
            )

    def _add_log_injection_sink(self, node: ast.Call, name: str) -> None:
        """log_injection.md (CWE-117): request-derived input reaching a logging call.

        Parameterised %-args are NOT the safe shape here (logging does not neutralize CR/LF
        in them), so any log call carrying request data is a candidate; constants and
        internal-only values are not.
        """
        segments = name.split(".")
        if len(segments) < 2 or segments[-1] not in _LOG_METHODS:
            return
        if not _is_logger_receiver(segments[-2]):
            return
        if not self._contains_request_data(node):
            return
        self.scanner._add(
            "sink",
            self.path,
            node.lineno,
            "log_write",
            "LOG_INJECTION",
            f"{name} unsanitized log write review",
            {"callee": name, "request_derived_input": True},
            confidence="high",
        )

    def _add_redirect_sink(self, node: ast.Call, name: str, lower: str) -> None:
        if name in {"redirect", "HttpResponseRedirect", "RedirectResponse"} or lower.endswith(
            ".redirect"
        ):
            request_derived = self._contains_request_data(node)
            self.scanner._add(
                "sink",
                self.path,
                node.lineno,
                "redirect_sink",
                "OPEN_REDIRECT",
                f"{name} open redirect review",
                {"callee": name, "request_derived_input": request_derived},
                framework="django" if self.scanner.profile in {"auto", "django"} else None,
                confidence="high" if request_derived else "medium",
            )

    def _add_output_sinks(self, node: ast.Call, name: str, lower: str) -> None:
        if name in {"mark_safe", "format_html"} or lower.endswith(".html"):
            self.scanner._add(
                "sink",
                self.path,
                node.lineno,
                "template_output",
                "XSS",
                f"{name} output encoding review",
                {"callee": name, "request_derived_input": self._contains_request_data(node)},
                framework="django" if name in {"mark_safe", "format_html"} else None,
            )
        if name in {"HttpResponse", "render"} and self._contains_request_data(node):
            self.scanner._add(
                "sink",
                self.path,
                node.lineno,
                "template_output",
                "XSS",
                f"{name} reflected output review",
                {"callee": name, "request_derived_input": True},
                framework="django",
            )
        if (
            (
                name == "HttpResponse"
                or name.endswith(".HttpResponse")
                or name
                in {"HttpResponseBadRequest", "HttpResponseNotFound", "HttpResponseServerError"}
            )
            and node.args
            and isinstance(node.args[0], ast.BinOp)
        ):
            self.scanner._add(
                "sink",
                self.path,
                node.lineno,
                "template_output",
                "XSS",
                f"{name} concatenated reflected output review",
                {"callee": name, "concatenation": True},
                framework="django",
                confidence="medium",
            )

    def _add_write_sinks(self, node: ast.Call, name: str, lower: str) -> None:
        if name.endswith(
            ("objects.create", "objects.update", ".save")
        ) and self._contains_request_data(node):
            self.scanner._add(
                "sink",
                self.path,
                node.lineno,
                "model_binding",
                "MASS_ASSIGNMENT",
                f"{name} request-derived model write review",
                {"callee": name, "request_derived_input": True},
                framework="django" if self.scanner.profile in {"auto", "django"} else None,
            )
        if (
            lower in _COMMAND_SINK_CALLS
            or lower.endswith(".popen")
            or lower.startswith(("os.exec", "os.spawn"))
        ):
            shell_kwarg = self._kwarg(node, "shell")
            shell_true = isinstance(shell_kwarg, ast.Constant) and shell_kwarg.value is True
            request_derived = self._contains_request_data(node)
            self.scanner._add(
                "sink",
                self.path,
                node.lineno,
                "command_sink",
                "RCE",
                f"{name} command execution review",
                {
                    "callee": name,
                    "request_derived_input": request_derived,
                    "shell_true": shell_true,
                },
                confidence="high" if (request_derived or shell_true) else "medium",
            )
        if lower in _DYNAMIC_CODE_CALLS or lower.endswith(".import_module"):
            self.scanner._add(
                "sink",
                self.path,
                node.lineno,
                "command_sink",
                "RCE",
                f"{name} dynamic code loading review",
                {"callee": name, "request_derived_input": self._contains_request_data(node)},
                confidence="medium",
            )
        if name == "setattr" and self._contains_request_data(node):
            self.scanner._add(
                "sink",
                self.path,
                node.lineno,
                "model_binding",
                "MASS_ASSIGNMENT",
                f"{name} request-derived attribute write review",
                {"callee": name, "request_derived_input": True},
                framework="django" if self.scanner.profile in {"auto", "django"} else None,
            )
        if name.endswith(".update") and (
            "__dict__" in name or any(keyword.arg is None for keyword in node.keywords)
        ):
            self.scanner._add(
                "sink",
                self.path,
                node.lineno,
                "model_binding",
                "MASS_ASSIGNMENT",
                f"{name} bulk field update review",
                {"callee": name, "bulk_update": True},
                framework="django" if self.scanner.profile in {"auto", "django"} else None,
                confidence="high",
            )

    def _add_serialization_and_file_sinks(self, node: ast.Call, name: str) -> None:
        if name == "model_to_dict" and not any(
            keyword.arg == "fields" for keyword in node.keywords
        ):
            self.scanner._add(
                "sink",
                self.path,
                node.lineno,
                "serializer_output",
                "EXPOSURE",
                f"{name} unrestricted field serialization review",
                {"callee": name, "field_policy": "unbounded"},
                framework="django",
                confidence="high",
            )
        if name == "open" and self._contains_request_data(node):
            self.scanner._add(
                "sink",
                self.path,
                node.lineno,
                "file_path",
                "PATH_TRAVERSAL",
                f"{name} request-derived file path review",
                {"callee": name, "request_derived_input": True},
                confidence="high",
            )
        if name.endswith(".serialize") or name == "serialize":
            self.scanner._add(
                "sink",
                self.path,
                node.lineno,
                "serializer_output",
                "EXPOSURE",
                f"{name} serialized queryset exposure review",
                {"callee": name},
                framework="django",
                confidence="medium",
            )
        if name.endswith("storage.save"):
            self.scanner._add(
                "sink",
                self.path,
                node.lineno,
                "file_path",
                "PATH_TRAVERSAL",
                f"{name} stored file path review",
                {"callee": name},
                framework="django",
                confidence="medium",
            )

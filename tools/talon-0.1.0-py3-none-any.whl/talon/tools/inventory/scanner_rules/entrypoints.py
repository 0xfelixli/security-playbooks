"""Django-style handler/view/admin/task entrypoints, class-based views, and settings
misconfiguration detection — the ``visit_FunctionDef``/``visit_ClassDef`` AST dispatch."""

from __future__ import annotations

import ast

from talon.tools.inventory.scanner_rules.helpers import ScanHelpersMixin


class EntrypointSinksMixin(ast.NodeVisitor, ScanHelpersMixin):
    """Inherits ``ast.NodeVisitor`` (in addition to the shared ``PythonVisitor``
    base) so ``visit_FunctionDef``/``visit_ClassDef`` are recognized as dispatch
    overrides rather than flagged by naming-convention lint."""

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        self._visit_function_def(node)

    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> None:
        self._visit_function_def(node)

    def _visit_function_def(self, node: ast.FunctionDef | ast.AsyncFunctionDef) -> None:
        lowered = node.name.lower()
        decorator_names = [self._name(decorator).lower() for decorator in node.decorator_list]
        has_request_param = any(arg.arg == "request" for arg in node.args.args)
        is_route_decorated = any(
            name.endswith((".get", ".post", ".put", ".patch", ".delete"))
            or "route" in name
            or "mapping" in name
            or "csrf_exempt" in name
            for name in decorator_names
        )
        is_viewish = (
            "view" in lowered or "admin" in lowered or has_request_param or is_route_decorated
        )
        if is_viewish:
            self.scanner._add(
                "handler",
                self.path,
                node.lineno,
                "http_handler",
                "BFLA",
                f"{node.name} authorization review",
                {"symbol": node.name, "decorators": decorator_names},
                framework="django" if self.scanner.profile in {"auto", "django"} else None,
            )
        if "admin" in lowered:
            self.scanner._add(
                "handler",
                self.path,
                node.lineno,
                "admin_view",
                "BFLA",
                f"{node.name} admin authorization review",
                {"symbol": node.name},
                framework="django",
                confidence="high",
            )
        if any("csrf_exempt" in dec for dec in decorator_names):
            self.scanner._add(
                "sink",
                self.path,
                node.lineno,
                "csrf_config",
                "CSRF",
                f"{node.name} CSRF protection disabled review",
                {"symbol": node.name},
                framework="django",
                confidence="high",
            )
        is_task = any(
            dec in {"shared_task", "periodic_task", "task"} or dec.endswith(".task")
            for dec in decorator_names
        )
        if is_task:
            # celery.md: queue tasks are remote entrypoints — their args are untrusted
            # input reaching sinks without any HTTP-layer guard.
            self.scanner._add(
                "handler",
                self.path,
                node.lineno,
                "task_entrypoint",
                "QUEUE_INJECTION",
                f"{node.name} queue task input handling review",
                {"symbol": node.name, "decorators": decorator_names},
                confidence="medium",
            )
        is_signal = any(dec == "receiver" or dec.endswith(".receiver") for dec in decorator_names)
        if is_signal:
            # signals are event entrypoints — receiver args carry model/event data reaching
            # sinks with no HTTP-layer guard (django.dispatch / blinker).
            self.scanner._add(
                "handler",
                self.path,
                node.lineno,
                "signal_receiver",
                "QUEUE_INJECTION",
                f"{node.name} signal receiver input handling review",
                {"symbol": node.name, "decorators": decorator_names},
                confidence="medium",
            )
        call_names = [
            self._call_name(call) for call in ast.walk(node) if isinstance(call, ast.Call)
        ]
        sets_auth_session = any(name == "login" or name.endswith(".login") for name in call_names)
        rotates = any(
            name.endswith(("cycle_key", "flush", "cycle_session_key")) for name in call_names
        )
        if sets_auth_session and not rotates:
            self.scanner._add(
                "handler",
                self.path,
                node.lineno,
                "auth_session",
                "SESSION_FIXATION",
                f"{node.name} session rotation review",
                {"symbol": node.name, "logs_in": True, "rotates_session": False},
                framework="django",
                confidence="high",
            )
        self.generic_visit(node)

    def visit_ClassDef(self, node: ast.ClassDef) -> None:
        base_names = [self._name(base) for base in node.bases]
        lowered = node.name.lower()
        is_view = any(
            base.endswith(("View", "APIView", "ViewSet", "ModelViewSet")) for base in base_names
        )
        if is_view or "admin" in lowered:
            construct = "admin_view" if "admin" in lowered else "http_handler"
            self.scanner._add(
                "handler",
                self.path,
                node.lineno,
                construct,
                "BFLA",
                f"{node.name} authorization review",
                {"symbol": node.name, "bases": base_names},
                framework="django" if self.scanner.profile in {"auto", "django"} else None,
                confidence="high" if construct == "admin_view" else "medium",
            )
        is_command = any(base.endswith("BaseCommand") for base in base_names)
        is_middleware = lowered.endswith("middleware") or any(
            base.endswith(("Middleware", "MiddlewareMixin")) for base in base_names
        )
        is_consumer = any(base.endswith("Consumer") for base in base_names)
        if is_command:
            # management commands are operational entrypoints; args/options are untrusted
            # input and they usually run with elevated privilege (framework_django.md).
            self.scanner._add(
                "handler",
                self.path,
                node.lineno,
                "management_command",
                "BFLA",
                f"{node.name} management command input/authorization review",
                {"symbol": node.name, "bases": base_names},
                framework="django",
                confidence="medium",
            )
        if is_middleware:
            # middleware sees every request — a control point to audit for auth-bypass /
            # ordering gaps, not a mere pass-through.
            self.scanner._add(
                "handler",
                self.path,
                node.lineno,
                "middleware_handler",
                "BFLA",
                f"{node.name} middleware control-point review",
                {"symbol": node.name, "bases": base_names},
                confidence="medium",
            )
        if is_consumer:
            # channels / MQ consumers receive messages outside the HTTP layer — payloads are
            # untrusted input reaching sinks with no request-layer guard.
            self.scanner._add(
                "handler",
                self.path,
                node.lineno,
                "message_consumer",
                "QUEUE_INJECTION",
                f"{node.name} message consumer input handling review",
                {"symbol": node.name, "bases": base_names},
                confidence="medium",
            )
        is_serializer = any("Serializer" in base for base in base_names) or "serializer" in lowered
        is_form = any("Form" in base for base in base_names) or lowered.endswith("form")
        if is_serializer:
            self.scanner._add(
                "sink",
                self.path,
                node.lineno,
                "serializer_output",
                "EXPOSURE",
                f"{node.name} serialized data exposure review",
                {"symbol": node.name, "bases": base_names},
                framework="django",
            )
        if is_form:
            self.scanner._add(
                "sink",
                self.path,
                node.lineno,
                "model_binding",
                "MASS_ASSIGNMENT",
                f"{node.name} model binding review",
                {"symbol": node.name, "bases": base_names},
                framework="django",
            )
        for child in ast.walk(node):
            if isinstance(child, ast.Assign):
                self._add_field_policy_units(
                    node, child, is_serializer=is_serializer, is_form=is_form
                )
        self.generic_visit(node)

    def _add_field_policy_units(
        self,
        class_node: ast.ClassDef,
        assign: ast.Assign,
        *,
        is_serializer: bool,
        is_form: bool,
    ) -> None:
        targets = [self._name(target) for target in assign.targets]
        if "fields" not in targets or not self._literal_all(assign.value):
            return
        if is_serializer:
            self.scanner._add(
                "sink",
                self.path,
                assign.lineno,
                "serializer_output",
                "EXPOSURE",
                f"{class_node.name} fields='__all__' exposure review",
                {"symbol": class_node.name, "field_policy": "__all__"},
                framework="django",
                confidence="high",
            )
        if is_form:
            self.scanner._add(
                "sink",
                self.path,
                assign.lineno,
                "model_binding",
                "MASS_ASSIGNMENT",
                f"{class_node.name} fields='__all__' mass assignment review",
                {"symbol": class_node.name, "field_policy": "__all__"},
                framework="django",
                confidence="high",
            )

    def _add_settings_misconfig(self, node: ast.Assign) -> None:
        """framework_django.md: production-config red flags, only in settings modules."""
        if "settings" not in self.path.name.lower():
            return
        for target in node.targets:
            target_name = self._name(target)
            if (
                target_name == "DEBUG"
                and isinstance(node.value, ast.Constant)
                and node.value.value is True
            ):
                self.scanner._add(
                    "sink",
                    self.path,
                    node.lineno,
                    "framework_config",
                    "SECURITY_MISCONFIG",
                    "DEBUG=True production configuration review",
                    {"target": target_name},
                    framework="django",
                    confidence="medium",
                )
            if target_name == "ALLOWED_HOSTS" and any(
                isinstance(child, ast.Constant) and child.value == "*"
                for child in ast.walk(node.value)
            ):
                self.scanner._add(
                    "sink",
                    self.path,
                    node.lineno,
                    "framework_config",
                    "SECURITY_MISCONFIG",
                    "ALLOWED_HOSTS wildcard configuration review",
                    {"target": target_name},
                    framework="django",
                    confidence="medium",
                )

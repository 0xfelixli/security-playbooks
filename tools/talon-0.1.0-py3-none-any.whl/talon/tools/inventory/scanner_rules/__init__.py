"""Domain-grouped ``PythonVisitor`` sink-detection mixins.

Each module holds the ``_add_*_sink`` methods for one vulnerability domain, composed
together onto ``PythonVisitor`` in ``talon/tools/inventory/scanner.py``. Split out of a
single 1200+ line class so each domain's detection rules are reviewable independently.
"""

from __future__ import annotations

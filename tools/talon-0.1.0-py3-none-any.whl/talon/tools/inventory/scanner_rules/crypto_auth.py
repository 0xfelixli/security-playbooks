"""crypto_misuse / authentication_jwt.md / session_fixation.md sinks."""

from __future__ import annotations

import ast

from talon.tools.inventory.scanner_rules.helpers import ScanHelpersMixin


# Symmetric-cipher constructors (pyca/cryptography, PyCryptodome, pyDes …). A
# ``<Cipher>.new(...)`` or bare ``Cipher(...)`` call needs a crypto review: mode (ECB),
# key/IV provenance, and IV reuse are only judgeable at the call site.
_CIPHER_CTORS = {
    "AES",
    "DES",
    "DES3",
    "ARC2",
    "ARC4",
    "RC4",
    "Blowfish",
    "CAST",
    "ChaCha20",
    "Salsa20",
    "XOR",
}
# Broken / risky hash primitives (CWE-327/328). Common in non-security contexts too,
# so these are surfaced for review, not asserted as bugs.
_WEAK_HASH_CALLS = {"md5", "sha1", "hashlib.md5", "hashlib.sha1"}

# authentication_jwt.md: jwt.decode red flags — disabled verification, no algorithm
# allowlist, alg=none. Also consulted by scanner_rules.network to exclude jwt.decode's
# verify=False from the generic INSECURE_TRANSPORT check (it's JWT_VALIDATION's domain).
JWT_MODULE_SEGMENTS = frozenset({"jwt", "pyjwt", "jose"})


class CryptoAuthSinksMixin(ScanHelpersMixin):
    def _add_jwt_sink(self, node: ast.Call, name: str, lower: str) -> None:
        """authentication_jwt.md: decode without verification / allowlist / alg=none."""
        segments = lower.split(".")
        if segments[-1] != "decode" or not any(seg in JWT_MODULE_SEGMENTS for seg in segments[:-1]):
            return
        red_flags: list[str] = []
        verify = self._kwarg(node, "verify")
        if isinstance(verify, ast.Constant) and verify.value is False:
            red_flags.append("verify=False")
        options = self._kwarg(node, "options")
        if isinstance(options, ast.Dict):
            for key, value in zip(options.keys, options.values, strict=False):
                if (
                    isinstance(key, ast.Constant)
                    and key.value == "verify_signature"
                    and isinstance(value, ast.Constant)
                    and value.value is False
                ):
                    red_flags.append("verify_signature=False")
        algorithms = self._kwarg(node, "algorithms")
        if algorithms is None:
            red_flags.append("no algorithms allowlist")
        elif any(
            isinstance(child, ast.Constant) and str(child.value).lower() == "none"
            for child in ast.walk(algorithms)
        ):
            red_flags.append("alg=none allowed")
        self.scanner._add(
            "sink",
            self.path,
            node.lineno,
            "auth_token",
            "JWT_VALIDATION",
            f"{name} token verification review",
            {"callee": name, "red_flags": red_flags},
            confidence="high" if red_flags else "medium",
        )

    def _add_session_cookie_sink(self, node: ast.Call, name: str) -> None:
        if name != "set_cookie" and not name.endswith(".set_cookie"):
            return
        if not node.args:
            return
        first_arg = node.args[0]
        cookie_name = (
            first_arg.value
            if isinstance(first_arg, ast.Constant) and isinstance(first_arg.value, str)
            else ""
        )
        if any(token in cookie_name.lower() for token in ("auth", "session", "token", "sid")):
            self.scanner._add(
                "sink",
                self.path,
                node.lineno,
                "auth_session",
                "SESSION_FIXATION",
                f"{name} auth cookie lifecycle/rotation review",
                {"callee": name, "cookie": cookie_name},
                framework="django",
                confidence="medium",
            )

    def _add_crypto_sink(self, node: ast.Call, name: str, lower: str) -> None:
        """Surface symmetric-crypto constructs so a crypto review is always seeded.

        Covers cipher construction (``AES.new`` / ``Cipher(...)`` / ``Fernet(...)``), raw
        encrypt/decrypt, weak hash primitives, and custom padding routines. Mode (ECB),
        static/reused IV, hardcoded keys and padding-oracle risks are only decidable at
        the call site, so every construct becomes a WEAK_CRYPTO unit to confirm or refute.
        """
        segments = name.split(".")
        is_cipher_new = name.endswith(".new") and any(seg in _CIPHER_CTORS for seg in segments)
        if is_cipher_new or name in ("Cipher", "Fernet") or name.endswith((".Cipher", ".Fernet")):
            self.scanner._add(
                "sink",
                self.path,
                node.lineno,
                "crypto_primitive",
                "WEAK_CRYPTO",
                f"{name} cipher construction review (mode/IV/key provenance)",
                {"callee": name},
                confidence="high",
            )
        if name in {"encrypt", "decrypt"} or name.endswith((".encrypt", ".decrypt")):
            self.scanner._add(
                "sink",
                self.path,
                node.lineno,
                "crypto_operation",
                "WEAK_CRYPTO",
                f"{name} encrypt/decrypt review (mode/IV/padding)",
                {"callee": name},
                confidence="medium",
            )
        if lower in _WEAK_HASH_CALLS or lower.endswith((".md5", ".sha1")):
            self.scanner._add(
                "sink",
                self.path,
                node.lineno,
                "weak_hash",
                "WEAK_CRYPTO",
                f"{name} weak hash algorithm review (MD5/SHA1)",
                {"callee": name},
                confidence="medium",
            )
        if name in {"pad", "unpad"} or name.endswith((".pad", ".unpad")):
            self.scanner._add(
                "sink",
                self.path,
                node.lineno,
                "crypto_padding",
                "WEAK_CRYPTO",
                f"{name} padding routine review (padding oracle / custom pad)",
                {"callee": name},
                confidence="low",
            )

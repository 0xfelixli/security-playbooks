"""secrets.md / hardcoded_credentials.md / plaintext_password_storage.md sinks."""

from __future__ import annotations

import ast
import re

from talon.tools.inventory.scanner_rules.helpers import ScanHelpersMixin


# CWE-798 hardcoded credentials. A name/keyword/dict-key matching this lexicon whose
# value is a STRING LITERAL (not an env/secret-store read, which is a Call/reference)
# is a credential-embedding candidate. Framework-agnostic.
_CRED_NAME_RE = re.compile(
    r"(password|passwd|pwd|secret[_-]?key|secret|api[_-]?key|apikey|access[_-]?token"
    r"|auth[_-]?token|refresh[_-]?token|private[_-]?key|client[_-]?secret|passphrase"
    r"|credential)",
    re.I,
)
# Literal values that are placeholders, not real secrets → seed at low confidence so
# they never block finishing but still get an explicit review.
_CRED_PLACEHOLDERS = frozenset(
    {
        "",
        "changeme",
        "change-me",
        "password",
        "secret",
        "xxx",
        "todo",
        "none",
        "null",
        "example",
        "test",
        "placeholder",
        "your-key-here",
        "changethis",
    }
)
_CRED_MIN_LEN = 6

# secrets.md: literal VALUES that are recognisable secret material regardless of the
# variable name they are assigned to.
_SECRET_VALUE_RE = re.compile(r"^(AKIA[0-9A-Z]{12,}|sk_live_\w{8,}|sk_test_\w{8,})")

# CWE-256/257/319 plaintext password storage. A write to a password-named target whose
# value did NOT pass through a one-way hash/KDF. The callee substring match catches the
# common hashing helpers across frameworks; anything else stored is a candidate.
_PASSWORD_NAME_RE = re.compile(r"(password|passwd|pwd)", re.I)
_HASHING_CALLS = (
    "make_password",
    "set_password",
    "hash_password",
    "bcrypt",
    "argon2",
    "scrypt",
    "pbkdf2",
    "hashlib",
    "passlib",
    "pwd_context",
    "generate_password_hash",
)
# ORM field constructors — a password field declaration is a low-confidence storage
# obligation: verify the save path hashes before persisting.
_ORM_FIELD_CTORS = ("CharField", "TextField", "BinaryField")


class CredentialSinksMixin(ScanHelpersMixin):
    def _is_hashing_call(self, node: ast.AST) -> bool:
        if not isinstance(node, ast.Call):
            return False
        callee = self._call_name(node).lower()
        return any(h in callee for h in _HASHING_CALLS)

    def _add_plaintext_password(self, node: ast.Assign) -> None:
        rhs = node.value
        # Dynamic write to a password attribute (obj.password = <expr>) that is neither a
        # literal (hardcoded-credentials' domain) nor a hash/KDF result → plaintext store.
        if not isinstance(rhs, ast.Constant) and not self._is_hashing_call(rhs):
            for target in node.targets:
                if isinstance(target, ast.Attribute) and _PASSWORD_NAME_RE.search(target.attr):
                    self.scanner._add(
                        "sink",
                        self.path,
                        node.lineno,
                        "password_write",
                        "PLAINTEXT_PASSWORD_STORAGE",
                        f"{self._name(target)} plaintext password storage review",
                        {"target": self._name(target)},
                        confidence="medium",
                    )
        # Model field declaration (password = models.CharField(...)) — low-confidence
        # obligation to verify the save path hashes before persisting.
        if isinstance(rhs, ast.Call) and self._call_name(rhs).endswith(_ORM_FIELD_CTORS):
            for target in node.targets:
                if isinstance(target, ast.Name) and _PASSWORD_NAME_RE.search(target.id):
                    self.scanner._add(
                        "sink",
                        self.path,
                        node.lineno,
                        "password_field",
                        "PLAINTEXT_PASSWORD_STORAGE",
                        f"{target.id} password field storage review (verify hashing on save)",
                        {"field": target.id},
                        confidence="low",
                    )

    def _emit_credential(self, name: str, value: str, lineno: int) -> None:
        placeholder = value.strip().lower() in _CRED_PLACEHOLDERS or len(value) < _CRED_MIN_LEN
        self.scanner._add(
            "sink",
            self.path,
            lineno,
            "credential_literal",
            "HARDCODED_CREDENTIALS",
            f"{name} hardcoded credential review",
            {"target": name, "placeholder_like": placeholder},
            confidence="low" if placeholder else "medium",
        )

    def _add_hardcoded_credentials(self, node: ast.Assign) -> None:
        # NAME = "literal" where NAME is credential-shaped. Only string literals qualify;
        # env/secret-store reads are Calls/references and are correctly ignored.
        literal = self._string_literal(node.value)
        if literal is not None:
            for target in node.targets:
                target_name = self._name(target)
                if target_name and _CRED_NAME_RE.search(target_name):
                    self._emit_credential(target_name, literal, node.lineno)
                elif target_name and _SECRET_VALUE_RE.match(literal):
                    # secrets.md: the VALUE itself is recognisable secret material
                    # (AWS key id, Stripe key) regardless of the variable name.
                    self.scanner._add(
                        "sink",
                        self.path,
                        node.lineno,
                        "credential_literal",
                        "HARDCODED_CREDENTIALS",
                        f"{target_name} recognisable secret value review",
                        {"target": target_name, "value_prefix_match": True},
                        confidence="high",
                    )
        # CONFIG = {"api_key": "literal", ...}
        if isinstance(node.value, ast.Dict):
            for key, val in zip(node.value.keys, node.value.values, strict=False):
                key_str = self._string_literal(key) if key is not None else None
                val_str = self._string_literal(val)
                if key_str and val_str is not None and _CRED_NAME_RE.search(key_str):
                    self._emit_credential(key_str, val_str, node.lineno)

    def _add_credential_kwargs(self, node: ast.Call) -> None:
        # func(..., password="literal", ...) — credential-shaped keyword with a literal.
        for keyword in node.keywords:
            if keyword.arg is None:
                continue
            literal = self._string_literal(keyword.value)
            if literal is not None and _CRED_NAME_RE.search(keyword.arg):
                self._emit_credential(keyword.arg, literal, node.lineno)

"""sql_injection.md / code_injection.md (SSTI) / nosql_injection.md sinks."""

from __future__ import annotations

import ast

from talon.tools.inventory.scanner_rules.helpers import ScanHelpersMixin


# sql_injection.md / framework_django.md / framework_fastapi.md: DB-API cursors,
# SQLAlchemy text(), Django raw()/extra()/RawSQL. Only DYNAMICALLY BUILT statements
# (f-string / concat / .format / %) are sinks — parameterised constants are the safe shape.
_SQL_EXEC_METHODS = frozenset({"execute", "executemany", "executescript"})

# code_injection.md: user input becoming the template STRING itself is SSTI → RCE.
_SSTI_CALLS = frozenset({"render_template_string", "from_string"})

# nosql_injection.md: Mongo-style query methods fed a dict.
_NOSQL_QUERY_METHODS = frozenset({"find", "find_one", "find_one_and_update", "aggregate"})


class InjectionSinksMixin(ScanHelpersMixin):
    def _add_sql_sinks(self, node: ast.Call, name: str) -> None:
        """sql_injection.md: dynamically built SQL reaching an execution API.

        Parameterised constants (execute("... %s", params)) are the safe shape and never
        emit — only runtime-built statements (f-string / concat / .format / RawSQL) do.
        """
        segments = name.split(".")
        last = segments[-1]
        first = self._first_arg(node)
        if last in _SQL_EXEC_METHODS and self._is_dynamic_string(first):
            self.scanner._add(
                "sink",
                self.path,
                node.lineno,
                "sql_sink",
                "SQL_INJECTION",
                f"{name} dynamically built SQL statement review",
                {"callee": name, "dynamic_statement": True},
                confidence="high",
            )
        if last == "raw" and self._is_dynamic_string(first):
            self.scanner._add(
                "sink",
                self.path,
                node.lineno,
                "sql_sink",
                "SQL_INJECTION",
                f"{name} dynamically built raw SQL review",
                {"callee": name, "dynamic_statement": True},
                framework="django",
                confidence="high",
            )
        if last == "extra":
            dynamic = any(
                self._is_dynamic_string(child)
                for keyword in node.keywords
                if keyword.arg in {"where", "select", "tables"}
                for child in ast.walk(keyword.value)
            )
            if dynamic:
                self.scanner._add(
                    "sink",
                    self.path,
                    node.lineno,
                    "sql_sink",
                    "SQL_INJECTION",
                    f"{name} dynamic extra() clause review",
                    {"callee": name, "dynamic_statement": True},
                    framework="django",
                    confidence="high",
                )
        if last == "RawSQL":
            self.scanner._add(
                "sink",
                self.path,
                node.lineno,
                "sql_sink",
                "SQL_INJECTION",
                f"{name} raw SQL expression review",
                {"callee": name, "dynamic_statement": self._is_dynamic_string(first)},
                framework="django",
                confidence="high" if self._is_dynamic_string(first) else "medium",
            )
        if last == "text" and self._is_dynamic_string(first):
            self.scanner._add(
                "sink",
                self.path,
                node.lineno,
                "sql_sink",
                "SQL_INJECTION",
                f"{name} dynamically built SQL text() review",
                {"callee": name, "dynamic_statement": True},
                confidence="high",
            )

    def _add_ssti_sink(self, node: ast.Call, name: str) -> None:
        """code_injection.md SSTI: user input becoming the template STRING itself."""
        last = name.rsplit(".", 1)[-1]
        first = self._first_arg(node)
        if last == "Environment":
            # A Jinja2 Environment with autoescape off renders any interpolated value raw —
            # the engine-level XSS/SSTI enabler. Flag an explicit autoescape=False, or an
            # engine-like construction (jinja name / loader=) that leaves autoescape default.
            autoescape = self._kwarg(node, "autoescape")
            explicit_false = isinstance(autoescape, ast.Constant) and autoescape.value is False
            engine_like = "jinja" in name.lower() or self._kwarg(node, "loader") is not None
            if explicit_false or (engine_like and autoescape is None):
                self.scanner._add(
                    "sink",
                    self.path,
                    node.lineno,
                    "template_construction",
                    "SSTI",
                    f"{name} Jinja2 environment autoescape review",
                    {"callee": name, "autoescape_off": True},
                    confidence="medium",
                )
            return
        if first is None or isinstance(first, ast.Constant):
            return
        if last in _SSTI_CALLS:
            self.scanner._add(
                "sink",
                self.path,
                node.lineno,
                "template_construction",
                "SSTI",
                f"{name} dynamic template construction review",
                {"callee": name, "request_derived_input": self._contains_request_data(node)},
                confidence="high",
            )
        elif last == "Template" and name != "string.Template":
            self.scanner._add(
                "sink",
                self.path,
                node.lineno,
                "template_construction",
                "SSTI",
                f"{name} dynamic template construction review",
                {"callee": name},
                confidence="medium",
            )

    def _add_nosql_sink(self, node: ast.Call, name: str) -> None:
        """nosql_injection.md: Mongo-style query fed a dict with $where or request data."""
        last = name.rsplit(".", 1)[-1]
        first = self._first_arg(node)
        if last not in _NOSQL_QUERY_METHODS or not isinstance(first, ast.Dict):
            return
        has_where = any(
            isinstance(key, ast.Constant) and key.value == "$where"
            for key in first.keys
            if key is not None
        )
        request_derived = self._contains_request_data(first)
        if has_where or request_derived:
            self.scanner._add(
                "sink",
                self.path,
                node.lineno,
                "nosql_query",
                "NOSQL_INJECTION",
                f"{name} query operator injection review",
                {"callee": name, "server_side_js": has_where},
                confidence="high",
            )

"""Deterministic attack-surface inventory tools."""

"""Deterministic attack-surface inventory seeding for whitebox scans."""

from __future__ import annotations

import asyncio
import json
import logging
import posixpath
from pathlib import Path
from typing import Any

from agents import RunContextWrapper, function_tool

from talon.config import load_settings
from talon.tools.coverage.tools import _add_units_impl, is_entry
from talon.tools.inventory.scanner import list_eligible_source_files, run_inventory_scan


logger = logging.getLogger(__name__)

_DEFAULT_OUTPUT = ".talon-source-aware/inventory.json"
_VALID_PROFILES = {"auto", "generic", "django"}

# Every enumerated entry-role unit owes an explicit "is this authenticated / intentionally
# public?" answer (missing_authentication.md) — keyed on the derived coverage role.


def _auth_obligation_units(units: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Pair each enumerated entrypoint with a MISSING_AUTHENTICATION obligation unit.

    Absence-of-control (no ``@login_required`` is *no code*) is invisible to grep/semgrep and
    the construct seed, so it must be driven from entries, not sinks. Emitting one obligation
    per entry location forces the recall gate to demand an explicit auth disposition for every
    attack-surface entry — one per location (an entry with several units still owes a single
    auth answer).
    """
    obligations: list[dict[str, Any]] = []
    seen: set[str] = set()
    for unit in units:
        if not is_entry(unit):
            continue
        location = str(unit.get("location") or "")
        if not location or location in seen:
            continue
        seen.add(location)
        symbol = str((unit.get("evidence") or {}).get("symbol") or location)
        obligations.append(
            {
                "kind": "sink",
                "location": location,
                "title": f"{symbol} authentication/authorization presence review",
                "construct_type": "auth_obligation",
                "vulnerability_class": "MISSING_AUTHENTICATION",
                "confidence": "medium",
                "evidence": {
                    "obligation": "auth_presence",
                    "for_entry": unit.get("construct_type"),
                },
            }
        )
    return obligations


# Where the scanner is baked into the sandbox image as an importable subtree (see
# containers/Dockerfile — PYTHONPATH=/opt/talon-src makes its scanner_rules imports resolve).
_CONTAINER_SCANNER_PATH = "/opt/talon-src/talon/tools/inventory/scanner.py"
# Result envelope path RELATIVE to the container workspace root. Written at
# <workspace_root>/<this> and read back by the same relative path, because
# session.read() only accepts workspace-relative paths (an absolute /tmp path is
# rejected). The workspace root is writable even when a source subdir is a read-only mount.
_RESULT_REL_PATH = ".talon-inventory-result.json"


async def _run_inventory_in_container(
    session: Any,
    *,
    workspace_root: str,
    path: str,
    output_path: str,
    profile: str,
    max_files: int,
    include_files: list[str] | None = None,
) -> tuple[dict[str, Any], dict[str, Any], str | None]:
    """Run the inventory scanner INSIDE the container and read its result back.

    The Docker backend keeps the source tree in the container, so the stdlib scanner is
    baked into the image and exec'd there: it reads ``/workspace`` and writes a
    ``{summary, payload, err}`` envelope the host parses to seed coverage.
    """
    result_abs = posixpath.join(workspace_root, _RESULT_REL_PATH)
    exec_args = [
        "python3",
        _CONTAINER_SCANNER_PATH,
        "--workspace-root",
        workspace_root,
        "--path",
        path,
        "--output-path",
        output_path,
        "--profile",
        profile,
        "--max-files",
        str(max_files),
    ]
    if include_files is not None:
        exec_args += ["--include-files", json.dumps(include_files)]
    exec_args += ["--result-path", result_abs]
    try:
        result = await session.exec(*exec_args, shell=False, timeout=180)
    except Exception as e:  # noqa: BLE001 — any exec transport error becomes a seed failure
        return {}, {}, f"inventory scanner exec failed in container: {e!s}"

    if not result.ok():
        stderr = result.stderr.decode("utf-8", errors="replace")[-800:]
        return {}, {}, f"inventory scanner failed in container (exit {result.exit_code}): {stderr}"

    try:
        # session.read() only accepts workspace-relative paths (written above at the
        # absolute <workspace_root>/<rel>).
        raw = await session.read(Path(_RESULT_REL_PATH))
        envelope = json.loads(raw.read().decode("utf-8"))
    except Exception as e:  # noqa: BLE001 — a missing/unparseable envelope is a seed failure
        return {}, {}, f"could not read inventory result from container: {e!s}"

    return envelope.get("summary") or {}, envelope.get("payload") or {}, envelope.get("err")


async def list_source_inventory(ctx_inner: dict[str, Any]) -> tuple[list[str], bool, str | None]:
    """Gate-time filesystem denominator: the in-scope source files under the workspace.

    Dispatches the same way as seeding — in-container for the Docker backend (source lives
    there), on a host thread for the local backend — so the gate's file list uses the exact
    ``_is_eligible_source_file`` rules and ``_rel`` namespace as the seeded ``kind=file``
    units. Returns ``(rel_paths, capped, err)``; a transport/exec failure degrades to
    ``([], False, err)`` so the caller notes it and never blocks finish on an infra hiccup.
    """
    session = ctx_inner.get("sandbox_session")
    if session is None:
        return [], False, "no sandbox session"
    workspace_root = ctx_inner["workspace_layout"].workspace_root
    settings = load_settings()
    # Denominator walk cap must match the seeder (TALON_INVENTORY_MAX_FILES, default 20000);
    # otherwise the gate under-counts. The container CLI defaults to 4000, so pass it explicitly.
    max_files = settings.runtime.inventory_max_files
    if settings.runtime.runtime_backend == "docker":
        result_abs = posixpath.join(workspace_root, _RESULT_REL_PATH)
        try:
            result = await session.exec(
                "python3",
                _CONTAINER_SCANNER_PATH,
                "--workspace-root",
                workspace_root,
                "--path",
                ".",
                "--mode",
                "list-files",
                "--max-files",
                str(max_files),
                "--result-path",
                result_abs,
                shell=False,
                timeout=120,
            )
        except Exception as e:  # noqa: BLE001 — any exec transport error becomes a soft failure
            return [], False, f"source-file list exec failed in container: {e!s}"
        if not result.ok():
            stderr = result.stderr.decode("utf-8", errors="replace")[-400:]
            return (
                [],
                False,
                f"source-file list failed in container (exit {result.exit_code}): {stderr}",
            )
        try:
            raw = await session.read(Path(_RESULT_REL_PATH))
            envelope = json.loads(raw.read().decode("utf-8"))
        except Exception as e:  # noqa: BLE001 — a missing/unparseable envelope is a soft failure
            return [], False, f"could not read source-file list from container: {e!s}"
        files = envelope.get("files") or []
        return [str(f) for f in files], bool(envelope.get("capped")), envelope.get("err")
    files, capped, err = await asyncio.to_thread(
        list_eligible_source_files, workspace_root=workspace_root, path=".", max_files=max_files
    )
    return files, capped, err


async def _seed_static_inventory_impl(
    ctx_inner: dict[str, Any],
    path: str,
    output_path: str,
    profile: str,
    max_files: int,
    files: list[str] | None = None,
) -> dict[str, Any]:
    if ctx_inner.get("sandbox_session") is None:
        return {"success": False, "error": "No sandbox session in context", "added": 0}
    profile_norm = (profile or "auto").strip().lower()
    if profile_norm not in _VALID_PROFILES:
        return {
            "success": False,
            "error": f"profile must be one of: {', '.join(sorted(_VALID_PROFILES))}",
            "added": 0,
        }
    workspace_root = ctx_inner["workspace_layout"].workspace_root
    target_path = (path or ".").strip() or "."
    out_path = (output_path or _DEFAULT_OUTPUT).strip() or _DEFAULT_OUTPUT
    bounded_max_files = max(1, min(int(max_files or 4000), 20000))

    if load_settings().runtime.runtime_backend == "docker":
        # Source lives in the container; run the scanner there via session.exec.
        scanner_summary, inventory, err = await _run_inventory_in_container(
            ctx_inner["sandbox_session"],
            workspace_root=workspace_root,
            path=target_path,
            output_path=out_path,
            profile=profile_norm,
            max_files=bounded_max_files,
            include_files=files,
        )
    else:
        # Local backend: workspace_root is a real host path — run in a worker thread.
        scanner_summary, inventory, err = await asyncio.to_thread(
            run_inventory_scan,
            workspace_root=workspace_root,
            path=target_path,
            output_path=out_path,
            profile=profile_norm,
            max_files=bounded_max_files,
            include_files=files,
        )
    if err:
        logger.warning("seed_static_inventory failed: %s", err)
        return {"success": False, "error": err, "added": 0, "scanner": scanner_summary}

    units = inventory.get("units") if isinstance(inventory, dict) else inventory
    unit_list = list(units or [])
    if load_settings().agents.auth_obligations:
        unit_list.extend(_auth_obligation_units(unit_list))
    add_result = await asyncio.to_thread(_add_units_impl, unit_list, "static_inventory")
    return {**add_result, "inventory_path": out_path, "scanner": scanner_summary}


@function_tool(timeout=180)
async def seed_static_inventory(
    ctx: RunContextWrapper,
    path: str = ".",
    output_path: str = _DEFAULT_OUTPUT,
    profile: str = "auto",
    max_files: int = 4000,
    files: list[str] | None = None,
) -> str:
    """Run a deterministic source inventory pass and seed coverage units.

    This is a recall-oriented inventory, not a vulnerability verdict. It scans common
    source/template files for high-signal constructs and registers construct x
    vulnerability-class coverage units such as ``redirect_sink`` x ``OPEN_REDIRECT``,
    ``admin_view`` x ``BFLA``, ``model_binding`` x ``MASS_ASSIGNMENT``, and
    ``template_output`` x ``XSS``. Every resulting unit must still be reviewed or ruled
    out by an agent before ``finish_scan`` can complete.

    Args:
        path: Subtree to scan. Absolute, or relative to the **workspace root** (NOT your
            shell cwd). Defaults to the whole workspace. Ignored when ``files`` is given.
        output_path: Where to write the generated inventory JSON. Prefer the absolute
            ``$TALON_ARTIFACT_DIR/inventory.json``; a relative path resolves from the
            workspace root.
        profile: ``auto`` (default), ``generic``, or ``django``.
        max_files: Hard cap on files scanned to keep the pass bounded.
        files: Workspace-relative paths to scope the pass to (e.g. a diff's changed
            files), instead of walking ``path``'s whole subtree. Use this for a
            fast, targeted pass over a known set of files rather than a full seed.
    """
    inner = ctx.context if isinstance(getattr(ctx, "context", None), dict) else {}
    return json.dumps(
        await _seed_static_inventory_impl(inner, path, output_path, profile, max_files, files),
        ensure_ascii=False,
        default=str,
    )

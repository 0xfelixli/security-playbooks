"""Static source inventory scanner."""

from __future__ import annotations

import argparse
import ast
import json
import os
import re
from pathlib import Path
from typing import Any

from talon.tools.inventory.scanner_rules.credentials import CredentialSinksMixin
from talon.tools.inventory.scanner_rules.crypto_auth import CryptoAuthSinksMixin
from talon.tools.inventory.scanner_rules.data_handling import DataHandlingSinksMixin
from talon.tools.inventory.scanner_rules.entrypoints import EntrypointSinksMixin
from talon.tools.inventory.scanner_rules.injection import InjectionSinksMixin
from talon.tools.inventory.scanner_rules.misc import MiscSinksMixin
from talon.tools.inventory.scanner_rules.network import NetworkSinksMixin
from talon.tools.inventory.scanner_rules.web_output import WebOutputSinksMixin


SKIP_DIRS = {
    ".git",
    ".hg",
    ".svn",
    ".venv",
    "venv",
    "env",
    "node_modules",
    "vendor",
    "dist",
    "build",
    "out",
    ".next",
    "_next",
    ".output",
    ".svelte-kit",
    "__pycache__",
    ".mypy_cache",
    ".ruff_cache",
    ".pytest_cache",
}
TEST_DIRS = {"tests", "test", "__tests__", "spec"}
LOW_SIGNAL_FALLBACK_DIRS = {
    "fixtures",
    "__fixtures__",
    "snapshots",
    "__snapshots__",
    "migrations",
    "generated",
    "examples",
    "docs",
    "mock",
    "mocks",
}
TEXT_SUFFIXES = {
    ".py",
    ".js",
    ".jsx",
    ".ts",
    ".tsx",
    ".java",
    ".go",
    ".rb",
    ".php",
    ".kt",
    ".rs",
    ".scala",
    ".cs",
    ".swift",
    ".c",
    ".cpp",
    ".h",
    ".html",
    ".htm",
    ".jinja",
    ".jinja2",
    ".j2",
    ".tpl",
    ".vue",
    ".svelte",
}
PY_SUFFIXES = {".py"}
TEMPLATE_SUFFIXES = {".html", ".htm", ".jinja", ".jinja2", ".j2", ".tpl"}
# Infra-as-code files get targeted pattern scans only, never full-file fallback units
# (a repo can hold hundreds of unrelated YAML files) — a unit exists only when a
# concrete risky construct is recognised.
IAC_SUFFIXES = {".yml", ".yaml", ".tf"}
JS_SUFFIXES = {".js", ".jsx", ".ts", ".tsx", ".vue", ".svelte"}

_CSRF_TAG_RE = re.compile(r"\{%\s*csrf_token\s*%\}")
_FORM_OPEN_RE = re.compile(r"<form\b([^>]*)>", re.I)
_FORM_METHOD_RE = re.compile(r"method\s*=\s*['\"]?(\w+)", re.I)
_STATE_CHANGING_METHODS = {"post", "patch", "put", "delete"}

# --- text/IaC line patterns (JS/Java/Go/Ruby/PHP + workflows/k8s/terraform) ---
#
# Python AST sink-detection constants (SQL/SSTI/SSRF/crypto/credentials/etc.) live
# alongside their detection methods in scanner_rules/ — see PythonVisitor below.

# Line-sink tables below: each entry is pattern / construct type / vulnerability
# class / title / confidence.
_JS_LINE_SINKS: tuple[tuple[re.Pattern[str], str, str, str, str], ...] = (
    (
        re.compile(
            r"\b(?:console|logger|log)\.(?:log|info|warn|error|debug)"
            r"\s*\([^)]*\$\{[^}]*\breq"
        ),
        "log_write",
        "LOG_INJECTION",
        "JavaScript request-derived log write review",
        "medium",
    ),
    (
        re.compile(r"\bnew\s+Function\s*\("),
        "command_sink",
        "RCE",
        "JavaScript dynamic Function construction review",
        "high",
    ),
    (
        re.compile(r"\b(document\.write|insertAdjacentHTML)\s*\(|\bouterHTML\s*="),
        "template_output",
        "XSS",
        "JavaScript HTML injection sink review",
        "medium",
    ),
    (
        re.compile(r"\bv-html\s*=|\{@html\b"),
        "template_output",
        "XSS",
        "framework raw-HTML binding review",
        "high",
    ),
    (
        re.compile(r"\bunserialize\s*\("),
        "deserialization",
        "INSECURE_DESERIALIZATION",
        "JavaScript object deserialization review",
        "high",
    ),
    (
        re.compile(
            r"\.(query|execute)\s*\(\s*[`'\"][^`'\"]*\b(SELECT|INSERT|UPDATE|DELETE|FROM|WHERE)\b",
            re.I,
        ),
        "sql_sink",
        "SQL_INJECTION",
        "JavaScript dynamically built SQL query review",
        "high",
    ),
    (
        re.compile(r"rejectUnauthorized\s*:\s*false|NODE_TLS_REJECT_UNAUTHORIZED"),
        "tls_config",
        "INSECURE_TRANSPORT",
        "TLS certificate verification disabled review",
        "high",
    ),
    (
        re.compile(r"\bjwt\.decode\s*\(|algorithms\s*:\s*\[\s*['\"]none['\"]"),
        "auth_token",
        "JWT_VALIDATION",
        "JWT decode without verification review",
        "medium",
    ),
    (
        re.compile(r"\bfs\.writeFile(Sync)?\s*\(.*\b(req|request|params|query|body)\b"),
        "file_write",
        "ARBITRARY_FILE_WRITE",
        "request-derived file write review",
        "high",
    ),
    (
        re.compile(r"__proto__|\b(deepmerge|merge|extend)\s*\(.*\b(req\.body|req\.query|params)\b"),
        "object_merge",
        "PROTOTYPE_POLLUTION",
        "recursive merge / prototype pollution review",
        "medium",
    ),
    (
        re.compile(r"createHash\s*\(\s*['\"](md5|sha1)['\"]"),
        "weak_hash",
        "WEAK_CRYPTO",
        "weak hash algorithm review (MD5/SHA1)",
        "medium",
    ),
    # Client-side navigation sink. Common enough that a blanket high/medium would flood
    # the gate on an SPA, so it is advisory (low) — surfaced for review, non-blocking.
    (
        re.compile(r"\b(location\.(href|assign|replace)|window\.open)\s*[=(]"),
        "redirect_sink",
        "OPEN_REDIRECT",
        "client-side navigation / open-redirect review",
        "low",
    ),
    (
        re.compile(r"\bpostMessage\s*\(|\baddEventListener\s*\(\s*['\"]message['\"]"),
        "postmessage",
        "POSTMESSAGE",
        "postMessage origin/target validation review",
        "medium",
    ),
    (
        re.compile(
            r"\b(localStorage|sessionStorage|AsyncStorage)\.setItem\s*\([^)]*"
            r"(token|jwt|secret|password|auth|credential|session)",
            re.I,
        ),
        "client_storage",
        "SENSITIVE_CLIENT_STORAGE",
        "sensitive data in browser / device storage review",
        "medium",
    ),
    # React Native WebView: injected JS and remote/untrusted source URLs are the primary
    # RN XSS/RCE surface.
    (
        re.compile(r"\binjectedJavaScript(BeforeContentLoaded)?\s*="),
        "webview_inject",
        "XSS",
        "React Native WebView injected JavaScript review",
        "medium",
    ),
    # React Native deep-link navigation: opening an externally-supplied URL/intent.
    (
        re.compile(r"\bLinking\.openURL\s*\("),
        "redirect_sink",
        "OPEN_REDIRECT",
        "React Native deep-link openURL review",
        "medium",
    ),
)

_JAVA_LINE_SINKS: tuple[tuple[re.Pattern[str], str, str, str, str], ...] = (
    (
        re.compile(
            r"\b(?:log|logger|LOG|LOGGER|Logger)\.(?:info|warn|error|debug|trace|fatal)"
            r"\s*\([^)]*\+[^)]*\b(?:request|req|param|input|user)"
        ),
        "log_write",
        "LOG_INJECTION",
        "Java request-derived log write review",
        "medium",
    ),
    (
        re.compile(r"\b(executeQuery|executeUpdate|createNativeQuery)\s*\(.*(\+|String\.format)"),
        "sql_sink",
        "SQL_INJECTION",
        "Java dynamically built SQL statement review",
        "high",
    ),
    (
        re.compile(r"\bnew\s+ObjectInputStream\s*\(|\breadObject\s*\("),
        "deserialization",
        "INSECURE_DESERIALIZATION",
        "Java native deserialization review",
        "high",
    ),
    (
        re.compile(r"\.csrf\s*\(\s*\)\s*\.disable\s*\(\s*\)"),
        "csrf_config",
        "CSRF",
        "Spring Security CSRF explicitly disabled review",
        "high",
    ),
    (
        re.compile(r"Runtime\.getRuntime\(\)\.exec\s*\(|\bnew\s+ProcessBuilder\s*\("),
        "command_sink",
        "RCE",
        "Java process execution review",
        "medium",
    ),
    (
        re.compile(r"getInstance\s*\(\s*['\"](MD5|SHA-?1|DES)"),
        "weak_hash",
        "WEAK_CRYPTO",
        "weak crypto algorithm review (MD5/SHA1/DES)",
        "medium",
    ),
)

_GO_LINE_SINKS: tuple[tuple[re.Pattern[str], str, str, str, str], ...] = (
    (
        re.compile(
            r"\b(?:log|logger|slog)\.(?:Printf|Println|Print|Fatalf|Panicf|Info|Error|Warn)"
            r"\s*\([^)]*\b(?:r\.|req|request|user|input|param)"
        ),
        "log_write",
        "LOG_INJECTION",
        "Go request-derived log write review",
        "medium",
    ),
    (
        re.compile(r"\bexec\.Command(Context)?\s*\(\s*\"(bash|sh)\""),
        "command_sink",
        "RCE",
        "Go shell command execution review",
        "high",
    ),
    (
        re.compile(r"\bdb\.(Query|Exec|QueryRow)\s*\(\s*(fmt\.Sprintf|\"[^\"]*\"\s*\+)"),
        "sql_sink",
        "SQL_INJECTION",
        "Go dynamically built SQL statement review",
        "high",
    ),
    (
        re.compile(r"InsecureSkipVerify\s*:\s*true"),
        "tls_config",
        "INSECURE_TRANSPORT",
        "TLS certificate verification disabled review",
        "high",
    ),
    (
        re.compile(r"\b(md5|sha1)\.New\s*\(|\bdes\.NewCipher\s*\("),
        "weak_hash",
        "WEAK_CRYPTO",
        "weak crypto primitive review (MD5/SHA1/DES)",
        "medium",
    ),
    (
        re.compile(r"\bhttp\.(Get|Post)\s*\(\s*(fmt\.Sprintf|[\w.]+\s*\+)"),
        "outbound_request",
        "SSRF",
        "Go outbound request with dynamic URL review",
        "medium",
    ),
    (
        # http.NewRequest(method, url, body) — dynamic URL in the 2nd arg.
        re.compile(r"\bhttp\.NewRequest(WithContext)?\s*\([^,]+,\s*(fmt\.Sprintf|[\w.]+\s*\+)"),
        "outbound_request",
        "SSRF",
        "Go outbound request (NewRequest) with dynamic URL review",
        "medium",
    ),
)

# Go line-level entrypoints: (pattern, kind, construct_type, vulnerability_class, title,
# framework). Each is a remote/untrusted-input entry needing review. A classless entry
# (``""``) gates via the entrypoint dimension, not a vuln class.
_GO_LINE_ENTRYPOINTS: tuple[tuple[re.Pattern[str], str, str, str, str, str], ...] = (
    (
        re.compile(r"\bRegister\w+Server\s*\("),
        "handler",
        "grpc_handler",
        "BFLA",
        "Go gRPC service authorization review",
        "grpc",
    ),
    (
        re.compile(r"\bcobra\.Command\s*\{"),
        "entrypoint",
        "cli_command",
        "",
        "Go cobra CLI command input review",
        "cobra",
    ),
    (
        re.compile(r"\bfunc\b.*\bConsumeClaim\s*\("),
        "handler",
        "queue_consumer",
        "QUEUE_INJECTION",
        "Go Kafka consumer message handling review",
        "sarama",
    ),
    (
        re.compile(r"\blambda\.Start\w*\s*\("),
        "entrypoint",
        "lambda_handler",
        "",
        "Go Lambda event handler input review",
        "lambda",
    ),
)

_RUBY_LINE_SINKS: tuple[tuple[re.Pattern[str], str, str, str, str], ...] = (
    (
        re.compile(r"\bMarshal\.load\s*\("),
        "deserialization",
        "INSECURE_DESERIALIZATION",
        "Ruby Marshal deserialization review",
        "high",
    ),
    (
        re.compile(r"\bYAML\.load\s*\("),
        "deserialization",
        "INSECURE_DESERIALIZATION",
        "Ruby unsafe YAML load review",
        "medium",
    ),
    (
        re.compile(r"\beval\s*\("),
        "command_sink",
        "RCE",
        "Ruby eval review",
        "medium",
    ),
    (
        re.compile(r"\b(system|exec)\s*\(.*#\{"),
        "command_sink",
        "RCE",
        "Ruby interpolated shell command review",
        "high",
    ),
)

_PHP_LINE_SINKS: tuple[tuple[re.Pattern[str], str, str, str, str], ...] = (
    (
        re.compile(r"\beval\s*\(|\bassert\s*\(\s*\$"),
        "command_sink",
        "RCE",
        "PHP dynamic code evaluation review",
        "high",
    ),
    (
        re.compile(r"\bunserialize\s*\("),
        "deserialization",
        "INSECURE_DESERIALIZATION",
        "PHP unserialize review",
        "high",
    ),
    (
        re.compile(r"\becho\s+\$_(GET|POST|REQUEST|COOKIE)"),
        "template_output",
        "XSS",
        "PHP direct request echo review",
        "high",
    ),
    (
        re.compile(r"\b(include|require)(_once)?\s*\(\s*\$"),
        "file_path",
        "PATH_TRAVERSAL",
        "PHP dynamic include review",
        "high",
    ),
    (
        re.compile(r"\bcurl_init\s*\(\s*\$"),
        "outbound_request",
        "SSRF",
        "PHP curl with dynamic URL review",
        "high",
    ),
    (
        re.compile(r"\bpreg_replace\s*\(.*/[a-z]*e[a-z]*['\"]"),
        "command_sink",
        "RCE",
        "PHP preg_replace /e modifier review",
        "high",
    ),
)

# github_actions.md: expression injection into run: scripts + poisoned-checkout shapes.
_GHA_EXPRESSION_RE = re.compile(
    r"\$\{\{\s*github\.(event\.(pull_request|issue|comment|review|head_commit)"
    r"|head_ref)"
)

# kubernetes.md / docker.md: privileged-container shapes in k8s manifests and compose.
_CONTAINER_PRIVILEGE_RE = re.compile(
    r"privileged:\s*true|hostNetwork:\s*true|hostPID:\s*true|hostIPC:\s*true"
    r"|allowPrivilegeEscalation:\s*true|runAsUser:\s*0\b|/var/run/docker\.sock"
)

# terraform_{aws,azure,gcp}.md: high-signal misconfiguration lines.
_TF_LINE_SINKS: tuple[tuple[re.Pattern[str], str, str, str, str], ...] = (
    (
        re.compile(r"(cidr_blocks|source_ranges|ipv6_cidr_blocks).*(0\.0\.0\.0/0|::/0)"),
        "network_rule",
        "NETWORK_EXPOSURE",
        "world-open network rule review",
        "high",
    ),
    (
        re.compile(r"(publicly_accessible|public_network_access_enabled)\s*=\s*true"),
        "public_access",
        "PUBLIC_ACCESS",
        "resource public network access review",
        "high",
    ),
    (
        re.compile(r"member\s*=\s*\"all(Authenticated)?Users\"|Principal\"?\s*[:=]\s*\"?\*"),
        "iam_policy",
        "PUBLIC_ACCESS",
        "wildcard/public IAM principal review",
        "high",
    ),
    (
        re.compile(r"[Aa]ction\"?\s*[:=]\s*\[?\s*\"\*\""),
        "iam_policy",
        "IAM_WILDCARD",
        "wildcard IAM action review",
        "high",
    ),
    (
        re.compile(r"min(imum)?_tls_version\s*=\s*\"(TLS)?1[._]0\""),
        "tls_config",
        "INSECURE_TRANSPORT",
        "weak minimum TLS version review",
        "medium",
    ),
    (
        re.compile(r"encrypted\s*=\s*false"),
        "encryption_config",
        "MISSING_ENCRYPTION",
        "resource encryption disabled review",
        "medium",
    ),
    (
        re.compile(r"(password|secret|access_key)\s*=\s*\"[^\"${]{6,}\""),
        "credential_literal",
        "HARDCODED_CREDENTIALS",
        "hardcoded credential in terraform review",
        "medium",
    ),
)


def _is_test_file(path: Path) -> bool:
    name = path.name.lower()
    suffixes = path.suffixes
    if name.startswith("test_") or name.endswith("_test.py"):
        return True
    if len(suffixes) >= 2 and suffixes[-2:] in (
        [".spec", ".js"],
        [".test", ".js"],
        [".spec", ".jsx"],
        [".test", ".jsx"],
        [".spec", ".ts"],
        [".test", ".ts"],
        [".spec", ".tsx"],
        [".test", ".tsx"],
    ):
        return True
    return any(part.lower() in TEST_DIRS for part in path.parts)


def _is_low_signal_fallback(path: Path) -> bool:
    return any(part.lower() in LOW_SIGNAL_FALLBACK_DIRS for part in path.parts)


def _is_eligible_source_file(path: Path) -> bool:
    """Whether ``path`` is a source file the scanner should read and analyze.

    Shared by both file-discovery modes (whole-tree walk and an explicit whitelist)
    so a diff-scoped seed and a full seed apply identical suffix/test-file rules.
    """
    if any(part in SKIP_DIRS for part in path.parts):
        return False
    # Minified/bundled JS carries no auditable source semantics (a webpack chunk is one
    # unreadable line); skip it even when it slips past the build-output dir list.
    if path.name.endswith((".min.js", ".bundle.js")):
        return False
    suffix = path.suffix.lower()
    eligible = (
        suffix in TEXT_SUFFIXES or suffix in IAC_SUFFIXES or path.name.startswith("Dockerfile")
    )
    return eligible and not _is_test_file(path)


class InventoryScanner:
    def __init__(self, *, root: Path, profile: str) -> None:
        self.root = root.resolve()
        self.profile = profile
        self.units: list[dict[str, Any]] = []
        self._seen: set[tuple[str, str, str, str]] = set()
        # Set when _iter_files stops because it hit max_files — i.e. there were
        # more eligible source files than the cap allowed, so coverage is partial.
        self.capped = False

    def scan(
        self,
        *,
        path: str,
        output_path: str,
        max_files: int,
        include_files: frozenset[str] | None = None,
    ) -> tuple[dict[str, Any], dict[str, Any]]:
        scan_path = (self.root / path).resolve()
        inventory_path = (self.root / output_path).resolve()
        scanned_files: list[Path] = []
        for file_path in self._iter_files(
            scan_path, max_files=max_files, include_files=include_files
        ):
            scanned_files.append(file_path)
            # Read once and share the text with both scanners; an empty/unreadable file
            # makes both no-op, so skipping is equivalent.
            text = self._read_text(file_path)
            if not text:
                continue
            if file_path.suffix.lower() in PY_SUFFIXES:
                self._scan_python(file_path, text)
            self._scan_text(file_path, text)

        self._add_file_fallbacks(scanned_files)
        if self.capped:
            self._add_scan_cap_marker(max_files=max_files, files_scanned=len(scanned_files))
        payload = {
            "units": self.units,
            "summary": {
                "total": len(self.units),
                "profile": self.profile,
                "files_scanned": len(scanned_files),
                "capped": self.capped,
                "max_files": max_files,
            },
        }
        inventory_path.parent.mkdir(parents=True, exist_ok=True)
        inventory_path.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
        summary = {
            "success": True,
            "output_path": self._rel(inventory_path),
            "units": len(self.units),
            "files_scanned": len(scanned_files),
            "capped": self.capped,
            "max_files": max_files,
        }
        return summary, payload

    def _rel(self, path: Path) -> str:
        try:
            return path.resolve().relative_to(self.root).as_posix()
        except ValueError:
            return path.as_posix()

    def _add(
        self,
        kind: str,
        path: Path,
        line: int,
        construct_type: str,
        vulnerability_class: str,
        title: str,
        evidence: dict[str, Any] | None = None,
        framework: str | None = None,
        confidence: str = "medium",
        blocking: bool = False,
    ) -> None:
        location = f"{self._rel(path)}:{line}"
        key = (kind, location, construct_type, vulnerability_class)
        if key in self._seen:
            return
        self._seen.add(key)
        unit: dict[str, Any] = {
            "kind": kind,
            "location": location,
            "title": title,
            "construct_type": construct_type,
            "vulnerability_class": vulnerability_class,
            "confidence": confidence,
            "evidence": evidence or {},
        }
        if framework:
            unit["framework"] = framework
        if blocking:  # gates via coverage.tools.unit_is_blocking, not a faked class
            unit["blocking"] = True
        self.units.append(unit)

    def _iter_files(
        self, base: Path, *, max_files: int, include_files: frozenset[str] | None = None
    ) -> Any:
        """Yield eligible source files, from an explicit whitelist or a full tree walk.

        ``include_files`` (workspace-relative paths, e.g. a diff's changed files) scopes
        the pass to exactly those files instead of walking ``base``'s whole subtree —
        both modes apply the same ``_is_eligible_source_file`` rule, so a diff-scoped
        seed and a full seed never disagree on what counts as a source file.
        """
        candidates = (
            ((self.root / rel).resolve() for rel in sorted(include_files))
            if include_files is not None
            else self._walk_all_files(base)
        )

        count = 0
        for path in candidates:
            if include_files is not None and not path.is_file():
                continue
            if not _is_eligible_source_file(path):
                continue
            count += 1
            if count > max_files:
                self.capped = True
                return
            yield path

    @staticmethod
    def _walk_all_files(base: Path) -> Any:
        for dirpath, dirnames, filenames in os.walk(base):
            dirnames[:] = [
                name
                for name in dirnames
                if name not in SKIP_DIRS and name not in TEST_DIRS and not name.startswith(".tox")
            ]
            for filename in filenames:
                yield Path(dirpath) / filename

    @staticmethod
    def _read_text(path: Path) -> str:
        try:
            return path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            return ""

    def _scan_python(self, path: Path, text: str | None = None) -> None:
        # ``scan`` passes the already-read text; standalone callers may omit it.
        if text is None:
            text = self._read_text(path)
        if not text:
            return
        try:
            tree = ast.parse(text)
        except SyntaxError as exc:
            # Sink detection can't run on an unparseable file; emit a blocking obligation so
            # the gate forces a manual read instead of a silent low file fallback.
            self._add(
                "file",
                path,
                getattr(exc, "lineno", 1) or 1,
                "unparsed_source",
                "",
                f"{self._rel(path)} could not be parsed — automated sink detection did "
                "not run; review this file by hand",
                {"error": str(exc)[:180]},
                blocking=True,
            )
            return
        PythonVisitor(self, path).visit(tree)

    def _scan_template(self, path: Path, text: str) -> None:
        in_script = False
        form_open = False
        form_line = 0
        form_method = "get"
        form_has_csrf = False

        def close_form() -> None:
            if form_open and form_method in _STATE_CHANGING_METHODS and not form_has_csrf:
                self._add(
                    "sink",
                    path,
                    form_line,
                    "state_changing_form",
                    "CSRF",
                    "state-changing form missing valid csrf_token review",
                    {"method": form_method},
                    framework="django",
                    confidence="high",
                )

        for idx, line in enumerate(text.splitlines(), start=1):
            stripped = line.strip()
            lower = stripped.lower()
            if "<script" in lower:
                in_script = True
            if "|safe" in stripped or "mark_safe" in stripped:
                self._add(
                    "sink",
                    path,
                    idx,
                    "template_output",
                    "XSS",
                    "template safe output review",
                    {"line": stripped[:180]},
                    framework="django",
                    confidence="high",
                )
            if (
                in_script
                and "{{" in stripped
                and "escapejs" not in lower
                and "json_script" not in lower
            ):
                self._add(
                    "sink",
                    path,
                    idx,
                    "template_js_output",
                    "XSS",
                    "template JavaScript context encoding review",
                    {"line": stripped[:180]},
                    framework="django",
                    confidence="high",
                )
            if "</script" in lower:
                in_script = False
            match = _FORM_OPEN_RE.search(line)
            if match:
                close_form()
                form_open = True
                form_line = idx
                form_has_csrf = False
                method_match = _FORM_METHOD_RE.search(match.group(1))
                form_method = method_match.group(1).lower() if method_match else "get"
            if form_open and _CSRF_TAG_RE.search(line):
                form_has_csrf = True
            if "</form" in lower and form_open:
                close_form()
                form_open = False
            if re.search(
                r"(password|passwd|pwd|api[ _-]?key|secret|access[ _-]?token)\s*[:=]",
                stripped,
                re.I,
            ):
                self._add(
                    "sink",
                    path,
                    idx,
                    "template_content",
                    "EXPOSURE",
                    "template credential disclosure review",
                    {"line": stripped[:180]},
                    framework="django",
                    confidence="medium",
                )
            elif re.search(r"<th[^>]*>\s*(password|api[ _-]?key|secret)\b", lower):
                self._add(
                    "sink",
                    path,
                    idx,
                    "template_content",
                    "EXPOSURE",
                    "credential column in template review",
                    {"line": stripped[:180]},
                    framework="django",
                    confidence="medium",
                )
        close_form()

    def _apply_line_sinks(
        self,
        path: Path,
        idx: int,
        stripped: str,
        sinks: tuple[tuple[re.Pattern[str], str, str, str, str], ...],
        *,
        framework: str | None = None,
    ) -> None:
        for pattern, construct_type, vulnerability_class, title, confidence in sinks:
            if pattern.search(stripped):
                self._add(
                    "sink",
                    path,
                    idx,
                    construct_type,
                    vulnerability_class,
                    title,
                    {"line": stripped[:180]},
                    framework=framework,
                    confidence=confidence,
                )

    def _scan_text(self, path: Path, text: str | None = None) -> None:
        # ``scan`` shares the already-read text; standalone callers may omit it.
        if text is None:
            text = self._read_text(path)
        if not text:
            return
        suffix = path.suffix.lower()
        if suffix in TEMPLATE_SUFFIXES:
            self._scan_template(path, text)
            return
        if suffix in IAC_SUFFIXES or path.name.startswith("Dockerfile"):
            self._scan_iac(path, text)
            return
        if suffix in JS_SUFFIXES:
            self._scan_js_entrypoint_file(path)
        for idx, line in enumerate(text.splitlines(), start=1):
            stripped = line.strip()
            if suffix in JS_SUFFIXES:
                self._scan_js_line(path, idx, stripped)
            elif suffix == ".java":
                self._scan_java_line(path, idx, stripped)
            elif suffix == ".go":
                self._scan_go_line(path, idx, stripped)
            elif suffix == ".rb":
                self._apply_line_sinks(path, idx, stripped, _RUBY_LINE_SINKS)
            elif suffix == ".php":
                self._apply_line_sinks(path, idx, stripped, _PHP_LINE_SINKS)

    def _scan_js_line(self, path: Path, idx: int, stripped: str) -> None:
        if re.search(r"\bres\.redirect\s*\(|\bredirect\s*\(", stripped):
            self._add(
                "sink",
                path,
                idx,
                "redirect_sink",
                "OPEN_REDIRECT",
                "JavaScript redirect review",
                {"line": stripped[:180]},
                framework="express",
            )
        if re.search(r"\b(innerHTML|dangerouslySetInnerHTML|res\.send)\b", stripped):
            self._add(
                "sink",
                path,
                idx,
                "template_output",
                "XSS",
                "JavaScript HTML output review",
                {"line": stripped[:180]},
            )
        if re.search(r"\b(exec|execSync|spawn|eval)\s*\(", stripped):
            self._add(
                "sink",
                path,
                idx,
                "command_sink",
                "RCE",
                "JavaScript command execution review",
                {"line": stripped[:180]},
            )
        # Server-side HTTP route handlers → BFLA handler under the entrypoint gate.
        # Narrowed to Express/Fastify/Koa server objects (app/router/fastify): matching a
        # bare .get/.post would flood on client HTTP calls (axios ``api.get('/url')``).
        if re.search(
            r"\b(app|router|fastify)\.(get|post|put|patch|delete|options|all)\s*\(",
            stripped,
        ):
            self._add(
                "handler",
                path,
                idx,
                "http_handler",
                "BFLA",
                "JavaScript HTTP route authorization review",
                {"line": stripped[:180]},
                framework="express",
            )
        # Client-side routes (React Router) and React Native screens / deep-link handlers:
        # genuine app entry points with real client-side authz obligations (unauthenticated
        # reachability, exposed admin routes, deep-link entry), so seed as entry units.
        if re.search(
            r"<Route\b[^>]*\bpath\s*=|createBrowserRouter\s*\(|\buseRoutes\s*\("
            r"|<\w*\.?Screen\b[^>]*\bname\s*=|create(Stack|BottomTab|Drawer|NativeStack)Navigator\s*\("
            r"|Linking\.addEventListener\s*\(\s*['\"]url['\"]|Linking\.getInitialURL\s*\(",
            stripped,
        ):
            self._add(
                "route",
                path,
                idx,
                "client_route",
                "",
                "client-side route / screen reachability / authorization review",
                {"line": stripped[:180]},
                framework="react",
            )
        self._apply_line_sinks(path, idx, stripped, _JS_LINE_SINKS)

    def _scan_js_entrypoint_file(self, path: Path) -> None:
        """Seed a handler for a JS/TS file that is an HTTP endpoint by convention.

        Next.js API routes carry no in-file decorator to match on a line, so they are
        detected by path: ``pages/api/**`` (Pages Router) and ``app/**/route.{ts,js}``
        (App Router). Each is a real backend endpoint and an authorization obligation.
        """
        rel = f"/{self._rel(path).lower().lstrip('/')}"
        base = path.name.lower()
        is_app_route = (
            base.startswith("route.")
            and base.endswith((".ts", ".tsx", ".js", ".jsx"))
            and "/app/" in rel
        )
        is_next_api = "/pages/api/" in rel or is_app_route
        if is_next_api:
            self._add(
                "handler",
                path,
                1,
                "http_handler",
                "BFLA",
                "Next.js API route authorization review",
                {"file": self._rel(path)},
                framework="nextjs",
            )

    def _scan_go_line(self, path: Path, idx: int, stripped: str) -> None:
        # Route registration → handler, for net/http, gin, echo, chi, gorilla/mux. The
        # path arg must be a string starting with "/" to discriminate a route
        # (``r.GET("/users", h)``) from lookalikes like ``headers.Get("Content-Type")``.
        if re.search(
            r"\b\w+\.(GET|POST|PUT|PATCH|DELETE|HEAD|OPTIONS"
            r"|Get|Post|Put|Patch|Delete|Handle|HandleFunc)\s*\(\s*\"/",
            stripped,
        ):
            self._add(
                "handler",
                path,
                idx,
                "http_handler",
                "BFLA",
                "Go HTTP route authorization review",
                {"line": stripped[:180]},
                framework="go",
            )
        # gRPC / cobra CLI / Kafka consumer / Lambda entrypoints — see _GO_LINE_ENTRYPOINTS.
        for pattern, kind, construct_type, vuln_class, title, framework in _GO_LINE_ENTRYPOINTS:
            if pattern.search(stripped):
                self._add(
                    kind,
                    path,
                    idx,
                    construct_type,
                    vuln_class,
                    title,
                    {"line": stripped[:180]},
                    framework=framework,
                )
        self._apply_line_sinks(path, idx, stripped, _GO_LINE_SINKS)

    def _scan_java_line(self, path: Path, idx: int, stripped: str) -> None:
        lower = stripped.lower()
        if "@requestmapping" in lower or "@getmapping" in lower or "@postmapping" in lower:
            self._add(
                "handler",
                path,
                idx,
                "http_handler",
                "BFLA",
                "Spring handler authorization review",
                {"line": stripped[:180]},
                framework="spring",
            )
        if "redirect:" in lower or "redirectview" in lower:
            self._add(
                "sink",
                path,
                idx,
                "redirect_sink",
                "OPEN_REDIRECT",
                "Spring redirect review",
                {"line": stripped[:180]},
                framework="spring",
            )
        self._apply_line_sinks(path, idx, stripped, _JAVA_LINE_SINKS, framework="spring")

    def _scan_iac(self, path: Path, text: str) -> None:
        """Targeted IaC scan: GitHub workflows, k8s/compose manifests, terraform, Dockerfile.

        These files never fall back to full-file units, so every check here must be a
        concrete risky construct from the corresponding rules doc.
        """
        posix = path.as_posix()
        suffix = path.suffix.lower()
        is_workflow = ".github/workflows" in posix
        if path.name.startswith("Dockerfile"):
            last_user = ""
            last_user_line = 0
            for idx, line in enumerate(text.splitlines(), start=1):
                stripped = line.strip()
                if stripped.upper().startswith("USER "):
                    last_user = stripped.split(None, 1)[1].strip()
                    last_user_line = idx
            if last_user == "root":
                self._add(
                    "sink",
                    path,
                    last_user_line,
                    "container_user",
                    "CONTAINER_PRIVILEGE",
                    "container runs as root user review",
                    {"line": f"USER {last_user}"},
                    confidence="medium",
                )
            return
        if suffix == ".tf":
            for idx, line in enumerate(text.splitlines(), start=1):
                self._apply_line_sinks(path, idx, line.strip(), _TF_LINE_SINKS)
            return
        # YAML: GitHub Actions expression injection / poisoned checkout, k8s/compose privilege.
        has_pull_request_target = "pull_request_target" in text or "workflow_run" in text
        for idx, line in enumerate(text.splitlines(), start=1):
            stripped = line.strip()
            if is_workflow and _GHA_EXPRESSION_RE.search(stripped):
                self._add(
                    "sink",
                    path,
                    idx,
                    "ci_script",
                    "SCRIPT_INJECTION",
                    "attacker-controlled expression in workflow review",
                    {"line": stripped[:180]},
                    confidence="high",
                )
            if is_workflow and has_pull_request_target and "actions/checkout" in stripped:
                self._add(
                    "sink",
                    path,
                    idx,
                    "ci_checkout",
                    "SCRIPT_INJECTION",
                    "privileged-trigger checkout (pwn request shape) review",
                    {"line": stripped[:180]},
                    confidence="high",
                )
            if _CONTAINER_PRIVILEGE_RE.search(stripped):
                self._add(
                    "sink",
                    path,
                    idx,
                    "container_privilege",
                    "CONTAINER_PRIVILEGE",
                    "privileged container configuration review",
                    {"line": stripped[:180]},
                    confidence="high",
                )

    def _add_scan_cap_marker(self, *, max_files: int, files_scanned: int) -> None:
        """Seed one blocking unit for a truncated file walk (files past ``max_files`` never
        enter the manifest), so the agent must act rather than miss them silently. Blocks via
        the ``blocking`` flag; ``scan_cap`` construct is exempt from the location check."""
        self.units.append(
            {
                "kind": "file",
                "location": "<inventory>:file-cap",
                "title": (
                    f"inventory file cap reached at {max_files} files ({files_scanned} "
                    "scanned); files beyond the cap are NOT in the coverage manifest"
                ),
                "construct_type": "scan_cap",
                "vulnerability_class": "",
                "confidence": "medium",
                "blocking": True,
                "evidence": {"max_files": max_files, "files_scanned": files_scanned},
            }
        )

    def _add_file_fallbacks(self, scanned_files: list[Path]) -> None:
        covered_files = {unit["location"].rsplit(":", 1)[0] for unit in self.units}
        for file_path in scanned_files:
            if (
                file_path.name == "__init__.py"
                or ".min." in file_path.name
                or file_path.suffix.lower() in IAC_SUFFIXES
                or file_path.name.startswith("Dockerfile")
                or _is_low_signal_fallback(file_path)
            ):
                continue
            if self._rel(file_path) not in covered_files:
                self._add(
                    "file",
                    file_path,
                    1,
                    "source_file",
                    "",
                    f"{self._rel(file_path)} full-file review (no construct recognised)",
                    {"suffix": file_path.suffix.lower()},
                    confidence="low",
                )


class PythonVisitor(
    EntrypointSinksMixin,
    NetworkSinksMixin,
    CredentialSinksMixin,
    InjectionSinksMixin,
    CryptoAuthSinksMixin,
    DataHandlingSinksMixin,
    WebOutputSinksMixin,
    MiscSinksMixin,
    ast.NodeVisitor,
):
    """AST visitor seeding sink/handler/entrypoint units for one Python source file.

    Detection logic is split across the domain mixins in ``scanner_rules/`` (each one
    a self-contained vulnerability class); this class owns only per-file state and the
    two AST dispatch points (``visit_Assign``, ``visit_Call``) that fan out to them.
    """

    def __init__(self, scanner: InventoryScanner, path: Path) -> None:
        self.scanner = scanner
        self.path = path
        # Lowercased names bound to an HTTP client/session constructor in this file
        # (``client``, ``self.session``, …), so ``client.get(url)`` is recognized as an
        # outbound request. Single-pass, so a forward reference (use before assignment) is
        # missed — acceptable for a heuristic seeder.
        self._http_client_vars: set[str] = set()

    def visit_Assign(self, node: ast.Assign) -> None:
        if self._contains_request_data(node.value):
            for target in node.targets:
                if isinstance(target, ast.Attribute):
                    self.scanner._add(
                        "sink",
                        self.path,
                        node.lineno,
                        "model_binding",
                        "MASS_ASSIGNMENT",
                        f"{self._name(target)} request-derived assignment review",
                        {"target": self._name(target), "request_derived_input": True},
                        framework="django" if self.scanner.profile in {"auto", "django"} else None,
                    )
                    break
        self._add_hardcoded_credentials(node)
        self._add_plaintext_password(node)
        self._add_settings_misconfig(node)
        if isinstance(node.value, ast.Call):
            self._track_http_client_binding(node.value, node.targets)
        self.generic_visit(node)

    def visit_Call(self, node: ast.Call) -> None:
        name = self._call_name(node)
        lower = name.lower()
        self._add_redirect_sink(node, name, lower)
        self._add_output_sinks(node, name, lower)
        self._add_write_sinks(node, name, lower)
        self._add_serialization_and_file_sinks(node, name)
        self._add_session_cookie_sink(node, name)
        self._add_crypto_sink(node, name, lower)
        self._add_credential_kwargs(node)
        self._add_response_exposure(node, name)
        self._add_sql_sinks(node, name)
        self._add_ssti_sink(node, name)
        self._add_ssrf_sink(node, name, lower)
        self._add_deserialization_sink(node, name, lower)
        self._add_xml_sink(node, name, lower)
        self._add_jwt_sink(node, name, lower)
        self._add_transport_sink(node, name, lower)
        self._add_path_and_write_sinks(node, name, lower)
        self._add_nosql_sink(node, name)
        self._add_log_injection_sink(node, name)
        self._add_misc_sinks(node, name)
        self.generic_visit(node)


def list_eligible_source_files(
    *, workspace_root: str, path: str = ".", max_files: int = 20000
) -> tuple[list[str], bool, str | None]:
    """The in-scope source files under the tree, workspace-relative, for the coverage gate.

    A lightweight walk that reuses the SAME ``_is_eligible_source_file`` rule and ``_rel``
    namespace as the seeding scan, so the gate's filesystem-derived denominator can never
    drift from what seeding registers as ``kind=file`` units. Reads no file content and
    builds no units — just the eligible-path list, plus whether the walk hit ``max_files``
    (so a truncated denominator is reported, never silently short). Returns
    ``(rel_paths, capped, err)``.
    """
    try:
        root = Path(workspace_root)
        scanner = InventoryScanner(root=root, profile="auto")
        base = (root / (path or ".")).resolve()
        files = [scanner._rel(p) for p in scanner._iter_files(base, max_files=max_files)]
    except OSError as e:
        return [], False, f"source-file inventory walk failed: {e!s}"
    else:
        return files, scanner.capped, None


def run_inventory_scan(
    *,
    workspace_root: str,
    path: str,
    output_path: str,
    profile: str,
    max_files: int,
    include_files: list[str] | None = None,
) -> tuple[dict[str, Any], dict[str, Any], str | None]:
    try:
        scanner = InventoryScanner(root=Path(workspace_root), profile=profile)
        summary, payload = scanner.scan(
            path=path,
            output_path=output_path,
            max_files=max_files,
            include_files=frozenset(include_files) if include_files is not None else None,
        )
    except OSError as e:
        return {}, {}, f"inventory scanner failed: {e!s}"
    else:
        return summary, payload, None


def _main() -> int:
    """CLI entry point so the Docker backend can run this scanner in-container.

    Under the Docker backend the source tree lives in the container (``/workspace``), not
    on the host, so this stdlib-only module is baked into the sandbox image and invoked
    via ``session.exec``. It scans the in-container workspace and writes a
    ``{summary, payload, err}`` JSON envelope the host reads back to seed coverage units.
    """
    parser = argparse.ArgumentParser(description="Static source inventory scan (in-container).")
    parser.add_argument("--workspace-root", required=True)
    parser.add_argument("--path", default=".")
    parser.add_argument("--output-path", default=".talon-source-aware/inventory.json")
    parser.add_argument("--profile", default="auto")
    parser.add_argument("--max-files", type=int, default=4000)
    parser.add_argument(
        "--include-files",
        default=None,
        help=(
            "JSON-encoded list of workspace-relative paths to scope the pass to "
            "(e.g. a diff's changed files), instead of walking --path's whole subtree."
        ),
    )
    parser.add_argument(
        "--mode",
        default="scan",
        choices=("scan", "list-files"),
        help="'scan' seeds inventory units (default); 'list-files' only lists eligible "
        "source files for the coverage gate's filesystem denominator.",
    )
    parser.add_argument(
        "--result-path",
        required=True,
        help="Where to write the result JSON envelope the host reads back.",
    )
    args = parser.parse_args()

    if args.mode == "list-files":
        files, capped, err = list_eligible_source_files(
            workspace_root=args.workspace_root, path=args.path, max_files=args.max_files
        )
        envelope: dict[str, Any] = {"files": files, "capped": capped, "err": err}
    else:
        summary, payload, err = run_inventory_scan(
            workspace_root=args.workspace_root,
            path=args.path,
            output_path=args.output_path,
            profile=args.profile,
            max_files=args.max_files,
            include_files=json.loads(args.include_files) if args.include_files else None,
        )
        envelope = {"summary": summary, "payload": payload, "err": err}
    Path(args.result_path).write_text(json.dumps(envelope, ensure_ascii=False), encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(_main())

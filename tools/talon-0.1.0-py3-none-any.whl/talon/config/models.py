"""SDK model configuration helpers."""

from __future__ import annotations

import asyncio
import logging
import os
from typing import TYPE_CHECKING, Any

from agents import Model, set_default_openai_api, set_default_openai_key, set_tracing_disabled
from agents.models.multi_provider import MultiProvider
from agents.retry import (
    ModelRetryBackoffSettings,
    ModelRetrySettings,
    retry_policies,
)


if TYPE_CHECKING:
    from collections.abc import AsyncIterator

    from agents import ModelResponse
    from agents.items import TResponseStreamEvent
    from agents.models.interface import ModelProvider
    from agents.retry import ModelRetryAdvice, ModelRetryAdviceRequest

    from talon.config.settings import Settings


logger = logging.getLogger(__name__)

_loop_semaphores: dict[int, asyncio.Semaphore] = {}


# Some OpenAI-compatible gateways intermittently violate ``tool_choice="required"``:
# under load they return an empty ``finish_reason="stop"`` completion (no content, no
# tool call), which the SDK renders as an empty turn that parks the agent. When we asked
# for "required" and the whole turn produced no tool call, treat it as a transient
# endpoint fault and retry with exponential backoff.
_EMPTY_REQUIRED_RETRY_MAX = 4
_EMPTY_REQUIRED_RETRY_BASE_SECS = 2.0


def _requested_tool_choice(args: tuple[Any, ...], kwargs: dict[str, Any]) -> Any:
    """Extract ``model_settings.tool_choice`` from a Model.stream_response call.

    ``model_settings`` is the 3rd positional arg of the SDK's stream_response/get_response;
    read defensively from kwargs or args.
    """
    model_settings = kwargs.get("model_settings")
    if model_settings is None and len(args) >= 3:
        model_settings = args[2]
    return getattr(model_settings, "tool_choice", None)


def _is_tool_call_added(event: Any) -> bool:
    """True if this stream event announces a function/tool-call output item."""
    if getattr(event, "type", None) != "response.output_item.added":
        return False
    item = getattr(event, "item", None)
    return getattr(item, "type", None) == "function_call"


def _concurrency_semaphore(limit: int) -> asyncio.Semaphore | None:
    """Return a per-event-loop semaphore capping concurrent LLM requests.

    Keyed by the running event loop so the warm-up loop and the scan loop (separate
    ``asyncio.run`` calls) never share a semaphore bound to the wrong loop.
    ``limit <= 0`` disables throttling (returns ``None``).
    """
    if limit <= 0:
        return None
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        return None
    key = id(loop)
    semaphore = _loop_semaphores.get(key)
    if semaphore is None:
        semaphore = asyncio.Semaphore(limit)
        _loop_semaphores[key] = semaphore
    return semaphore


class _ThrottledModel(Model):
    """Wrap a Model so each request passes through a shared concurrency gate.

    The semaphore is held for a request's full lifetime — including the entire streaming
    response — so in-flight requests never exceed ``TALON_MAX_CONCURRENCY``, keeping the
    multi-agent fan-out from tripping provider-side "concurrency limit exceeded" errors.
    """

    def __init__(self, inner: Model, semaphore: asyncio.Semaphore) -> None:
        self._inner = inner
        self._semaphore = semaphore

    async def get_response(self, *args: Any, **kwargs: Any) -> ModelResponse:
        async with self._semaphore:
            return await self._inner.get_response(*args, **kwargs)

    async def stream_response(
        self, *args: Any, **kwargs: Any
    ) -> AsyncIterator[TResponseStreamEvent]:
        # Guard only turns where we demanded a tool call. Buffer until the first tool-call
        # event (early for healthy turns, so latency is unaffected); if the whole turn ends
        # with no tool call, discard it and retry with backoff. The interactive root uses
        # tool_choice=None and is exempt — it may reply in text.
        required = _requested_tool_choice(args, kwargs) == "required"
        attempt = 0
        while True:
            buffered: list[Any] = []
            produced_tool_call = False
            async with self._semaphore:
                async for event in self._inner.stream_response(*args, **kwargs):
                    if not required or produced_tool_call:
                        yield event
                        continue
                    buffered.append(event)
                    if _is_tool_call_added(event):
                        produced_tool_call = True
                        for buffered_event in buffered:
                            yield buffered_event
                        buffered = []
            if not required or produced_tool_call or attempt >= _EMPTY_REQUIRED_RETRY_MAX:
                if buffered and required:
                    logger.warning(
                        "endpoint returned an empty tool_choice=required response; passing "
                        "it through after %d exhausted retries",
                        attempt,
                    )
                for buffered_event in buffered:
                    yield buffered_event
                return
            attempt += 1
            delay = _EMPTY_REQUIRED_RETRY_BASE_SECS * (2 ** (attempt - 1))
            logger.warning(
                "endpoint returned an empty response despite tool_choice=required "
                "(no tool call); retrying %d/%d after %.1fs",
                attempt,
                _EMPTY_REQUIRED_RETRY_MAX,
                delay,
            )
            await asyncio.sleep(delay)

    async def close(self) -> None:
        await self._inner.close()

    def get_retry_advice(self, request: ModelRetryAdviceRequest) -> ModelRetryAdvice | None:
        return self._inner.get_retry_advice(request)


class TalonProvider(MultiProvider):
    """Route any non-OpenAI prefix through LiteLLM with the prefix preserved,
    so users type ``deepseek/deepseek-chat`` rather than
    ``litellm/deepseek/deepseek-chat``.
    """

    def get_model(self, model_name: str | None) -> Model:
        """Resolve the model, then wrap it in a shared concurrency gate.

        Every LLM call in a scan flows through here (Runner resolves the model via the
        configured ``model_provider`` at run time), so this is the single seam where the
        ``TALON_MAX_CONCURRENCY`` cap is applied.
        """
        model = super().get_model(model_name)
        from talon.config import load_settings

        semaphore = _concurrency_semaphore(load_settings().runtime.max_concurrency)
        if semaphore is None:
            return model
        return _ThrottledModel(model, semaphore)

    def _resolve_prefixed_model(
        self,
        *,
        original_model_name: str,
        prefix: str,
        stripped_model_name: str | None,
    ) -> tuple[ModelProvider, str | None]:
        if prefix in {"openai", "litellm", "any-llm"}:
            return super()._resolve_prefixed_model(
                original_model_name=original_model_name,
                prefix=prefix,
                stripped_model_name=stripped_model_name,
            )
        if prefix == "ollama" and stripped_model_name:
            return self._get_fallback_provider("litellm"), f"ollama_chat/{stripped_model_name}"
        return self._get_fallback_provider("litellm"), original_model_name


DEFAULT_MODEL_RETRY = ModelRetrySettings(
    max_retries=5,
    backoff=ModelRetryBackoffSettings(
        initial_delay=2.0,
        max_delay=90.0,
        multiplier=2.0,
        jitter=False,
    ),
    policy=retry_policies.any(
        retry_policies.provider_suggested(),
        retry_policies.network_error(),
        retry_policies.http_status((429, 500, 502, 503, 504)),
    ),
)


def prefer_responses_api(model_name: str | None) -> bool:
    """Whether the OpenAI provider should keep this model on the Responses API.

    An ``openai/``-prefixed reasoning model (e.g. ``openai/gpt-5.5``) is Responses-API
    native (``fc_``-prefixed tool-call ids, reasoning items). Forcing it through the Chat
    Completions shim just because an ``api_base`` gateway is set corrupts tool-call/result
    pairing on high-fan-out parallel-tool turns: the SDK's chat converter can't reconstruct
    a multi-call assistant message on replay, so history arrives with an orphaned
    ``function_call_output`` and the server rejects the request with a non-retryable 400.
    Keeping such models on Responses preserves the native ``fc_`` format end-to-end.

    Only ``openai/`` (or bare OpenAI) routes are eligible: litellm/other prefixes have
    their own transport and are unaffected by ``set_default_openai_api``.
    """
    if not model_name:
        return False
    name = model_name.strip().lower()
    if "/" in name and not name.startswith("openai/"):
        return False
    return model_supports_reasoning(name)


def configure_sdk_model_defaults(settings: Settings) -> None:
    """Apply Talon config to SDK-native defaults."""
    llm = settings.llm
    set_tracing_disabled(True)
    _configure_litellm_compatibility()
    _patch_openai_sse_decoder()
    if llm.api_key:
        set_default_openai_key(llm.api_key, use_for_tracing=False)
        _configure_litellm_default("api_key", llm.api_key)
        _mirror_api_key_to_provider_env(llm.model, llm.api_key)
    if llm.api_base:
        os.environ["OPENAI_BASE_URL"] = llm.api_base
        _configure_litellm_default("api_base", llm.api_base)
        # A gateway (api_base) normally means Chat Completions, but a Responses-native
        # reasoning model must stay on Responses even behind one (see prefer_responses_api).
        # This global switch is keyed off the configured primary model — correct while a
        # scan runs a single model tier.
        if prefer_responses_api(llm.model):
            set_default_openai_api("responses")
        else:
            set_default_openai_api("chat_completions")
    else:
        set_default_openai_api("responses")
    _configure_openai_client_timeout(llm)


def _configure_openai_client_timeout(llm: Any) -> None:
    """Install a default AsyncOpenAI client whose read timeout is bounded.

    ``openai/``-prefixed models (e.g. ``openai/gpt-5.5`` against a custom ``api_base``) go
    through the SDK's OpenAI provider, NOT litellm, so ``litellm.request_timeout`` doesn't
    apply. The OpenAI SDK's default 600s *read* timeout means a stalled stream (server
    stops sending bytes without closing the socket) parks the agent for 10 minutes.

    A float ``timeout`` makes httpx's read timeout an *idle* timeout that resets on every
    chunk, so a healthy long generation is never cut off but a truly stalled stream raises
    after ``LLM_TIMEOUT`` and the SDK retry policy recovers the agent.

    The client carries the key/base_url because ``set_default_openai_client`` takes
    precedence over ``set_default_openai_key``.
    """
    if not llm.api_key or llm.timeout <= 0:
        return
    from agents import set_default_openai_client
    from openai import AsyncOpenAI

    client_kwargs: dict[str, Any] = {"api_key": llm.api_key, "timeout": float(llm.timeout)}
    if llm.api_base:
        client_kwargs["base_url"] = llm.api_base
    set_default_openai_client(AsyncOpenAI(**client_kwargs), use_for_tracing=False)


def _mirror_api_key_to_provider_env(model_name: str | None, api_key: str) -> None:
    if not model_name:
        return
    import litellm

    name = model_name.strip()
    for prefix in ("litellm/", "any-llm/"):
        if name.lower().startswith(prefix):
            name = name[len(prefix) :]
            break
    try:
        report = litellm.validate_environment(model=name.lower())
    except Exception:  # noqa: BLE001
        return
    for env_key in report.get("missing_keys") or []:
        if env_key.endswith("_API_KEY"):
            os.environ.setdefault(env_key, api_key)


def _patch_openai_sse_decoder() -> None:
    """Make ``openai``'s SSE decoder skip meta-only frames instead of crashing.

    Upstream bug: a meta-only frame (``retry``/``id``/``event``, no ``data``) is valid per
    the SSE spec, and ``SSEDecoder.decode`` dispatches it as a ``ServerSentEvent`` with
    ``data=""`` — as it also does on a bare blank-line flush once any prior event carried an
    ``id`` (``last_event_id`` is never reset, defeating the "was anything sent" check for the
    rest of the connection). Either shape is the no-op flush a gateway sends to keep a
    long-reasoning connection alive; ``Stream.__stream__`` then calls ``sse.json()``
    unconditionally and ``json.loads("")`` raises ``JSONDecodeError``, aborting the turn.
    Fix proposed in openai-python#2721 (unmerged as of 2.45.0; the repo is Stainless-
    generated so community PRs are unlikely to land): see
    https://github.com/openai/openai-python/issues/2722. Idempotent.
    """
    from openai._streaming import SSEDecoder

    if getattr(SSEDecoder, "_talon_skips_empty_sse", False):
        return
    original_decode = SSEDecoder.decode

    def _decode_skip_empty(self: SSEDecoder, line: str) -> Any:
        sse = original_decode(self, line)
        if sse is not None and not sse.data.strip():
            return None
        return sse

    SSEDecoder.decode = _decode_skip_empty  # type: ignore[method-assign]
    SSEDecoder._talon_skips_empty_sse = True  # type: ignore[attr-defined]


def _configure_litellm_compatibility() -> None:
    """Enable LiteLLM's permissive param handling and disable its callbacks."""
    import litellm

    litellm.drop_params = True
    litellm.modify_params = True
    litellm.turn_off_message_logging = True
    litellm.disable_streaming_logging = True
    litellm.suppress_debug_info = True

    _register_litellm_cost_callback()


def _register_litellm_cost_callback() -> None:
    import litellm

    from talon.report.state import litellm_cost_callback

    for bucket_name in ("success_callback", "_async_success_callback"):
        bucket = getattr(litellm, bucket_name, None)
        if not isinstance(bucket, list):
            continue
        if litellm_cost_callback in bucket:
            continue
        bucket.append(litellm_cost_callback)


def _configure_litellm_default(name: str, value: str) -> None:
    """Set LiteLLM's module-level defaults without adding a provider wrapper."""
    import litellm

    setattr(litellm, name, value)


def uses_chat_completions_tool_schema(model_name: str, settings: Settings) -> bool:
    """Return whether the resolved SDK route can only receive JSON function tools.

    Must track :func:`configure_sdk_model_defaults`'s API choice: a Responses-native
    reasoning model stays on Responses even behind a gateway, so it does NOT use the
    chat-completions tool schema — reporting True there would inject the wrong format.
    """
    model = model_name.strip().lower()
    if "/" in model and not model.startswith("openai/"):
        return True
    if prefer_responses_api(model_name):
        return False
    if settings.llm.api_base:
        return True
    return not model_supports_reasoning(model_name)


def model_supports_reasoning(model_name: str) -> bool:
    import litellm

    name = model_name.strip().lower()
    for prefix in ("litellm/", "any-llm/", "openai/"):
        if name.startswith(prefix):
            name = name[len(prefix) :]
            break
    entry = litellm.model_cost.get(name)
    if entry is None and "/" in name:
        entry = litellm.model_cost.get(name.rsplit("/", 1)[1])
    return bool(entry and entry.get("supports_reasoning"))


def is_known_openai_bare_model(model_name: str) -> bool:
    import litellm

    name = model_name.strip().lower()
    if not name or "/" in name:
        return False
    entry = litellm.model_cost.get(name)
    return bool(entry and entry.get("litellm_provider") == "openai")

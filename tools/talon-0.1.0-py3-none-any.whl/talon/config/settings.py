"""Talon application settings — pydantic-settings powered."""

from __future__ import annotations

from typing import Literal

from pydantic import AliasChoices, Field
from pydantic_settings import BaseSettings, SettingsConfigDict


ReasoningEffort = Literal["none", "minimal", "low", "medium", "high", "xhigh"]

_BASE_CONFIG = SettingsConfigDict(
    case_sensitive=False,
    populate_by_name=True,
    extra="ignore",
)


class LlmSettings(BaseSettings):
    model_config = _BASE_CONFIG

    model: str | None = Field(default=None, alias="TALON_LLM")
    api_key: str | None = Field(
        default=None,
        validation_alias=AliasChoices("LLM_API_KEY", "OPENAI_API_KEY"),
    )
    api_base: str | None = Field(
        default=None,
        validation_alias=AliasChoices(
            "LLM_API_BASE",
            "OPENAI_API_BASE",
            "OPENAI_BASE_URL",
            "LITELLM_BASE_URL",
            "OLLAMA_API_BASE",
        ),
    )
    reasoning_effort: ReasoningEffort = Field(default="high", alias="TALON_REASONING_EFFORT")
    timeout: int = Field(default=300, alias="LLM_TIMEOUT")


class RuntimeSettings(BaseSettings):
    model_config = _BASE_CONFIG

    # Sandbox backend; both materialize each source at <workspace>/<subdir> (strix
    # layout). "local" CoW-clones on the host and runs subprocesses under macOS
    # sandbox-exec; "docker" copies into a container-backed SDK session for real
    # isolation (needed on Linux / untrusted code).
    runtime_backend: Literal["local", "docker"] = Field(
        default="docker", alias="TALON_RUNTIME_BACKEND"
    )
    image: str = Field(default="talon-sandbox:latest", alias="TALON_IMAGE")
    max_local_copy_mb: int = Field(default=1024, alias="TALON_MAX_LOCAL_COPY_MB")

    # Escape hatch that disables the macOS sandbox's WRITE isolation entirely — the
    # agent's shell can then read/write anywhere on the host, not just workspace + temp.
    # Off by default; ONLY for auditing fully-trusted local code, since on untrusted code
    # it removes the sole guard against a mistaken/prompt-injected agent mutating the host.
    # Buys no extra tool capability (read-open + temp-write grants already cover tools) —
    # it only removes the write guardrail.
    sandbox_unrestricted: bool = Field(default=False, alias="TALON_SANDBOX_UNRESTRICTED")

    # Shell snippet run once per scan inside the sandbox before any agent starts —
    # typically a dependency install (e.g. ``uv sync``) so agents don't burn turns
    # provisioning. Runs via ``bash -lc`` from the workspace root. Empty = skip.
    setup_cmd: str | None = Field(default=None, alias="TALON_SETUP_CMD")
    setup_timeout: int = Field(default=600, alias="TALON_SETUP_TIMEOUT")

    # Interval (seconds) for the one-line progress dashboard (elapsed, agents
    # spawned/active/done, coverage dispositioned/total, findings) — a heartbeat so a
    # long deep scan doesn't look idle before the first report. 0 disables. Default 30s.
    progress_interval_secs: int = Field(default=30, alias="TALON_PROGRESS_INTERVAL")

    # Cap on concurrent in-flight LLM requests across the whole scan. The multi-agent
    # fan-out otherwise opens one streaming request per active agent, which can exceed a
    # provider/gateway concurrency limit and abort the scan. Enforced at the model layer
    # via a shared per-event-loop semaphore. 0 or negative disables the cap.
    max_concurrency: int = Field(default=8, alias="TALON_MAX_CONCURRENCY")

    # Server-side context compaction threshold (tokens) for OpenAI Responses-API models:
    # when a request's rendered tokens cross this, the server compacts older history into
    # an opaque item and the SDK drops everything before it on replay. Primary defense
    # against long-lived agents ballooning past the context window (a real scan crashed a
    # child with "input exceeds the context window"). Default 180k — comfortably under the
    # ~272k effective input limit measured through the gateway for gpt-5.5 (the SDK's 1M
    # table entry is wrong for that route, hence a static threshold not a dynamic policy).
    # 0 disables. Ignored on non-Responses routes (litellm/anthropic/gateway-chat).
    compact_threshold: int = Field(default=180_000, alias="TALON_COMPACT_THRESHOLD")

    # Sliding window on each agent's replayed history: keep only the last N session items
    # (via the SDK's SessionSettings.limit -> get_items(limit=N)). The session otherwise
    # grows monotonically every turn, so on a long scan the request context balloons until
    # a flaky gateway degrades or the context window is exhausted. 0 (default) disables —
    # full history. CAVEATS: (1) counts ITEMS not tokens, so one huge tool output is 1;
    # (2) a naive latest-N cut can orphan a function_call from its output at the window
    # edge, which some providers reject with a 400 — verify before enabling in prod.
    history_limit: int = Field(default=0, alias="TALON_HISTORY_LIMIT")

    # Fallback history window for non-Responses routes only (litellm/anthropic/chat),
    # which have no server-side Compaction and would otherwise replay ever-growing history.
    # Used only when history_limit is 0; an explicit history_limit > 0 overrides it, and
    # Responses routes ignore it. Generous by design (same orphan-function-call caveat as
    # history_limit) — caps runaway growth, not aggressive trimming. 0 disables.
    chat_history_limit: int = Field(default=1200, alias="TALON_CHAT_HISTORY_LIMIT")

    # Hard cap on source files scanned during the whitebox static-inventory seed,
    # bounding the coverage-manifest denominator; files beyond the cap never enter the
    # manifest and are a recall miss on large repos. Defaults to the seed tool's 20000 hard
    # ceiling (recall-first); lower to speed the pass. When the cap truncates the walk, the
    # scan is flagged so the miss is reported instead of silent.
    inventory_max_files: int = Field(default=20000, alias="TALON_INVENTORY_MAX_FILES")


class AgentSettings(BaseSettings):
    model_config = _BASE_CONFIG

    # When true, ``finish_scan`` no longer blocks on undispositioned coverage units.
    # The manifest is still tracked and reported; only the hard gate is lifted. Off by
    # default — the gate is the point of the coverage manifest.
    disable_coverage_gate: bool = Field(default=False, alias="TALON_DISABLE_COVERAGE_GATE")

    # When true (default), low-signal file-fallback units (kind=file, no vulnerability_class —
    # whole-file "read this file" obligations where the scanner found no construct) must
    # ALSO be dispositioned before finish_scan. This is the lowest-signal, highest-cost tier
    # (forces reading every remaining file cover-to-cover); on by default in this recall-first
    # build. Set TALON_STRICT_FILE_FALLBACK=false to skip it and speed the pass.
    strict_file_fallback: bool = Field(default=True, alias="TALON_STRICT_FILE_FALLBACK")

    # When true (default), the recall gate ALSO requires every enumerated entrypoint unit
    # (kind route/handler/entrypoint/contract_fn) to be dispositioned, not only units with
    # a vulnerability_class — an attack-surface entry is an obligation to deep-review
    # regardless of a guessed class. Closes the gap where a seeded entry is advisory-skipped
    # yet finish is allowed (the SSTI-class miss: a dangerous line in a low-signal-only
    # file). Black-box / empty-manifest scans stay exempt (handled upstream). Set
    # TALON_ENTRYPOINT_GATE=false to fall back to the class-only gate.
    entrypoint_gate: bool = Field(default=True, alias="TALON_ENTRYPOINT_GATE")

    # When true (default), finish_scan is blocked while any in-scope source file is owned by
    # NO coverage unit (the filesystem-derived denominator: the tree walked with the same
    # eligibility rules as seeding, minus tests/vendored/generated). On by default in this
    # recall-first build — turns "a source file was never even enumerated" into a hard failure
    # instead of a mere note. It is the objective, agent-independent floor for "was every file
    # covered", complementary to the disposition gate (every unit reviewed) and P0 (dispositions
    # cite real per-file evidence). Set TALON_STRICT_COVERAGE=false to demote it back to a note.
    strict_coverage: bool = Field(default=True, alias="TALON_STRICT_COVERAGE")

    # When true (default), finish_scan auto-dispositions any pending blocking unit whose file
    # is MACHINE-VERIFIED unauditable — a build artifact / minified bundle (generated-path
    # name AND a one-enormous-line structure, checked in the sandbox). This is the recall-safe
    # escape from a deadlock where a residual minified chunk carries a vulnerability_class it
    # can never be given a resolving file:line for, and thus blocks the gate forever. It is
    # fail-closed toward review: real source (anything not double-proved) is never touched and
    # stays blocking. Set false for a paranoid run where even verified artifacts must be
    # dispositioned by a human/agent (they will then block finish until cleared).
    auto_skip_unauditable: bool = Field(default=True, alias="TALON_AUTO_SKIP_UNAUDITABLE")

    # When true (default), ruling OUT a blocking coverage unit (dropping a review obligation)
    # requires independent confirmation: mark_unit_reviewed must carry a confirmed_by naming a
    # different agent than the one dispositioning. codejury's recall-safe deletion rule — a
    # lone finder cannot delete its own obligation; uncertainty stays pending. On by default in
    # this recall-first build, but it REQUIRES the orchestration to run a challenger and pass
    # its id (see the Rule 5 flow) — without a challenger a ruled_out obligation stays pending
    # and finish_scan cannot pass the gate. Set TALON_RULEOUT_REQUIRES_CONFIRMATION=false for
    # single-finder / no-challenger runs.
    ruleout_requires_confirmation: bool = Field(
        default=True, alias="TALON_RULEOUT_REQUIRES_CONFIRMATION"
    )

    # When true (default), seed_static_inventory pairs every enumerated entrypoint
    # (route/handler/task/consumer) with a MISSING_AUTHENTICATION obligation unit, so the
    # recall gate forces an explicit "this entry is authenticated / intentionally public"
    # disposition. Absence-of-control bugs have no sink for grep/semgrep to find (no
    # @login_required is *no code*), so this is the machine floor that keeps "did anyone check
    # auth on this entry?" from being silently skipped. On by default in this recall-first
    # build; it roughly doubles the manifest (each obligation is medium → blocking). Set
    # TALON_AUTH_OBLIGATIONS=false to skip it.
    auth_obligations: bool = Field(default=True, alias="TALON_AUTH_OBLIGATIONS")

    # When true, agents are built without the Filesystem capability, dropping the
    # write/edit tool (``apply_patch``) and ``view_image``. The agent can still read via
    # shell (cat/grep) and run SAST tools, but has no structured way to modify source.
    # On by default — a static audit never writes target source; set
    # ``TALON_READONLY=false`` to allow apply_patch. Independent of this flag, both
    # backends run the agent against a CoW clone or copy, never the original.
    readonly: bool = Field(default=True, alias="TALON_READONLY")


class IntegrationSettings(BaseSettings):
    model_config = _BASE_CONFIG

    perplexity_api_key: str | None = Field(default=None, alias="PERPLEXITY_API_KEY")


class Settings(BaseSettings):
    model_config = _BASE_CONFIG

    llm: LlmSettings = Field(default_factory=LlmSettings)
    runtime: RuntimeSettings = Field(default_factory=RuntimeSettings)
    agents: AgentSettings = Field(default_factory=AgentSettings)
    integrations: IntegrationSettings = Field(default_factory=IntegrationSettings)

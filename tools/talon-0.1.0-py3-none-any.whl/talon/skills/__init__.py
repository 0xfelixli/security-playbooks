import logging
import re
from collections.abc import Iterator
from pathlib import Path

from talon.utils.resource_paths import get_talon_resource_path


logger = logging.getLogger(__name__)

_FRONTMATTER_PATTERN = re.compile(r"^---\s*\n.*?\n---\s*\n", re.DOTALL)
_DESCRIPTION_RE = re.compile(r"^description:\s*(.+?)\s*$", re.MULTILINE)

_INTERNAL_SKILL_CATEGORIES: frozenset[str] = frozenset({"scan_modes", "coordination"})


def _iter_user_skill_files() -> Iterator[tuple[str, str]]:
    """Yield ``(category, skill_name)`` for every user-selectable skill.

    ``category`` is the file's parent directory relative to the skills root, posix-style,
    so a nested rule ``rules/vulnerability/xss.md`` reports category ``rules/vulnerability``.
    Internal categories are matched on their top-level segment; ``__``-prefixed and
    skills-root files are skipped. Sorted for deterministic ordering.
    """
    skills_dir = get_talon_resource_path("skills")
    if not skills_dir.exists():
        return
    for file_path in sorted(skills_dir.rglob("*.md")):
        parts = file_path.parent.relative_to(skills_dir).parts
        if not parts or any(p.startswith("__") for p in parts):
            continue
        if parts[0] in _INTERNAL_SKILL_CATEGORIES:
            continue
        yield "/".join(parts), file_path.stem


def get_all_skill_names() -> set[str]:
    """Return every user-selectable skill name (bare, no category prefix)."""
    return {name for _, name in _iter_user_skill_files()}


def _skill_description(path: Path) -> str:
    """First ``description:`` line from a skill's frontmatter (empty string if none)."""
    try:
        text = path.read_text(encoding="utf-8")
    except OSError:
        return ""
    frontmatter = _FRONTMATTER_PATTERN.match(text)
    if frontmatter is None:
        return ""
    match = _DESCRIPTION_RE.search(frontmatter.group(0))
    return match.group(1).strip() if match else ""


def get_available_skills() -> dict[str, list[tuple[str, str]]]:
    """Group user-selectable skills by category as ``(name, description)`` pairs.

    Surfacing each skill's frontmatter ``description`` grounds the agent's skill
    selection (``load_skill`` / ``create_agent(skills=...)``) — otherwise it picks blind
    from bare filenames while the rich rules/* frontmatter (impact/CWE/tags) sits unused.
    ``description`` is empty when a skill declares none.
    """
    skills_dir = get_talon_resource_path("skills")
    grouped: dict[str, list[tuple[str, str]]] = {}
    for category, name in _iter_user_skill_files():
        description = _skill_description(skills_dir / category / f"{name}.md")
        grouped.setdefault(category, []).append((name, description))
    return grouped


def validate_requested_skills(skill_list: list[str], max_skills: int = 5) -> str | None:
    """Validate a list of user-passed skill names.

    Returns ``None`` on success, or a model-readable error message
    describing what was wrong (count exceeded, unknown names).
    """
    if len(skill_list) > max_skills:
        return (
            f"Cannot specify more than {max_skills} skills per agent; "
            f"got {len(skill_list)}. Aim for 1-3 related skills per specialist."
        )
    if not skill_list:
        return None
    available = get_all_skill_names()
    invalid = sorted({s for s in skill_list if s not in available})
    if invalid:
        return f"Invalid skill name(s): {invalid}. Available skills: {sorted(available)}"
    return None


def load_skills(skill_names: list[str]) -> dict[str, str]:
    """Load skill markdown bodies (frontmatter stripped) by name.

    A skill is addressed by bare ``stem`` (resolved anywhere in the skills tree) or by
    ``top-category/stem`` (resolved anywhere under that top category). Physical sub-folders
    (e.g. ``rules/vulnerability/``) are invisible to this addressing — the stem is the
    identity. Missing skills are logged and skipped.
    """
    skills_dir = get_talon_resource_path("skills")
    if not skills_dir.exists():
        return {}

    # stem -> file, from a recursive walk. Sorted so a stem collision across folders (should
    # never happen — see test_no_cross_category_skill_name_collisions) resolves
    # deterministically rather than by filesystem iteration order, which varies across hosts.
    by_stem: dict[str, Path] = {}
    for file_path in sorted(skills_dir.rglob("*.md")):
        if any(p.startswith("__") for p in file_path.relative_to(skills_dir).parts):
            continue
        by_stem.setdefault(file_path.stem, file_path)

    def _resolve(name: str) -> Path | None:
        if "/" in name:
            top, _, rest = name.partition("/")
            stem = rest.rsplit("/", 1)[-1]
            top_dir = skills_dir / top
            matches = sorted(top_dir.rglob(f"{stem}.md")) if top_dir.is_dir() else []
            return matches[0] if matches else None
        return by_stem.get(name)

    skill_content: dict[str, str] = {}
    for skill_name in skill_names:
        path = _resolve(skill_name)
        if path is None or not path.exists():
            logger.warning("skill.load: not found %s", skill_name)
            continue
        try:
            content = path.read_text(encoding="utf-8")
        except (OSError, ValueError) as e:
            logger.warning("skill.load: failed %s: %s", skill_name, e)
            continue
        var_name = skill_name.split("/")[-1]
        skill_content[var_name] = _FRONTMATTER_PATTERN.sub("", content).lstrip()

    logger.debug("skill.load: %d resolved: %s", len(skill_content), ", ".join(skill_content.keys()))
    return skill_content

# 📚 Talon Skills

## 🎯 Overview

Skills are specialized knowledge packages that enhance Talon agents with deep expertise in specific vulnerability types, technologies, and testing methodologies. Each skill provides advanced techniques, practical examples, and validation methods that go beyond baseline security knowledge.

---

## 🏗️ Architecture

### How Skills Work

When an agent is created, it can explicitly request up to 5 specialized skills relevant to the specific subtask and context at hand (on top of that, a fixed set of scaffold skills — e.g. scan_mode, tooling/python_sandbox, coordination — is always injected regardless of this limit; see `talon/agents/prompt.py::_resolve_skills`):

```python
# Agent creation with specialized skills
create_agent(
    task="Test authentication mechanisms in API",
    name="Auth Specialist",
    skills=["authentication_jwt", "business_logic"]
)
```

The skills are dynamically injected into the agent's system prompt, allowing it to operate with deep expertise tailored to the specific vulnerability types or technologies required for the task at hand.

---

## 📁 Skill Categories

| Category | Purpose |
|----------|---------|
| **`/rules`** | Security rules, split into `rules/<kind>/` sub-folders by their frontmatter `kind`: `vulnerability/` (weakness classes — sql_injection, command_injection, path_traversal, IDOR, …), `infrastructure/` (IaC/CI — terraform, docker, kubernetes, github_actions), `framework/` (framework-specific security — django, fastapi, celery), `protocol/` (oauth). A skill is still addressed by bare name; the sub-folder is organizational only |
| **`/guides`** | Framework / language / quality guides: django, fastapi, python, go, react, typescript, entrypoints enumeration, best_practice |
| **`/scan_modes`** | Scan-mode playbooks: quick / standard / deep |
| **`/coordination`** | Orchestration playbooks: root_agent, source_aware_whitebox, exhaustive_sweeps |
| **`/tooling`** | CLI playbooks for sandbox tools: `semgrep`, `python_sandbox` (running Python via `exec_command`). Other tools in the container (ast-grep, gitleaks, trivy) are usable directly but have no dedicated playbook skill yet |
| **`/custom`** | Specialized analysis skills: source_aware_sast, severity_rubric, false_positive_traps, auth_model, auth_lifecycle, crypto_misuse, hygiene_checklist |

Notable source-aware skills:
- `source_aware_whitebox` (coordination): white-box orchestration playbook
- `source_aware_sast` (custom): semgrep/AST/secrets/supply-chain static triage workflow

---

## 🎨 Creating New Skills

### What Should a Skill Contain?

A good skill is a structured knowledge package that typically includes:

- **Advanced techniques** - Non-obvious methods specific to the task and domain
- **Practical examples** - Working payloads, commands, or test cases with variations
- **Validation methods** - How to confirm findings and avoid false positives
- **Context-specific insights** - Environment and version nuances, configuration-dependent behavior, and edge cases
- **YAML frontmatter** - `name` and `description` fields for skill metadata

Skills focus on deep, specialized knowledge to significantly enhance agent capabilities. They are dynamically injected into agent context when needed.

---

## 🤝 Contributing

Contributions welcome — propose new skills via merge request, or contact security@cobo.com to help expand the collection for Talon agents.

---

> [!NOTE]
> **Work in Progress** - We're actively expanding the skills collection with specialized techniques and new categories.

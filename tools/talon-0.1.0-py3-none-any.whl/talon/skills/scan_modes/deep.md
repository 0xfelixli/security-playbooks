---
name: deep
description: Exhaustive static code security audit — full coverage across audit dimensions, advance/challenge rounds until convergence
---

# Deep Code Audit Mode

Exhaustive static security audit of a codebase. Maximum coverage, maximum depth. Finding what others miss through code analysis is the goal.

## Execution Model

Phases 1-4 below are **audit dimensions** (what to review), NOT a one-pass linear sequence. You work them inside an **advance/challenge loop**: advance rounds deepen coverage on unreviewed entries/sinks; challenge rounds refute existing conclusions. Loop until the coverage manifest converges and `finish_scan`'s recall gate passes. File findings via `create_vulnerability_report`; keep working notes with the note/todo tools — do NOT hand-write files or directories.

## Approach

Thorough understanding before analysis. Review every parameter, every endpoint, every code path. Trace data flows end-to-end to understand systemic impact.

## Phase 1: Code Understanding

**Source-aware static analysis**
- Build the coverage manifest as the backbone of recall: `seed_static_inventory` for the file/construct inventory, `seed_coverage_from_semgrep` to seed from SAST hits, then `add_coverage_units` for every route/handler/sink/entry point. The recall gate blocks `finish_scan` until every high-signal unit with a `vulnerability_class` is dispositioned via `mark_unit_reviewed`; use `list_coverage` to see what remains.
- Start with broad source-aware triage (`semgrep`, `ast-grep`, `gitleaks`, `trivy fs`) and use outputs to drive deep review.
- Execute at least one structural AST pass (`sg`) per repository and store artifacts for reuse; keep them bounded and query-driven (target relevant paths/sinks; avoid whole-repo generic dumps).
- Drive review with a sink→source taint pass: for each dangerous sink, `trace_symbol(direction=callers)` back to a source across files (see `source_aware_sast`).

**Entry-point enumeration — three parallel strategies, take the union** (no single strategy is complete):
- **Route-declaration path**: read route registries (`urls.py`, `router.py`, `app.include_router`); expand every `include()` and auto-generated ViewSet action.
- **Decorator/handler grep**: grep `@app.route`, `@api_view`, `@action`, `path(`, `re_path(`, `@router.get/post` — catch handlers not listed in route files.
- **Test-file path**: grep `client.get`, `client.post`, `reverse(` — tests often reference endpoints missing from route files.
- **Framework-implicit**: Django admin auto-CRUD, management commands, Celery beat, MQ consumers, internal RPC/gRPC (mTLS ≠ no IDOR), webhook receivers, archive/deserialization points, frontend routes/postMessage/URL-param reads.
- **Action-dispatch expansion (mandatory)**: for dynamic action routing (`(?P<action>[^/]+)`, `dispatch()`, ViewSet), do NOT count the whole handler as one entry — expand to each action method (ViewSet → list/create/retrieve/update/partial_update/destroy + every `@action`). Count expanded methods, not URL patterns. Add each as a coverage unit.

**Dangerous-sink scan** — grep known sinks per stack (this table is *which* sinks to trace; the taint pass above is *how*):

| Class | Typical sinks |
|---|---|
| SQLi | `cursor.execute`, `.raw(`, `RawSQL`, `extra(where=`, string-formatted SQL |
| Command | `os.system`, `subprocess`, `Popen`, `eval`, `exec` |
| SSRF | `requests.get/post`, `httpx`, `urllib`, `fetch(` |
| Path traversal | `open(`, `os.path.join`, `send_file`, `FileResponse` |
| File write | `open(...,'w'/'wb'/'a')`, `.write_text(`, `shutil.copy/move`, `fs.writeFile` with attacker-controlled path OR contents (CWE-73) — overwriting source/template/config → RCE; report as CWE-73 not CWE-94; see `arbitrary_file_write` |
| Template injection | `render_to_string(`, `Template(`, Jinja2 `Environment(` |
| Deserialization | `pickle.loads`, `yaml.load(` (non-safe), `marshal.loads` |
| Secret/PII exposure | `logger.`, `print(`, sensitive field names in responses |
| Log injection | untrusted input in `logger.*` / `print(` / `console.log` / `log.Printf` calls without CR/LF neutralization (CWE-117) — a logging call IS a sink; see `log_injection` |

For each sink: trace the source back and decide whether it is **untrusted** — do NOT stop at "is it a request parameter?". A source is untrusted if it is any of: an HTTP request field (param / header / body / cookie); an **env-var / config-driven value or URL** (config can be injected, and an unvalidated outbound URL is itself SSRF no matter who set it); the **response body of an outbound HTTP call / upstream API** (the remote can be attacker-controlled or MITM'd → second-order XSS / SQLi / command injection when reflected into a sink); a value **read back from the DB** (stored / second-order); or a **decrypted / decoded / deserialized / file-read** value. Only a compile-time constant in this process is trusted. Cross-check against entry enumeration.

**Control-presence sweep (absence-of-control)** — the sink→source pass above finds *dangerous code that exists*; this pass finds *safeguards that should exist but don't*. Absence bugs have **no sink**, so grep/semgrep and the inventory seed never surface them — they must be driven from **entries, not sinks**, or they silently pass `finish_scan`:
- Enumerate entries / response surfaces / deploy config, then for each check the controls it **owes**: auth endpoints → rate limiting (`rate_limiting`) + authentication present (`missing_authentication`); any sensitive endpoint → an auth check; HTML responses → clickjacking headers (`clickjacking`); externally-reachable listeners → transport encryption incl. reverse-proxy config (`insecure_transport`); any cross-origin API → exact-match CORS allowlist, not reflected/wildcard origin with credentials (`cors_misconfiguration`); framework/server config → no debug/dev mode or permissive default left enabled in production (`security_misconfiguration`); error handlers and logging call sites → no secret/PII/stack trace reaching a log or a client response (`information_exposure`).
- For each owed-but-absent control, file the finding **and** `add_coverage_units` for that obligation so the recall gate forces a disposition — otherwise absence bugs never enter the manifest and the gate can't protect them.

**Analysis baseline** — record with the note tool for later reference (sinks themselves are tracked as coverage units, not duplicated here):
- **auth-model**: how authz is enforced (decorator/middleware/guard/permission class); roles/tenants/services; where trust boundaries sit.
- **sensitive-data-map**: where tokens/keys/PII/tenant data live and flow; note fields written to DB then read back and rendered (stored-XSS / second-order source). Flag any password/secret written to DB/disk/log without a KDF hash or encryption — check the **write site in views/services**, not just the model field declaration (plaintext storage, CWE-256; see `plaintext_password`).

Also map from the code: authentication mechanisms, authorization/access-control model, external service integrations and API calls, config secrets/misconfigurations, DB schemas and relationships, background jobs/cron/async processing, serialization/deserialization points, file upload/download/processing, and deployment/infra assumptions.

## Phase 2: Business Logic Deep Dive

Build a complete storyboard from the code:

- **User flows** — trace every step of every workflow through the code
- **State machines** — map all transitions (Created → Paid → Shipped → Delivered); which transitions are guarded
- **Trust boundaries** — where privilege changes hands
- **Invariants** — rules the application should always enforce
- **Implicit assumptions** — what the code assumes that might be violated
- **Multi-step abuse surfaces** — where normal functionality can be chained or abused
- **Third-party integrations** — external service dependencies

Read the code paths for every user type to understand the full data lifecycle.

## Phase 3: Attack-Surface Audit

Audit every input vector for every applicable vulnerability class. **Review the code and data flow — do NOT send requests, fuzz, or fire payloads; this is a static audit.** Vulnerability classes stay; the black-box *actions* do not.

**Input Handling**
- Injection classes: SQL, NoSQL, LDAP, XPath, command, template
- Missing/incorrect input validation, type confusion, boundary handling
- Unsafe deserialization points

**Authentication & Session**
- Auth bypass paths, session fixation/prediction in code
- JWT/token verification flaws (alg confusion, missing signature/claim checks)
- OAuth flow handling; password-reset token generation/reuse/timing
- MFA enforcement gaps; account enumeration channels

**Access Control**
- Horizontal/vertical access control on every endpoint (IDOR / BFLA)
- Object-reference ownership checks; parameter-tampering surfaces
- Access control after state changes (logout, role change)

**File Operations**
- Upload validation (extension/content-type/magic bytes) in code
- Path traversal on file parameters; SSRF via file inclusion; XXE at XML parse points

**Business Logic**
- Race conditions / TOCTOU on state-changing operations (review locking/atomicity in the code)
- Workflow/step bypass on multi-step processes
- Price/quantity manipulation surfaces

**Framework-specific**
- Prototype pollution (JS), CORS misconfiguration (`cors_misconfiguration`), GraphQL introspection/batching/nested-query handling, WebSocket auth
- Reverse-proxy / gateway framing: HTTP request smuggling from a front-end/back-end parsing disagreement (`http_request_smuggling`); response headers built from request input without CR/LF stripping (`http_response_splitting`)
- LLM / agent / MCP integrations: untrusted external content (fetched page, tool result, stored record) reaching a model prompt with no instruction/data separation while a capable tool is reachable downstream (`prompt_injection`)

**Verifying a candidate — four-step refutation** (all four, or keep as confirmed/blocked):
1. Enumerate ALL call paths: grep every caller, walk up to the entry.
2. Read the control-point implementation (not comments/docs).
3. Verify the control point covers every path (decorator on CBV doesn't cover FBV; middleware exempt-lists don't cover exempt routes; internal calls may bypass middleware).
4. Verify the control point has no known bypass (`permission_required` without `raise_exception=True`; JWT not verifying `alg`).

Anything requiring runtime info to confirm → mark `blocked`, do not self-filter.

## Phase 4: Impact & Data-Flow Chaining

Individual findings are starting points. Trace — statically, through code and data flow — how they combine:

- Combine information disclosure with access-control gaps
- Trace SSRF reachability to internal services through the code
- Report every low-severity / hygiene finding on its own AND note where it enables a higher-impact chain. Low severity ranks it lower — never a reason to skip filing it.
- Cross component boundaries in the code: user → admin, external → internal, read → write, single-tenant → cross-tenant
- Ask of each finding: "what does this unlock next?" — follow the data flow toward maximum privilege / data exposure

## Phase 5: Coverage & Challenge

When advance rounds stop turning up new coverage, switch to challenge rounds; alternate until convergence:

- **Re-derive refuted conclusions**: apply the four-step refutation (Phase 3) to each — if call paths are incomplete or a control point doesn't hold, reactivate it to `blocked`.
- **Pattern propagation**: for each confirmed sink, grep the whole repo for the same pattern and file every new hit separately.
- **Spot-check reviewed units**: confirm they actually traced to the sink layer, not just the handler head.
- **Loop until dry**: keep alternating advance/challenge until consecutive rounds add no new coverage or findings and the recall gate passes.

## Phase 6: Reporting

- Document every confirmed vulnerability with full code evidence (`file:line`)
- Include all severity levels — low findings may enable chains
- Complete reproduction: the static call path (entry → sink), plus a PoC input where it clarifies exploitability
- Remediation guidance as prose or minimal snippets only — do NOT write changes into the target repository
- Note areas requiring review beyond current scope

## Agent Strategy

After code understanding, partition the seeded coverage surface across parallel deep-review agents. **Primary axis: cohesive file/subsystem slices** — group related files by directory/module (use `list_coverage` with `include_clusters=true` for the `pending_units_by_dir` grouping) so each slice agent owns and dispositions EVERY pending unit in its files, across ALL vulnerability classes at each site. One agent holds whole-file context; a dense file's units must NOT be scattered across class-only agents. Keeping related files in one slice keeps its `trace_symbol` cross-file work self-contained.

Reinforce the slice pass with secondary axes (reinforcement, not the primary coverage):

1. **Cross-cutting class sweeps** — one lens (`access-control`, `data-input`/injection, `external-call`/SSRF, `data-exposure`, crypto) swept across the whole surface to catch what a slice missed.
2. **Dense-file re-sweeps** — files with many pending units (`high_density_files` in `list_coverage` with `include_clusters=true`) get a dedicated fresh-context re-sweep; single-pass recall collapses on dense files.
3. **By-flow lens** — for sinkless classes (business-logic, auth-lifecycle, IDOR/BFLA, TOCTOU) that no single sink pins, drive from entrypoints and trace entry→sink across files.

Do NOT partition purely by vulnerability class — a slice agent owns a *place* and checks all classes there; class sweeps only reinforce. An entry may belong to multiple slices/lenses — over-assign rather than miss.

## Mindset

Thorough. Rigorous. Patient. Systematic.

This is about finding what others miss — through exhaustive code coverage, not attack theatrics. Review every parameter, every endpoint, every trust boundary, every dangerous sink. A refuted finding must survive all four refutation steps. Loop until dry.

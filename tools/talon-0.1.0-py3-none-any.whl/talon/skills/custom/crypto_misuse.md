---
name: crypto_misuse
description: Deep checklist for cryptographic misuse — beyond hardcoded keys: authentication, IV/nonce, padding, algorithms, KDF, randomness. Report each misuse as its own finding.
---

# Cryptographic Misuse (deep)

Finding a hardcoded key is only one crypto bug. When you touch any encrypt / decrypt
/ hash / sign / token / random-generation site, **analyze the usage**, not just the
key. Each distinct misuse below is its **own** finding (own CWE) — do not collapse
them into one "weak crypto" report. `poc_script_code` may be empty; `poc_description`
must explain the cryptographic attack (what an attacker forges/decrypts/predicts).

Trace each crypto call site and check:

## 1. Confidentiality without integrity
- AES-CBC / AES-CTR / stream ciphers **without a MAC** (encrypt-only) → ciphertext
  tampering, and with CBC a **padding oracle** if errors are distinguishable.
- ECB mode (leaks structure). Prefer authenticated modes (AES-GCM, ChaCha20-Poly1305).

## 2. IV / nonce
- **Static, hardcoded, reused, or predictable IV/nonce** (e.g. fixed bytes, zero IV,
  counter reset). CBC needs a random unpredictable IV; GCM/CTR nonce must never repeat.

## 3. Padding
- **Custom pad/unpad** logic, or unpadding that raises distinguishable errors →
  padding-oracle decryption. Manual PKCS#7 handling is a red flag.

## 4. Algorithms & libraries
- Weak/broken: MD5/SHA1 for security, DES/3DES, RC4, ECB.
- Deprecated libs: **PyCrypto** (unmaintained; use pycryptodome), old OpenSSL bindings.
- Weak password hashing: fast hashes (MD5/SHA*) or unsalted, instead of
  bcrypt/argon2/scrypt with proper cost.

## 5. Key derivation & management
- Missing/static salt; low iteration counts; deriving keys by plain hashing of a
  password; key == IV; keys committed in source/config/seed.

## 6. Randomness
- Security values (tokens, session ids, reset tokens, IVs, salts) from a
  **non-CSPRNG** (`random`, time-seeded, small space) → predictable/forgeable.

---

Report examples you must not miss (all can coexist in one crypto module):
- unauthenticated AES-CBC (CWE-327/CWE-353)
- static IV reuse (CWE-329)
- custom unpad / padding oracle (CWE-347/CWE-696)
- hardcoded key (CWE-321) — file separately even if you already noted the algorithm issue

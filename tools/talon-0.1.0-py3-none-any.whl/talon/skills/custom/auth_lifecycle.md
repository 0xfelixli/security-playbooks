---
name: auth_lifecycle
description: Deep checklist for authentication/session lifecycle — session fixation, token rotation, entropy, expiry, and account enumeration. Stateful/temporal properties an attack-chain lens misses.
---

# Authentication & Session Lifecycle (deep)

These are **stateful / temporal** properties — you can't see them by pattern-matching
one line; you must reason across the login → session → logout → reset flow. Check
each and file each as its own finding (`poc_description` explains the attack; script optional).

## 1. Session fixation & rotation
- **Session/auth token NOT rotated on login** or on privilege change → session
  fixation (attacker fixes a victim's token pre-auth, inherits the authed session).
- Token unchanged across auth boundary; same identifier before and after login.

## 2. Session invalidation & expiry
- Logout does not server-side invalidate the session/token.
- Sessions/tokens never expire; no idle/absolute timeout; reusable after logout.

## 3. Token quality (entropy / predictability)
- Auth/reset/verify tokens derived from **MD5 / timestamps / sequential ids / small
  random space** → guessable or brute-forceable.
- Reset/verification tokens: **no expiry, reusable, not single-use, or predictable.**

## 4. Cookie flags (cross-ref hygiene)
- Auth/session cookies missing `Secure` / `HttpOnly` / `SameSite`.

## 5. Account enumeration — check EVERY auth surface
- Login, signup, AND password-reset responses that let an attacker tell whether a
  username/email exists — via **different messages OR response timing OR status/redirect**.
- Common miss: reset-flow enumeration gets caught but **login-flow enumeration is
  overlooked** (or vice-versa). Verify BOTH: does the login error distinguish
  "no such user" from "wrong password"? Does signup reveal "already registered"?

---

Sweep the whole auth surface, not one endpoint. A single app typically has several
of these at once (e.g. no rotation on login + MD5-based token + login enumeration) —
report each independently.

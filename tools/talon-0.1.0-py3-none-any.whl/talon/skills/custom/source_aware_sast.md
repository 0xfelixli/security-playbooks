---
name: source-aware-sast
description: Practical source-aware SAST and AST playbook for semgrep, ast-grep, gitleaks, and trivy fs
---

# Source-Aware SAST Playbook

Use this skill for source-heavy analysis where static and structural signals should guide optional dynamic testing (when feasible).

## Fast Start

Your working directory is the **workspace root**; your source is in the `<subdir>/` from
the scope's `authorized_targets` (e.g. `fides/`). Run scanners against that subdir, and
store all outputs in the artifact dir `$ART` — an **absolute, injected, always-writable**
path (`/workspace/.talon-source-aware`), outside the possibly read-only source tree:

```bash
# $ART is the injected ABSOLUTE artifact dir. Always reference artifacts by this absolute
# path — never hand-build a relative path like `../.talon-source-aware/...`.
ART="$TALON_ARTIFACT_DIR"
mkdir -p "$ART"
```

When a tool takes a path to an artifact (`seed_coverage_from_semgrep`,
`seed_static_inventory`), pass the **absolute** `$ART/...` path — e.g. `$ART/semgrep.json`.
These tools resolve a relative path from the **workspace root**, not from your shell's cwd,
so a relative `../…` you built while `cd`'d into a source subdir will not resolve.

## Baseline Coverage Bundle (Recommended)

Run this baseline once per repository before deep narrowing:

```bash
ART="$TALON_ARTIFACT_DIR"
mkdir -p "$ART"

# Language-adaptive rulesets. NEVER use `--config auto` — it ships the repo's
# language/framework profile to semgrep.dev to pick rules (data egress). Instead:
# a fixed cross-language baseline + registry packs for languages actually present.
# Do NOT hardcode one language (e.g. p/golang) — that misses everything on a repo
# in another language (Django DEBUG/SECRET_KEY/weak-hash/cookie rules live in
# p/python + p/django, not p/golang).
CONFIGS="--config p/default --config p/secrets --config p/owasp-top-ten"   # baseline, any repo
present() { find . -type f -name "$1" -not -path '*/.*' 2>/dev/null | head -1 | grep -q .; }
present '*.py'   && CONFIGS="$CONFIGS --config p/python"
{ present 'manage.py' || present 'settings.py'; } && CONFIGS="$CONFIGS --config p/django"
present '*.go'   && CONFIGS="$CONFIGS --config p/golang"
present '*.js'   && CONFIGS="$CONFIGS --config p/javascript"
{ present '*.ts' || present '*.tsx'; } && CONFIGS="$CONFIGS --config p/typescript"
present '*.java' && CONFIGS="$CONFIGS --config p/java"
present '*.rb'   && CONFIGS="$CONFIGS --config p/ruby"
present '*.php'  && CONFIGS="$CONFIGS --config p/php"
present '*.cs'   && CONFIGS="$CONFIGS --config p/csharp"
# Languages semgrep has no mature registry pack for (Dart, Kotlin, Swift, …) get
# only the baseline here — their real coverage comes from the hygiene checklist +
# your own reading, which are language-agnostic. Do not skip those files.
echo "semgrep configs: $CONFIGS"

semgrep scan $CONFIGS --metrics=off --json --output "$ART/semgrep.json" .
# Build deterministic AST targets from semgrep scope (no hardcoded path guessing)
python3 - <<'PY'
import json
import os
from pathlib import Path

art = Path(os.environ["TALON_ARTIFACT_DIR"])
semgrep_json = art / "semgrep.json"
targets_file = art / "sg-targets.txt"

try:
    data = json.loads(semgrep_json.read_text(encoding="utf-8"))
except Exception:
    targets_file.write_text("", encoding="utf-8")
    raise

scanned = data.get("paths", {}).get("scanned") or []
if not scanned:
    scanned = sorted(
        {
            r.get("path")
            for r in data.get("results", [])
            if isinstance(r, dict) and isinstance(r.get("path"), str) and r.get("path")
        }
    )

bounded = scanned[:4000]
targets_file.write_text("".join(f"{p}\n" for p in bounded), encoding="utf-8")
print(f"sg-targets: {len(bounded)}")
PY
xargs -r -n 200 sg run --pattern '$F($$$ARGS)' --json=stream < "$ART/sg-targets.txt" \
  > "$ART/ast-grep.json" 2> "$ART/ast-grep.log" || true
gitleaks detect --source . --report-format json --report-path "$ART/gitleaks.json" || true
# Keep trivy focused on vuln/misconfig (secrets already covered above) and increase timeout for large repos
trivy fs --scanners vuln,misconfig --timeout 30m --offline-scan \
  --format json --output "$ART/trivy-fs.json" . || true
```

## Semgrep First Pass

Use Semgrep as the default static triage pass:

```bash
ART="$TALON_ARTIFACT_DIR"; mkdir -p "$ART"
# Preferred deterministic profile set (works with --metrics=off)
semgrep scan --config p/default --config p/golang --config p/secrets \
  --metrics=off --json --output "$ART/semgrep.json" .

# If you choose auto config, do not combine it with --metrics=off
semgrep scan --config auto --json --output "$ART/semgrep-auto.json" .
```

If diff scope is active, restrict to changed files first, then expand only when needed.

## AST-Grep Structural Mapping

Use `sg` for structure-aware code hunting:

```bash
# Ruleless structural pass over deterministic target list (no sgconfig.yml required)
ART="$TALON_ARTIFACT_DIR"
xargs -r -n 200 sg run --pattern '$F($$$ARGS)' --json=stream \
  < "$ART/sg-targets.txt" \
  > "$ART/ast-grep.json" 2> "$ART/ast-grep.log" || true
```

Target high-value patterns such as:
- missing auth checks near route handlers
- dynamic command/query construction
- unsafe deserialization or template execution paths
- file and path operations influenced by user input

## Structural Repo Mapping

Use `ast-grep` (`sg`) for syntax-aware structural mapping when grep-level mapping is
noisy — it parses code to an AST and matches structure, not text:

```bash
sg run --pattern '<structural pattern>' --json=stream <paths>
```

Use outputs to improve route/symbol/sink maps for subsequent targeted scans.

## Secret and Supply Chain Coverage

Detect hardcoded credentials:

```bash
ART="$TALON_ARTIFACT_DIR"; mkdir -p "$ART"
gitleaks detect --source . --report-format json --report-path "$ART/gitleaks.json"
```

Run repository-wide dependency and config checks:

```bash
ART="$TALON_ARTIFACT_DIR"; mkdir -p "$ART"
trivy fs --scanners vuln,misconfig --timeout 30m --offline-scan \
  --format json --output "$ART/trivy-fs.json" . || true
```

## JavaScript-Side Coverage

For frontends and Node services, layer these on top of the language-agnostic
passes above. The baseline semgrep pass already covers `p/javascript` and
`p/typescript` when those languages are detected; supplement with structural
passes using `sg`:

```bash
ART="$TALON_ARTIFACT_DIR"; mkdir -p "$ART"

# Structural pass scoped to JS/TS files from the semgrep target list
grep -E '\.(js|ts|jsx|tsx)$' "$ART/sg-targets.txt" > "$ART/sg-js-targets.txt" || true
if [ -s "$ART/sg-js-targets.txt" ]; then
  xargs -r -n 200 sg run --pattern '$F($$$ARGS)' --json=stream \
    < "$ART/sg-js-targets.txt" > "$ART/ast-grep-js.json" 2>/dev/null || true
fi
```

For dependency vulnerability coverage on Node projects, `trivy fs` (already in
the baseline bundle) scans `package.json` / `package-lock.json` for known CVEs
and covers the main supply-chain risk without extra tooling.

## Taint Tracking: Sink → Source (Highest-Yield Pass)

Most vulnerabilities reduce to one sentence: **untrusted data reaches a dangerous
operation without adequate validation.** Instead of reading code hoping to spot
bugs, enumerate the dangerous operations (sinks) and trace each one *backwards*
to its inputs (sources). This is the single highest-recall whitebox technique.

**Method:**

1. **Enumerate sinks** across the repo (grep / `sg`). Register each as a
   `kind=sink` coverage unit via `add_coverage_units` so it is gated to a
   disposition.
2. **Trace each sink backwards** to where its arguments come from. Use
   `trace_symbol(symbol=<enclosing function>, direction=callers)` to find the
   call sites — the upstream of the chain often lives in *other files*. Follow
   until you reach a **source** (user/attacker-controlled input).
3. **Check the path for sanitizers** — parameterization, escaping, validation,
   allow-lists, authorization. A sink fed by a source with no effective
   sanitizer in between is a finding.
4. **Disposition the unit** (`mark_unit_reviewed`): `reviewed` with the
   source→sink note, or `ruled_out` if the path is unreachable / properly
   guarded. Record the **taint triple** in the note's `evidence` field (see
   *Recording the Source→Sink Pair* below).

**Sources (attacker-controlled):** request params/body/query, headers, cookies,
path segments, uploaded filenames/content, webhooks, message-queue payloads, and
*stored* user data read back later (second-order). For EVM: `msg.data`,
function arguments, `msg.sender`-derived trust, oracle return values.

**Dangerous sinks to enumerate:**

- **SQL/NoSQL** — string-built queries, `.raw()`, `.extra()`, `$where`, query
  concatenation.
- **Command/exec** — `os.system`, `subprocess(..., shell=True)`, `exec`/`eval`,
  `child_process.exec`, backticks.
- **Deserialization** — `pickle`, `yaml.load`, `Marshal`, Java `readObject`,
  `unserialize`.
- **Template/SSTI** — render-from-string, `Template(...)` on user input.
- **Path/file** — `open`/`readFile`/`sendFile`/path joins with user input
  (traversal), archive extraction.
- **SSRF egress** — outbound HTTP/`fetch`/`requests` with user-controlled URL.
- **Redirect/headers** — `Location`/redirect from user input, header injection.
- **EVM/Solidity** — low-level `call`/`delegatecall`/`staticcall`, `transfer`/
  `send`, `selfdestruct`, `ecrecover` without nonce/replay protection,
  unchecked external-call return values, state writes after external calls
  (reentrancy), arithmetic/rounding in accounting, `tx.origin` auth.

## Third-Party API Taint-Spec Inference (Highest-Leverage Recall Lever)

The built-in sink list above is language-native. Real recall is lost on
**third-party library APIs** the deterministic scanner has never heard of — a
custom ORM's `.raw_query()`, a template lib's `render_string()`, an HTTP client
whose first argument is a URL, a "sanitizer" that only escapes HTML but is used
before a SQL sink. A pattern matcher cannot know these are dangerous; **you
can**, because you have seen these libraries used thousands of times. Inferring a
taint spec for each project dependency is the single change that most widens the
attack surface (it roughly doubled a mature static analyzer's detection rate in
published work — the IRIS result).

**Method:**

1. **Enumerate the third-party APIs the target actually calls.** Read
   `requirements*.txt` / `pyproject.toml` / `package.json` / `pom.xml` /
   `go.mod`, then grep the imports/`require`/`use` sites to see which are
   actually reached. Ignore the standard library (already covered above).
2. **Infer each API's taint role** from your prior knowledge of that library —
   do not guess from the name alone; use what you know of its documented
   behavior:
   - **source** — returns attacker-influenced data (a web framework's
     `request.args`, a queue client's `msg.body`, an SDK's `event.payload`).
   - **sink** — performs a dangerous operation with its argument (query exec,
     command spawn, deserialization, template render-from-string, outbound URL
     fetch, path join, redirect).
   - **sanitizer** — neutralizes taint **for a specific sink class only** (an
     HTML escaper does nothing for a SQL sink; a shell-quote does nothing for a
     path-traversal sink). Record *which* class it neutralizes.
   - **propagator** — passes taint through (string builders, ORM query
     builders, serializers).
3. **Register each inferred sink/source as a coverage unit** so it is gated to a
   disposition — reuse the existing manifest, no new tooling:
   ```
   add_coverage_units([
     {"kind": "sink", "location": "billing/db.py:88",
      "construct_type": "library_sink", "vulnerability_class": "SQLI",
      "confidence": "medium",                 # "low" when you are unsure → advisory only
      "title": "acme_orm.raw_query() SQL sink — inferred taint spec"}
   ])
   ```
   Use `construct_type="library_sink"` / `library_source`. Set `confidence`
   honestly: `high`/`medium` when you know the library, `low` when you are
   inferring from usage — `low` units are advisory and never block `finish_scan`,
   so over-registering costs nothing but noise.
4. **Then run the Sink→Source pass above** over the newly registered library
   sinks exactly as for native sinks, and disposition each.

Do not let an unfamiliar dependency be a blind spot: if you cannot infer a
library's role, register it as a `low`-confidence `library_sink` advisory and
say so in the disposition rather than silently skipping it.

## Recording the Source→Sink Pair

For any coverage unit that carries a `vulnerability_class`, `mark_unit_reviewed`
requires a JSON note (`decision`, `evidence`, `checked`, `other_classes_checked`;
plus `refutation` when ruling out). Make the `evidence` field carry the full
**taint triple** so the source↔sink pairing is auditable — a bare "looks fine"
is not reviewable:

```
mark_unit_reviewed(
  unit_ids="a1b2c3",
  status="reviewed",
  note='{
    "decision": "vulnerable",
    "evidence": {
      "source": "views.py:42 request.GET[\"next\"] (user-controlled query param)",
      "sink":   "utils.py:88 HttpResponseRedirect(next) (OPEN_REDIRECT)",
      "sanitizer": "none on the path — url_has_allowed_host_and_scheme() is NOT called",
      "flow": "views.profile -> utils.safe_next(next) -> HttpResponseRedirect"
    },
    "checked": "traced next from param to redirect via trace_symbol; no allow-list",
    "other_classes_checked": "SSRF: next only drives a client redirect, never a
      server-side fetch, so no SSRF sink here; no other class applies at this site"
  }'
)
```

When ruling a unit **out**, the same fields plus a `refutation` (the strongest
exploit case and why it concretely fails) is required. Record `source`, `sink`,
and `sanitizer` even for `ruled_out` — "sanitizer: parameterized query via ORM
bind params, user input never concatenated" is what makes a rule-out auditable.
`other_classes_checked` is required either way — what else you considered at
this exact site (see `coordination/exhaustive_sweeps` Rule 1) — so closing this
one candidate never silently skips the rest of the site.

## Converting Static Signals Into Findings

1. Rank candidates by impact and exploitability.
2. Trace the full source-to-sink data flow for top candidates and capture the
   exact code locations.
3. Construct a concrete PoC — the request/input/payload that reaches the sink.
   Execute it dynamically when the environment is available.
4. Report a candidate once the source-to-sink flow is clearly established and a
   concrete PoC payload is provided. Dynamic execution strengthens a finding
   but is NOT a precondition — do not drop a well-evidenced source-level finding
   just because the app could not be run. State in the analysis whether it is
   source-confirmed or dynamically-confirmed.

## Anti-Patterns

- Do not treat scanner output as final truth.
- Do not spend full cycles on low-signal pattern matches.
- Do not report low-confidence guesses: require a clear, traceable source-to-sink
  flow (or equivalent strong source evidence) plus a concrete PoC payload.

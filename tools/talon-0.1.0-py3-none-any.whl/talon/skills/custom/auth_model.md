---
name: auth_model
description: Build a shared authorization model + sensitive-data map once in recon, so every unit-review agent judges IDOR/BFLA/mass-assignment against the same expected access control instead of guessing per-agent. Zero tools — a workspace artifact all agents read.
---

# Shared Authorization Model (built once, read by every unit)

The weakest recall classes — **IDOR, broken function-level authz (BFLA), business
logic, mass-assignment** — all reduce to one thing: *the actual authorization is not
the authorization that should hold*. You cannot judge "what's missing" without a
baseline for "what should be there". If every review agent re-derives that baseline
on the spot, they disagree and each misses the inconsistency that IS the bug (the one
endpoint that scopes to `user` where all its siblings scope to `owner`).

So build the authorization model **once, during recon**, write it to a workspace
file, and have every unit-review agent read it before dispositioning. This is the
artifact that makes `false_positive_traps`'s rule — *"decide ONCE whether a principal
is inside/outside a boundary, then apply it consistently"* — actually enforceable:
the decision has a home instead of living in each agent's head.

## Where it lives

Write it to **`$TALON_ARTIFACT_DIR/auth_model.md`** (an injected env var holding the
**absolute** artifact-dir path, so it survives a read-only `--mount`), the same directory as
the inventory. Reference it by that absolute path — never a bare relative name, which
resolves against the shell cwd. Every sub-agent can read it through the normal
shell/filesystem access. No tool, no store — a plain file the recon agent writes and unit
agents read.

## Build it in recon (Phase 1), before fanning out

Read the route modules, middleware, permission classes, decorators, and base
views/controllers, then fill this structure:

```markdown
# Authorization Model, Trust Boundaries, Sensitive Data

## Access control mechanism
<!-- HOW this codebase authenticates a caller and authorizes a resource: the exact
decorator / middleware / permission class / signature check / guard, and the
file:line where it is defined. Name the default: is a route protected unless it
opts out, or open unless it opts in? -->

## Actors and trust boundaries
<!-- The principals — anonymous, authenticated user, resource owner, tenant/org,
staff/admin, internal service — and the boundaries between them: which caller
distrusts which. For each boundary name the KEY that separates two principals of the
same role (owner_id, tenant_id, org_id) — that key is what an IDOR tampers with. -->

## Sensitive data map
<!-- Where tokens, secrets, PII, password hashes, keys, and OTHER tenants' data
live. The data-exposure class has no attacker entrypoint — an entrypoint-anchored
read misses a list/serializer that returns a hash field to everyone allowed to
list. Name those fields and the models that hold them. -->
```

## Three constraints that keep it from becoming a liability

A shared baseline is powerful but, if wrong, it propagates the same error
*consistently* across every shard — consistent, but consistently blind to a whole
class. So:

1. **Record the source of every claim.** Each role, boundary, and owner-key must
   cite the `file:line` (decorator / middleware / model field) that establishes it.
   A claim with no source is a guess, not a model.
2. **It is a refutable hypothesis, never gospel.** A unit-review or challenger agent
   that reads code contradicting the model (a boundary the model claimed, enforced
   differently, or not at all) must flag and correct it, not defer to it. The model
   serves comparison; it does not override the code an agent actually reads.
3. **Boundaries are keyed, and graded the same everywhere.** State each boundary once
   with its separating key. Then every finding on that boundary is judged by the same
   rule — you may not treat a principal as hostile to confirm one finding and trusted
   to refute another on the same boundary (see `false_positive_traps`).

## How a unit-review agent uses it

Before dispositioning any handler/unit, read `auth_model.md` and ask:
- **Granularity**: does this path's check scope to the boundary's *key* (owner_id /
  tenant_id), or only prove "some valid user"? An authenticated check that never
  compares the resource's owner key to the caller is an IDOR.
- **Sibling comparison**: do this endpoint's siblings scope to the owner while this
  one does not? The dropped/weakened check is the finding.
- **List/read disclosure**: does a list or serializer on this path return a field
  from the sensitive-data map to every caller allowed to list?
- **Contradiction**: does the code enforce the boundary differently than the model
  says? If so, the model is wrong here — correct it (constraint 2) and file what the
  code actually allows.

If the model is silent on a boundary this unit touches, that gap is itself
signal — add the boundary to the model with its source, don't skip the check.

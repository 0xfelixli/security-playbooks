---
name: severity_rubric
description: Calibrated severity scale (CRITICAL–LOW) with firm anti-downgrade rules. Apply when grading any confirmed finding so severity is consistent across agents and a real bug is never talked down to a non-finding.
---

# Severity Rubric

Every real finding is reported at a calibrated severity. There is no "refuted for low
impact": a real, evidenced defect is graded and surfaced, never talked out of existence
to dodge a bar. Only an unreal finding — one whose controlling fact holds when you read
the code — is `ruled_out`, and that is a refutation on the facts, not on the impact.

Grade by **impact × exploitability, on the code you actually read**:

- **CRITICAL** — a control protecting funds, signing, custody, or authentication is
  defeated with little or no precondition, or unauthenticated. Mint/move funds, take over
  an account, forge a trusted signature, RCE, read or write any user's secret material at
  will.
- **HIGH** — such a control can be defeated, but with a precondition that is a *line in
  the attack path*, not a reason to drop the finding: capture one request, hold one
  credential, win a race. Cross-user/cross-tenant IDOR to sensitive data or a privileged
  action; replay of a privileged signed request; a missing authorization check on a
  state-changing endpoint; mass assignment of a privileged field.
- **MEDIUM** — real but bounded. An unauthenticated read of status/metadata, an
  enumerable-id information leak, a defect needing heavy preconditions or yielding limited
  impact, an idempotent state trigger reachable without auth. A real missing-auth or
  enumerable defect that *looks* low impact lands here — reported, not refuted.
- **LOW** — hardening / defense-in-depth, where the honest `cvss_breakdown` for it needs
  real friction beyond `AV:N/AC:L/PR:N/UI:N` — that combination scores Medium (≥5.0) the
  moment ANY impact metric is non-`N`, so grading something LOW while still describing it
  as remotely reachable, unauthenticated, and low-complexity is a contradiction, not a
  judgment call. Genuine LOW needs `AC:H` (real attacker effort/timing beyond a normal
  request), `PR:L`/`PR:H` (attacker already holds some access), `AV:L`/`AV:P` (not
  remotely reachable), or `C:N/I:N/A:N` (no reachable impact at all) — e.g. a
  non-constant-time compare only reachable by an already-authenticated caller (`PR:L`), or
  a dev-only bypass with zero reachable production impact (`C:N/I:N/A:N`). If the metrics
  you'd honestly pick are `AV:N/AC:L/PR:N/UI:N` with any real impact, it grades MEDIUM or
  higher instead — do not force it to LOW by picking a friendlier vector than the facts.

## Firm rules (these override a cautious instinct to downgrade to nothing)

- An endpoint that is state-changing, sensitive, or returns data by an **enumerable id**
  and is reachable **without the authentication its siblings require** is reported, at
  least **MEDIUM**. "It only returns status", "it is rate-limited", "it is idempotent"
  lower the severity — they do NOT make it a non-finding.
- A signed or privileged request with **no consumed nonce or no freshness window** is a
  replay finding, at least **HIGH** for a privileged action, even when impact looks
  bounded. A signed request that drives a privileged or internal script counts as a
  privileged action.
- Disclosure of a **live credential, token, signing key, or secret** that authenticates
  or authorizes to another system is **HIGH**, not a mere information leak. A Bearer token
  or API key written to a log or returned to a caller is *usable* — the harm is the access
  it grants, not the bytes.
- When you are unsure between two levels, **report at the higher** and say why. "Unsure how
  to grade" is never a reason to drop; only an unreal finding is dropped.

## Do not talk a real finding down to nothing

"It is idempotent", "it yields the same token", "it only returns status" **lower the
severity per this rubric — they do not make the finding disappear**. A weaker signal is a
lower severity, not a dropped finding. Noise is managed by the reader sorting on severity,
never by you suppressing a real, evidenced defect. A missed real finding is worse than a
LOW the reader skips.

## Out of scope vs LOW

Only two things are dropped, never reported: dependency/component CVEs (out of this tool's
scope), and a candidate the facts refute (the controlling fact holds when you read the
code — see `false_positive_traps`). Everything else real is reported, graded.

---
name: false_positive_traps
description: Controlling-facts checklist to run before confirming OR refuting a finding — cuts false positives without dropping real bugs. Recall-safe: when uncertain, keep.
---

# False-Positive Traps

Recurring ways a static read misjudges a finding in BOTH directions: calling a safe
thing real, and refuting a real thing on an incomplete read. Before you file a report
or `ruled_out` a candidate, check it against every trap below. Each names the one
**controlling fact** to confirm in the code — decide on that fact, not on a first
impression.

## Traps that cause false positives (confirm the fact before reporting)

- **Input that looks attacker-controlled but isn't.** A value read from the session, a
  signed cookie, a server-set field, or derived from the authenticated identity is not
  attacker-controlled just because it arrives on the `request` object. *Fact: trace
  where the value is SET, not where it is read.*
- **Controls that live off the handler body.** The auth / ownership / signature / CSRF
  check may be in a decorator, middleware, permission class, base class, or wrapper —
  not in the function you are reading. *Fact: read the full dispatch path (decorators +
  base classes + middleware) before concluding a check is absent.* A single `grep` for
  the function/route name that returns nothing is not that fact — dynamic dispatch (base
  classes, DI, decorators registered elsewhere) hides real call sites from a plain-text
  search. Use `trace_symbol(direction=callers)` on the handler itself, not just on the
  literal string you searched for.
- **Reachability.** A dangerous sink is only exploitable if attacker input actually
  reaches it. *Fact: trace a concrete entrypoint→sink path. If the value at the sink is
  a constant, a server-derived value, or only reachable by an internal caller, there is
  no exploit.*
- **Concurrency / locks.** `SELECT ... FOR UPDATE` (or any side-effecting query) takes
  the row lock the moment it executes, held until commit — a discarded return value does
  NOT mean no lock was taken. *Fact: judge on production RDBMS semantics inside the real
  transaction, not on a SQLite/in-memory test where locking is a no-op.*
- **Replay / freshness.** "Authenticated", "fails closed", or "single-use" alone do not
  make a request non-replayable; conversely a consumed nonce + enforced freshness window
  does moot it. *Fact: is the exact signed request accepted twice, or is a nonce consumed
  and a timestamp window checked?*
- **Trust boundaries.** A cross-service / cross-tenant read is a finding only if the two
  sides are genuinely distinct trust domains. Decide ONCE whether a given principal
  (internal service role, sibling tenant, worker) is inside or outside the boundary, then
  apply that one answer consistently. A self-set value is still attacker-influenced when
  the setter is a distinct tenant, but trusted when the setter is the same principal.
- **Fail closed vs fail open.** A control present on the success path can still be
  bypassable through its own error / timeout / fallback branch. An auth, signature, or
  ownership check whose failure branch logs-and-continues, returns a permissive default,
  or skips the guard rather than denying is defeated by *forcing* that failure — time out
  the service it calls, or send input that throws. *Fact: read the error and fallback
  branches, not only the happy path. "The check exists" is not "the check denies on
  failure."*
- **List / ReadAll disclosure.** A list or read-all endpoint that returns a secret field
  (hash, token, password, key, another share's data) hands it to every caller allowed to
  list — including one meant to see only a less-privileged subset. *Fact: check what
  fields the serializer / response body actually exposes, not just whether listing is
  authorized. Returning a write/admin secret to a read-only viewer is an escalation, not
  a clean list.*

## Enumerate every harm path — grade by the worst

When attacker-influenced input reaches a sink, a downstream service, an **AI / LLM call**,
a callback, a log, or a cache, name EVERY harm it enables, not just the first one you see,
then grade the finding by the worst. The same flow is usually several findings at once:
injection of the content, the data that sink then returns or exposes, cross-tenant
disclosure, denial of service, an unauthenticated trigger.

- A service-controlled value that flows into an **AI/LLM description/summarize call** is
  not only a prompt-injection risk — it can also **expose whatever organization or user
  data that call returns or is given as context**. Name that data-exposure path too.
- A value that flows into a log or cache is disclosure AND, if it carries CR/LF or cache
  keys, injection. Enumerate both.

This is a discovery instruction, not a refutation one: finding more harm paths only ever
*raises* severity, never drops a finding.

## Refuting safely — recall comes first

A real finding wrongly refuted is worse than a false positive that later triage removes.
So refute (`ruled_out`) ONLY when a controlling fact makes the code genuinely safe — the
access is actually authorized, the input cannot reach the sink, or the lock genuinely
holds. These bind every refutation:

- **Do not refute for low/bounded impact, idempotency, or rate-limiting.** Those lower
  the severity — they do not delete a real finding.
- **A finding usually has several harm paths** (info disclosure, DoS by inactivating a
  victim's resource, an unauthenticated state trigger, fund movement). You must rule out
  EVERY path to refute. Ruling out one is not a refutation — proving the attacker can't
  activate their own resource does not refute a finding whose harm is inactivating the
  victim's.
- **An unauthenticated endpoint reachable by an enumerable id** that reads sensitive
  state or changes state is a real finding — do not refute it.
- **When you are not certain it is safe on all paths, keep it real** (report it, mark
  confidence). A `ruled_out` must carry the controlling fact that proves safety in its
  disposition note. When a check is enforced ad hoc at each call site of a shared
  resolver/lookup function (rather than centrally), a check you confirmed at ONE call
  site is not the controlling fact for a sibling call site reusing the same resolver —
  that sibling stays real until you check IT, independently.

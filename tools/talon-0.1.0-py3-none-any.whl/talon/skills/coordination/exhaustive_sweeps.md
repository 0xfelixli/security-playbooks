---
name: exhaustive-sweeps
description: Root-coordinator playbook for whitebox recall — spawn per-class EXHAUSTIVE sweep subagents, enumerate every CWE per site, register instance-level coverage, and run a completeness critic before finishing.
---

# Exhaustive Sweeps (root coordinator, whitebox)

You are the coordinator. A single autonomous pass **samples** — it finds the loudest
bug per area and moves on, so it misses: other instances of the same class, other
CWEs at the same site, and reasoning-heavy classes. Counter this by **fanning out
subagents** and forcing instance-level disposition. Goal is recall (completeness),
not triage.

## Rule 0 — Partition the denominator across parallel deep-review agents (do this FIRST)

Inventory + recon seed the coverage manifest with the whole review surface — often
**hundreds of units**. **Do NOT review them yourself unit-by-unit** — one agent over
hundreds of units collapses back into shallow sampling (the exact failure this fights).
Do not eyeball the manifest and hand-carve big subsystem slices either — a whole-subsystem
slice (e.g. all of `server/api`) is right back to one shallow agent over hundreds of units.
Instead, let the tool cut a fine, balanced worklist and give every slice a deep owner:

1. **`plan_review_slices` (ONCE, right after seeding).** It partitions the review-worthy
   pending surface into small **file-cluster** slices (~15 units each) and gives every dense
   file its own dedicated slice, deterministically. This is the worklist — the atom is a
   handful of related files, not a subsystem. (Low-signal file-fallback units are the wide
   sweep tier and are handled separately, not here.)
2. **Spawn ONE `create_agent` per slice.** Pass the slice's `files` as `coverage_scope`, and
   load `source_aware_sast` **plus the vuln skills matching that slice's `classes_present`**
   as its lenses. Task: *"deep-review and disposition EVERY coverage unit in these files: per
   site enumerate ALL applicable CWEs (Rule 1), trace cross-file to source, file each finding,
   then `mark_unit_reviewed` with per-file evidence."* A slice is small enough that the agent
   must actually read its files — that is the point of the fine granularity.
3. **Keep the whole slice list in flight and saturated.** Dispatch up to your concurrency cap
   immediately and, the moment one slice agent completes, spawn the next queued slice so the
   number in flight stays at the cap until the worklist is empty. Do not fan out in the first
   half hour and then trickle the tail through one agent at a time — the tail must be as wide
   as the head. Track the pending count; reassign any slice whose agent crashed or left units
   pending before finishing. The manifest reaching zero pending is how you know the whole
   denominator was actually reviewed — not by eyeballing it.

This is the primary coverage mechanism: fine slices turn the big denominator into **parallel
depth** — every unit has a deep owner over few enough files that nothing is sampled.

## Rule 0.5 — Disposition is per-file evidence, never batch rubber-stamp
`mark_unit_reviewed` clears the gate, but it is only as honest as the evidence behind it.
A blocking unit's note must cite a `file:line` **inside that unit's own file** — the tool
rejects a note that cites only unrelated files, so you cannot clear a subsystem's units
with one note pointing at a single file you happened to read.

A blocking unit's note is a **JSON object**, not prose — copy this shape so the first
call clears the gate instead of bouncing on a missing field (every bounce is a wasted
round-trip):

```json
{"decision": "reviewed", "evidence": "app/api/users.py:42 — id checked against session owner before the query", "checked": "traced the ?id param from the route into the SQL call", "other_classes_checked": "SQLi: query is parameterized; mass-assignment: fields whitelisted"}
```

`decision`, `evidence`, `checked`, `other_classes_checked` are all required; `evidence`
must point at a `file:line` **inside the unit's own file** (verified against real source).
For `status="ruled_out"` add a `refutation` field: the strongest exploit case, then why it
concretely fails (Rule 5). Practical consequences:

- **Read a file once, then batch all of that file's units into one `mark_unit_reviewed`
  call.** Units in the SAME file share a note; reviewing ten files means roughly ten
  dispositions (or a few, each citing its own files), not one call over a hundred
  unit_ids. One call may span only a handful of distinct files.
- **A systemic finding uses the `covered_by_report` channel, not a broadcast note.** If
  one root cause (e.g. the server enforces no authentication at all) makes an entire class
  vulnerable across many files, file ONE report, then `mark_unit_reviewed(..., status=
  "reviewed", covered_by_report="vuln-NNNN")`. That call must cover a single
  vulnerability_class — it clears the BFLA units, and does **not** touch the injection or
  mass-assignment units on those same routes. Those are separate dimensions and must be
  registered and reviewed on their own. "Covered by the no-auth finding" is never a reason
  to skip a route's other classes.
- If you catch yourself passing dozens of unit_ids from different files under one prose
  note, stop — that is the sampling failure wearing a coverage badge. Split it.

## Rule 1 — Enumerate EVERY CWE at each site
One handler/file often carries several **independent** vulnerabilities. Report each
separately; never stop at the first/loudest. Example: one update endpoint can be
**SQLi (CWE-89) AND mass-assignment (CWE-915) AND missing-authorization (CWE-862)**
— that is three reports, not one. "I already reported SQLi here" is not a reason to
skip the mass-assignment.

## Rule 2 — Class-exhaustive sweeps (cross-cutting REINFORCEMENT on top of Rule 0)
Rule 0's slice agents cover the whole surface but partition it geographically, so a
class that spans slices (e.g. every XSS sink across many files) can be reviewed
unevenly. Add **cross-cutting** sweeps for the high-value classes: `create_agent` one
focused sweep per class present, tasked to enumerate **every instance across the whole
repo**, not examples. This is reinforcement, not the primary coverage — slice agents
own unit disposition; class sweeps hunt patterns the geographic partition may split.
Skip classes the stack can't have; scale to budget.

| Sweep (name) | skills | must enumerate |
|---|---|---|
| XSS Sweep | `xss` | EVERY render/output point × EVERY context: HTML body, **JS string context**, HTML attribute (quoted/unquoted), URL/href, **DOM sinks (`.html()`, `innerHTML`, `document.write`)** incl. values that were decrypted/decoded, **reflected via URL path and query params**, stored |
| Access/IDOR Sweep | `idor`, `broken_function_level_authorization` | EVERY object type × EVERY operation — read AND **write AND delete**; every id/ref-taking endpoint; horizontal (other users' records) and vertical (admin); every call site of a shared cross-tenant/cross-namespace reference-resolution function — a check confirmed at one call site is not evidence of the sibling call sites reusing the same resolver |
| Traversal/Upload Sweep | `path_traversal`, `insecure_file_uploads` | BOTH directions: **download/read paths AND upload/write paths** (filename → path traversal / arbitrary write). A found download traversal does not cover the upload one |
| Injection Sweep | `sql_injection`, `nosql_injection`, `command_injection` | every query-construction site (raw/f-string/concat/ORM-escape-hatch); every subprocess/exec call — including list-form/`shell=False` — where an attacker-influenceable token could start with `-`/`--` (argument/flag injection, CWE-88, not just shell metacharacters) |
| Auth-Bypass / Desync Sweep | `auth_bypass_desync`, `missing_authentication` | every place a routing/auth decision reads one representation of the path or headers (decoded, canonicalized) while a different piece of code forwards/serves another (raw, aliased, copy-then-partial-overwrite); every exempt-list/health-check/internal-route match using `endswith`/`startswith`/substring instead of exact equality |
| Timing Side-Channel Sweep | `timing_side_channel` | every credential/token/hash/HMAC comparison; every "does this decoy/dummy value get compared for unknown users" mitigation — trace whether the decoy path is actually reached, not just present |
| Crypto Audit | `crypto_misuse` | every encrypt/decrypt/hash/token/random site — usage, not just keys |
| Auth-Lifecycle Audit | `auth_lifecycle` | login/logout/reset/session/token flows; enumeration on **login AND reset** |
| Mass-Assignment Sweep | `mass_assignment` | every bulk-bind/update handler — file CWE-915 **even where SQLi/authz already reported** |
| Config & Secrets | `hygiene_checklist`, `security_misconfiguration` | settings, Docker/compose, CI, **seed data**, **public templates** (plaintext/default creds), DEBUG/hosts/keys |
| Open Redirect | `open_redirect` | every redirect that takes a user-controlled path/url/next param |
| Cross-Origin & Header Sweep | `cors_misconfiguration`, `http_response_splitting` | every CORS policy config; every response header built from request input |
| Info Exposure Sweep | `information_exposure` | every error handler and logging call site touching request/secret data |
| LLM/Agent Sweep (skip if stack has no LLM integration) | `prompt_injection` | every prompt-construction site where external content meets a capable downstream tool |

Sweep specialists execute their sweep and **do not spawn further sweeps** (no recursion).

## Rule 3 — Instance-level coverage (use the manifest as the recall backbone)
Register coverage units at **instance granularity**, not one coarse unit per file:
- IDOR: one unit per (model × operation)
- XSS: one unit per (sink × context)
- Traversal: separate read-path and write-path units
- auth: one unit per lifecycle property (rotation, expiry, enumeration-login, enumeration-reset)

The finish gate blocks until each is dispositioned as **confirmed (report filed)** or
**ruled_out (with reason)** — so a whole class/instance can't be silently skipped.

## Rule 3.5 — High-density files get a dedicated fresh-context re-sweep
LLM recall collapses as vulnerabilities-per-file rises: a single pass over a file
carrying many units systematically under-reports (it finds a few and stops). The
geographic slice from Rule 0 folds such a file into a larger batch, where it gets the
same shallow single look. Counter this explicitly:

- `list_coverage` (with `include_clusters=true`) returns a `high_density_files` list (files with ≥5 pending units,
  densest first). For each, `create_agent` a **dedicated re-sweep specialist scoped to
  that one file**, in a **fresh context** (do NOT reuse the slice agent that already
  skimmed it — a fresh agent, ideally with a different lens, is what breaks the
  under-count). Its task: *"exhaustively enumerate EVERY vulnerability in <file>,
  one report per (CWE × site); assume there are more than the obvious one."*
- This is on top of, not instead of, Rule 0's slice ownership — the dense file still
  gets dispositioned by its slice owner; the re-sweep is a second independent pass whose
  only job is to defeat under-counting on the files where it bites hardest.
Before `finish_scan`, spawn a **Completeness Critic** subagent: given the coverage
manifest + filed reports, it asks "which classes or instances have neither a report
nor an explicit ruleout?" and re-sweeps those gaps. This also catches run-to-run
jitter — a class found in one pass but not another surfaces here. Only finish after
the critic returns clean.

## Rule 5 — Adversarial verification (Finder → Challenger → Judge)
Verify findings adversarially, tuned for **recall** (not for culling false positives):

- **Finder** = the sweep subagents above (they produce candidate findings/reports).
- **Challenger** = spawn a subagent whose job is to *try to refute* each candidate —
  challenge the reasoning, look for a sanitizer/guard that neutralizes it, or show the
  path is unreachable. The Challenger's real value is also surfacing *additional*
  subtle cross-file cases the finder missed — treat refutation attempts as extra
  search, not pruning.
- **Judge** = decide per candidate. **Recall-safe deletion:** a candidate is dropped
  ONLY when the Challenger produces a concrete, recorded refutation the Judge accepts.
  Absent a solid refutation, the finding **survives** — uncertainty defaults to keep.
  Every drop is logged as a `ruled_out` disposition with the refutation reason (the
  refutation ledger).
- **Independent confirmation for a ruleout.** Dropping a blocking unit needs a second,
  independent read, never one agent's opinion. When the Challenger (a DIFFERENT agent than
  the one that reviewed the unit) confirms the refutation, record the ruleout with
  `mark_unit_reviewed(status="ruled_out", ..., confirmed_by="<challenger agent id>")`. The
  confirming id must differ from the reviewer's — a self-confirmed refutation is not
  independent. Under `TALON_RULEOUT_REQUIRES_CONFIRMATION` this is enforced: a lone agent
  cannot rule out a blocking unit, so the obligation stays pending until a challenger signs
  off. If you cannot get independent confirmation, mark it `reviewed` (you analyzed it) or
  leave it pending — do not force a ruleout.
- Do NOT use this pass to trim borderline findings for tidiness. Its purpose is to
  confirm real bugs and pull in ones the first pass missed.
- **Model diversity (optional, when a second model is available):** run Challenger
  and Judge on a *different* model than the Finder — different models miss different
  bugs, so this both raises recall and damps run-to-run jitter. With a single model,
  still run the adversarial pass (self-challenge), but you lose the diversity gain.

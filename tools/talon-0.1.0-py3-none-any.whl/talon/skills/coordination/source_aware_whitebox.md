---
name: source-aware-whitebox
description: Coordination playbook for source-aware white-box code analysis with static triage and optional dynamic validation
---

# Source-Aware White-Box Coordination

Use this coordination playbook when repository source code is available.

## Objective

Increase white-box coverage by combining source-aware triage with dynamic validation. Source-aware tooling is expected by default when source is available.

## Recommended Workflow

1. Build a quick source map before deep analysis, including at least one AST-structural pass (`sg`) scoped to relevant paths.
   - For `sg` baseline, derive `$ART/sg-targets.txt` from `$ART/semgrep.json` scope first (`paths.scanned`, fallback to unique `results[].path`) and run `xargs ... sg run` on that list. (`$ART` = `$TALON_ARTIFACT_DIR`, the injected absolute artifact dir.)
   - Only fall back to path heuristics when semgrep scope is unavailable.
2. **Seed the coverage manifest** from the semgrep report with
   `seed_coverage_from_semgrep`, then register routes/handlers/sinks with
   `add_coverage_units`. Every high-signal unit must later be dispositioned —
   the recall gate blocks `finish_scan` while any unit with `vulnerability_class`
   is `pending` (low-signal file fallback units are still visible but do not
   block).
3. **Before fanning out, build the shared authorization model** (see `auth_model`):
   write `$TALON_ARTIFACT_DIR/auth_model.md` (the injected absolute artifact dir) with the
   access-control mechanism,
   actors/trust boundaries (with their separating keys), and the sensitive-data map.
   Every unit-review sub-agent reads this instead of re-deriving it, so IDOR/BFLA/
   mass-assignment are judged against one shared expectation.
4. Run first-pass static triage to rank high-risk paths.
5. Run the **sink → source taint pass** (see `source_aware_sast`): enumerate
   sinks, trace each back to a source, check sanitizers in between.
6. Use triage outputs to prioritize dynamic PoC validation.
7. Keep findings evidence-driven: report on a clear, traceable source-to-sink
   flow with a concrete PoC payload; add dynamic validation when the environment
   allows, but do not gate reporting on it.

## Cross-File Review With `trace_symbol`

A sink's safety usually cannot be judged from its own file — whether its inputs
are trusted depends on its **callers**, which often live elsewhere (a handler, a
middleware, another service). Do not review a function in isolation.

When you hit a dangerous sink or an auth-sensitive function:

- `trace_symbol(symbol=<name>, direction=callers)` to find every call site (the
  upstream where untrusted input enters or where an auth check should be).
- `trace_symbol(symbol=<name>, direction=definition)` to jump to where it is
  defined.
- Open the returned `file:line` locations (you have filesystem access) to read
  full bodies and confirm whether tainted data actually reaches the sink.

`trace_symbol` is a fast locator, not a data-flow engine: it finds the chain;
you read the code to confirm the flow.

## Source-Aware Triage Stack

- `semgrep`: fast security-first triage and custom pattern scans
- `ast-grep` (`sg`): structural pattern hunting, syntax-aware parsing, and targeted repo mapping
- `gitleaks`: secret detection across the working tree and git history
- `trivy fs`: dependency, misconfiguration, license, and secret checks

Coverage target per repository:
- one `semgrep` pass
- one AST structural pass (`sg`)
- one secrets pass (`gitleaks`)
- one `trivy fs` pass

## Agent Delegation Guidance

- Keep child agents specialized by vulnerability/component as usual.
- For source-heavy subtasks, prefer creating child agents with `source_aware_sast` skill.
- Use source findings to shape payloads and endpoint selection for dynamic testing.

## Validation Guardrails

- A finding is reportable on strong, traceable source evidence (a clear
  source-to-sink data flow, or a missing/incorrect authorization check). Provide a
  runnable PoC for exploitable bugs; for non-exploitable weaknesses (crypto/config/
  cookie/enumeration) `poc_script_code` may be empty but `poc_description` must
  explain the attack/impact.
- Dynamic testing evidence strengthens a finding and is preferred when a running
  instance is available — but do NOT withhold a well-evidenced source-level
  finding solely because dynamic execution was not possible.
- State confidence explicitly: source-confirmed vs dynamically-confirmed.
- Keep scanner output concise, deduplicated, and mapped to concrete code locations.

## Deep Per-Unit Review (every coverage unit, including class-agnostic ones)

The coverage manifest is seeded to maximise the review denominator: besides
class-tagged units, it registers **class-agnostic** units — `file` (review this
whole file), `handler` (review this request handler), `sink` (review this external
call). A unit with no `vulnerability_class` does NOT mean "no risk" — it means
"you decide what, if anything, is here."

For EVERY unit:
- **Enumerate ALL applicable CWEs, not just the construct's apparent one.** A single
  handler can hold injection AND missing-authz AND mass-assignment AND reflected XSS —
  file each separately. Do not stop at the first/loudest. Do not assume the unit's
  `construct_type` bounds the risk.
- **Trace entrypoint → sink; the flaw usually lives below the handler.** From each
  entrypoint follow the call into managers/services/DAO/libraries down to the real
  sink with `trace_symbol` — the bug is often in a manager or DAO, not the view. Never
  judge a function in isolation. A `file` unit means read the whole file with every
  CWE class in mind.
- **Decide on the code you actually read, never on the presence of a named control.**
  For each control on the path check:
  - *Authorization granularity*: does the check scope to the right principal
    (owner vs tenant vs service), or only prove "some valid user"? Compare siblings —
    where most branches/endpoints scope to the owner and one does not, that one is the
    likely IDOR.
  - *List/read disclosure*: a list or read-all that returns a secret field (hash,
    token, password, key) hands it to every caller allowed to list — an escalation.
  - *Failure mode*: when a control errors/times-out/falls back, does the path fail
    **closed or open**? An auth/ownership/signature check whose error branch logs-and-
    continues or returns a permissive default is bypassable by forcing that error.
    Read the error and fallback branches, not just the success path.
  - *Replay, concurrency, trusted-source*: see `false_positive_traps` for the
    controlling fact on each.
- **Enumerate every harm path and grade by the worst.** The same flow is usually
  several findings — injection of the content, what the sink returns/exposes, cross-
  tenant disclosure, DoS, an unauthenticated trigger. Name each; file each.
- **Record what you examined.** The `mark_unit_reviewed` note must state the CWE
  classes you considered (`cwes_considered`) and the outcome — so a `reviewed` is an
  auditable review, not a rubber stamp. Uncertain → report (see recall-safe below).
- **Record the taint triple.** For any unit with a `vulnerability_class`, the note's
  `evidence` must name the `source`, the `sink`, and the `sanitizer` status on the path
  (see *Recording the Source→Sink Pair* in `source_aware_sast`). This is what makes the
  source↔sink pairing auditable — required for both `reviewed` and `ruled_out`.

## Disposition Efficiency (tier the effort, don't skip the surface)

The denominator is large on purpose. Keep it clearable by matching review depth to
signal — coverage, not uniform cost:
- **High-signal units** (`sink`, `handler`, and any unit with a `vulnerability_class`
  like auth/crypto): full deep review + structured note (`decision/evidence/checked/
  cwes_considered`). This is where the real bugs are.
- **Low-signal `file` fallback units** (whole-file, no construct recognised): skim for
  anything security-relevant; if none, **batch-`ruled_out`** many at once with one
  concise note (`mark_unit_reviewed` takes a list of ids). A construct-less file is
  usually config/partial/helper — read it, but don't manufacture structured evidence
  when there is nothing to review.
- Use `list_coverage` to pull pending units and disposition them in file/kind batches
  rather than one round-trip each.

This tiers cost without shrinking the surface: everything is still reviewed, just at a
depth proportional to its risk signal.

## Recall-Safe Reporting & Deletion

Recall is the priority. Missing a real bug is worse than a false positive that
later triage removes. Follow these rules whenever you decide whether to report or
drop something:

- **Default is keep.** When uncertain whether a candidate weakness is real,
  **file it as a report** (mark confidence low) rather than dropping it. Do not
  resolve uncertainty by leaving high-signal coverage pending — the finish gate
  blocks on pending units with `vulnerability_class`, so an unresolved risk unit
  stalls the scan. Resolve every high-signal unit as either a filed report or a
  justified `ruled_out`; never silently discard.
- **Deletion needs justification (refutation ledger).** To NOT report a candidate,
  or to `mark_unit_reviewed(... status=ruled_out ...)`, you MUST record an explicit
  reason in the disposition note: why it is safe / not reachable / a false positive.
  A `ruled_out` with no substantive justification is not allowed — that note IS the
  audit trail for every dropped finding.
- **Skepticism is for depth, not culling.** Challenge a finding to verify it and to
  surface *more* (subtle cross-file logic), not to prune borderline ones. Doubt
  resolves toward keeping, not dropping.
- **Confidence ≠ report/skip gate.** Low confidence lowers severity/priority, it does
  not justify skipping the report. File it and mark confidence.

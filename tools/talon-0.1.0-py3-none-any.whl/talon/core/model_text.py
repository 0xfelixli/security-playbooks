"""Shared helper for extracting plain text from an SDK ``ModelResponse``."""

from __future__ import annotations

from typing import TYPE_CHECKING

from openai.types.responses import ResponseOutputMessage


if TYPE_CHECKING:
    from agents.items import ModelResponse


def extract_text(response: ModelResponse) -> str:
    parts: list[str] = []
    for item in response.output:
        if not isinstance(item, ResponseOutputMessage):
            continue
        for chunk in item.content:
            text = getattr(chunk, "text", None)
            if text:
                parts.append(text)
    return "".join(parts)

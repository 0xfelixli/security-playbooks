"""SDK run hooks used by Talon orchestration."""

from __future__ import annotations

import logging
import math
from typing import TYPE_CHECKING, Any

from agents.lifecycle import RunHooks

from talon.report.state import get_global_report_state


if TYPE_CHECKING:
    from agents import RunContextWrapper
    from agents.agent import Agent
    from agents.items import ModelResponse


logger = logging.getLogger(__name__)


class BudgetExceededError(RuntimeError):
    """Raised when the accumulated LLM cost reaches the configured budget."""


class ReportUsageHooks(RunHooks[dict[str, Any]]):
    """Persist SDK-native usage after every model response."""

    def __init__(
        self,
        *,
        model: str,
        max_budget_usd: float | None = None,
        context_window_threshold: int = 0,
    ) -> None:
        if max_budget_usd is not None and (
            not math.isfinite(max_budget_usd) or max_budget_usd <= 0
        ):
            raise ValueError("max_budget_usd must be a finite number greater than 0")
        self._model = model
        self._max_budget_usd = max_budget_usd
        # Compaction threshold (tokens); 0 disables. Stashed into the run context after
        # every response so ``turn.start`` can log how close the replayed context is to it.
        self._context_window_threshold = context_window_threshold

    async def on_llm_end(
        self,
        context: RunContextWrapper[dict[str, Any]],
        agent: Agent[dict[str, Any]],
        response: ModelResponse,
    ) -> None:
        report_state = get_global_report_state()
        if report_state is None:
            if self._max_budget_usd is not None:
                # Money safety: silently skipping the check would turn a hard budget into no
                # budget. Callers must set_global_report_state before running with a budget.
                raise RuntimeError(
                    "max_budget_usd is set but no global report state is configured; "
                    "the budget cannot be enforced"
                )
            return

        ctx = context.context if isinstance(context.context, dict) else {}
        agent_name = getattr(agent, "name", None)
        if not isinstance(agent_name, str):
            agent_name = None
        agent_id = ctx.get("agent_id")
        if not isinstance(agent_id, str) or not agent_id:
            agent_id = agent_name or "unknown"

        try:
            report_state.record_sdk_usage(
                agent_id=agent_id,
                agent_name=agent_name,
                model=self._model,
                usage=response.usage,
            )
        except Exception:
            logger.exception("failed to record SDK usage for agent %s", agent_id)

        usage = response.usage
        # ``input_tokens`` IS the replayed context this turn — stash the latest reading
        # (plus the threshold) so the next ``turn.start`` can log the context-size curve
        # and give early warning before the window is exhausted.
        input_tokens = getattr(usage, "input_tokens", None)
        if isinstance(input_tokens, int):
            ctx["last_input_tokens"] = input_tokens
            if self._context_window_threshold > 0:
                ctx["context_window_threshold"] = self._context_window_threshold
        logger.debug(
            "llm.usage agent=%s model=%s in=%s out=%s total=%s",
            agent_id,
            self._model,
            getattr(usage, "input_tokens", "?"),
            getattr(usage, "output_tokens", "?"),
            getattr(usage, "total_tokens", "?"),
        )

        if self._max_budget_usd is not None:
            cost = report_state.get_total_llm_cost()
            logger.debug(
                "llm.budget agent=%s spent=$%.4f / $%.2f",
                agent_id,
                cost,
                self._max_budget_usd,
            )
            if cost >= self._max_budget_usd:
                raise BudgetExceededError(
                    f"Token budget of ${self._max_budget_usd:.2f} exceeded (spent ${cost:.4f})"
                )

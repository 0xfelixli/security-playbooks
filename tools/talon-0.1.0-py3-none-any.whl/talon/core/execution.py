"""Execution loop for addressable SDK-backed Talon agents."""

from __future__ import annotations

import asyncio
import contextlib
import json
import logging
import time
import uuid
from collections.abc import Callable
from dataclasses import dataclass, replace
from typing import TYPE_CHECKING, Any, Literal, cast

import httpx
from agents import RunConfig, Runner
from agents.exceptions import AgentsException, MaxTurnsExceeded, UserError
from agents.model_settings import ModelSettings
from agents.sandbox.errors import ExecTransportError
from openai import APIError

from talon.core.hooks import BudgetExceededError
from talon.core.inputs import (
    NONINTERACTIVE_RECOVERY_LIMIT,
    ROOT_STAGNATION_CHECK_INTERVAL,
    ROOT_STAGNATION_LIMIT,
    SCOPE_STAGNATION_CHECK_INTERVAL,
    SCOPE_STAGNATION_LIMIT,
    child_initial_input,
)
from talon.core.progress import touch_activity
from talon.core.sessions import open_agent_session, strip_all_images_from_session
from talon.logs import set_agent_id


if TYPE_CHECKING:
    from pathlib import Path

    from agents.items import TResponseInputItem
    from agents.lifecycle import RunHooks
    from agents.memory import Session, SQLiteSession
    from agents.result import RunResultBase

    from talon.core.agents import AgentCoordinator, Status


logger = logging.getLogger(__name__)

StreamEventSink = Callable[[str, Any], None]


def _is_root(context: dict[str, Any]) -> bool:
    """Whether this agent is the root (no parent). Single home for the ``parent_id`` key so a
    typo can't silently read a child as root across the ~13 branches on it."""
    return context.get("parent_id") is None


_INPUT_REJECTION_CODES = frozenset({400, 404, 422})

# Context-window exhaustion is non-retryable — the same oversized history fails identically
# forever, so these must never fall into the generic crash/retry paths. Matched
# case-insensitively against the provider message; first two are OpenAI Responses phrasing,
# then Chat Completions, then Anthropic/Bedrock.
_CONTEXT_WINDOW_ERROR_MARKERS = (
    "exceeds the context window",
    "context window of this model",
    "maximum context length",
    "context length exceeded",
    "prompt is too long",
    "input is too long",
)

# Interactive-mode idle cap for the involuntary loop-level park (an agent that ended a turn
# without a lifecycle tool). Matches the voluntary wait_for_message tool's cap
# (talon.tools.agents_graph.tools._WAIT_TIMEOUT_CAP = 600) so both parks share one ceiling;
# a local constant avoids a core->tools import. Restores upstream's resume-on-timeout.
_INTERACTIVE_IDLE_TIMEOUT_SECS = 600.0
# The parked root has no human-facing idle cap (it must survive an unattended pause), so it
# wakes on this cadence purely to check graph liveness. A wake only triggers recovery when the
# graph is quiesced AND blocking coverage work remains — a root legitimately waiting on a human
# (nothing owed) reparks untouched. A distinct constant from the subagent cap so tests can drive
# one path without shortening the other.
_ROOT_LIVENESS_POLL_SECS = 120.0
# Consecutive quiesced re-drives that yield no forward progress before the root stops cleanly
# (resumable) instead of spinning expensive no-op turns on a graph nothing will ever unblock.
_ROOT_QUIESCED_RECOVERY_LIMIT = 3
# A malformed streaming chunk (empty / truncated / non-JSON SSE ``data:`` line) surfaces as
# json.JSONDecodeError deep in the OpenAI SDK decoder. It is none of the SDK retry policy's
# classes, so without this it propagates uncaught and crashes the agent, discarding its work.
# Retry the whole turn with backoff; it replays cleanly from the session (the failed turn's
# assistant message was never committed), mirroring the image-strip retry below.
_STREAM_DECODE_RETRY_MAX = 3
_STREAM_DECODE_RETRY_BASE_SECS = 1.0
# The SDK already retries provider-suggested, network/timeout, and 429/5xx failures before an
# APIError reaches this loop. A bare Responses streaming APIError can still leak through —
# e.g. the provider closes the SSE stream with "you can retry your request" but no HTTP
# status code. Give those one more turn-level retry so a transient fault does not kill a
# long-lived child.
_STREAM_API_RETRY_MAX = 5
_STREAM_API_RETRY_BASE_SECS = 2.0
_RETRYABLE_API_ERROR_MARKERS = (
    "you can retry your request",
    "try again later",
    "temporarily unavailable",
    "internal server error",
    "server error",
    "timeout",
)
_RETRYABLE_API_STATUS_CODES = frozenset({408, 409, 425, 429, 500, 502, 503, 504})
_RETRYABLE_STREAM_TRANSPORT_ERRORS: tuple[type[Exception], ...] = (
    httpx.RemoteProtocolError,  # mid-stream disconnects leak raw from the SDK stream iterator
    httpx.ReadError,
    httpx.ReadTimeout,
)
_TERMINAL_STATUSES: frozenset[str] = frozenset({"completed", "crashed", "stopped", "failed"})
# Non-graceful terminal states whose parent must be woken so it stops waiting on a child that
# will never reply (see _notify_parent_on_crash). "completed" is graceful and reports through
# its own completion message, so it is excluded.
_TERMINATION_NOTIFY_STATUSES: frozenset[str] = frozenset({"crashed", "stopped", "failed"})


async def run_agent_loop(
    *,
    agent: Any,
    initial_input: Any,
    run_config: RunConfig,
    context: dict[str, Any],
    max_turns: int,
    coordinator: AgentCoordinator,
    agent_id: str,
    interactive: bool,
    session: Session | None = None,
    start_parked: bool = False,
    event_sink: StreamEventSink | None = None,
    hooks: RunHooks[dict[str, Any]] | None = None,
) -> RunResultBase | None:
    # Tag every log record from this agent's task (incl. openai-agents SDK lines) with
    # "<id>:<name>". ContextVar scoping labels each child's task (and its descendants)
    # independently; without it the agent column stayed "-". Root and children both enter here.
    view = await coordinator.describe(agent_id)
    set_agent_id(agent_id, view.name if view else agent_id)
    await coordinator.attach_runtime(
        agent_id,
        session=session,
        interrupt_on_message=interactive,
    )
    result: RunResultBase | None = None
    _turn: list[int] = [0]

    if not (start_parked and interactive):
        if interactive:
            result = await _run_cycle(
                agent,
                coordinator,
                agent_id,
                input_data=initial_input,
                run_config=run_config,
                context=context,
                max_turns=max_turns,
                session=session,
                interactive=interactive,
                event_sink=event_sink,
                hooks=hooks,
                _turn=_turn,
            )
        else:
            result = await _run_noninteractive_until_lifecycle(
                agent,
                coordinator,
                agent_id,
                initial_input=initial_input,
                run_config=run_config,
                context=context,
                max_turns=max_turns,
                session=session,
                event_sink=event_sink,
                hooks=hooks,
                _turn=_turn,
            )

    if not interactive:
        return result

    return await _run_interactive_park_loop(
        agent,
        coordinator,
        agent_id,
        result=result,
        run_config=run_config,
        context=context,
        max_turns=max_turns,
        session=session,
        event_sink=event_sink,
        hooks=hooks,
        _turn=_turn,
    )


async def _run_interactive_park_loop(
    agent: Any,
    coordinator: AgentCoordinator,
    agent_id: str,
    *,
    result: RunResultBase | None,
    run_config: RunConfig,
    context: dict[str, Any],
    max_turns: int,
    session: Session | None,
    event_sink: StreamEventSink | None,
    hooks: RunHooks[dict[str, Any]] | None,
    _turn: list[int],
) -> RunResultBase | None:
    """Park an interactive agent between turns, re-driving it when work arrives.

    Neither the root nor a subagent may sleep forever. A subagent's unbounded wait deadlocks
    ``finish_scan`` (which refuses while any child is running/waiting); it parks on the same
    600s cap ``wait_for_message`` uses and, on idle timeout, is driven back toward
    ``agent_finish``. The root has no human-facing idle cap — it must survive an unattended
    pause — but it polls on ``_ROOT_LIVENESS_POLL_SECS`` so a *quiesced graph with blocking
    work still pending* (every subagent settled, yet finish_scan refused — nobody left to wake
    the root) is broken instead of frozen. A root merely waiting on a human, with nothing owed,
    reparks untouched: it still never self-terminates on human latency alone.
    """
    is_subagent = not _is_root(context)
    idle_recoveries = 0
    while True:
        if is_subagent and await _agent_status(coordinator, agent_id) in _TERMINAL_STATUSES:
            return result

        park_timeout = _INTERACTIVE_IDLE_TIMEOUT_SECS if is_subagent else _ROOT_LIVENESS_POLL_SECS
        logger.debug(
            "park: %s subagent=%s timeout=%s",
            agent_id,
            is_subagent,
            park_timeout,
        )
        try:
            got_message = await coordinator.wait_for_message(agent_id, timeout=park_timeout)
        except asyncio.CancelledError:
            logger.debug("park: %s cancelled while parked", agent_id)
            return result

        if coordinator.budget_stopped:
            await coordinator.set_status(agent_id, "stopped", reason="budget reached")
            raise BudgetExceededError("scan budget reached")

        if got_message:
            idle_recoveries = 0
            logger.debug("resume: %s woken by pending message", agent_id)
            await coordinator.consume_pending(agent_id)
            input_data: Any = []
        else:
            if is_subagent:
                action, idle_recoveries, input_data = await _recover_idle_subagent(
                    coordinator, agent_id, context, session, idle_recoveries
                )
            else:
                action, idle_recoveries, input_data = await _recover_idle_root(
                    coordinator, agent_id, session, idle_recoveries
                )
            if action == "repark":
                continue
            if action == "finalize":
                return result
            if action == "crash":
                return None

        result = await _run_cycle(
            agent,
            coordinator,
            agent_id,
            input_data=input_data,
            run_config=run_config,
            context=context,
            max_turns=max_turns,
            session=session,
            interactive=True,
            event_sink=event_sink,
            hooks=hooks,
            _turn=_turn,
        )


def _child_run_config(run_config: RunConfig) -> RunConfig:
    """Return ``run_config`` with ``tool_choice="required"`` forced, for subagents.

    Without it a terse model can loop park→nudge→park (the idle-nudge reruns *without* forcing
    a tool) and never reach ``agent_finish``, deadlocking the root's finish gate. Pinning
    ``tool_choice`` to ``required`` — persisted because children build with
    ``reset_tool_choice=False`` — makes every child turn call a tool. The root keeps its own
    run_config (interactive root may reply in plain text to wait on the user). No-op when
    already required (non-interactive backend).
    """
    base = run_config.model_settings
    forced = (
        base.resolve(ModelSettings(tool_choice="required"))
        if base is not None
        else ModelSettings(tool_choice="required")
    )
    return replace(run_config, model_settings=forced)


def _brief(value: Any, limit: int = 160) -> str:
    """Collapse a tool arg/result to one truncated line for logging."""
    text = value if isinstance(value, str) else str(value)
    text = " ".join(text.split())
    return text if len(text) <= limit else f"{text[: limit - 1]}…"


def _message_text(item: Any) -> str:
    """Best-effort extract the assistant's plain-text output from a message item.

    The SDK item shape varies by backend; read defensively so a logging helper never
    raises. Returns "" when no text can be recovered.
    """
    raw = getattr(item, "raw_item", None)
    content = getattr(raw, "content", None)
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts = [getattr(part, "text", None) for part in content]
        return " ".join(p for p in parts if isinstance(p, str) and p)
    return ""


def _reasoning_text(item: Any) -> str:
    """Best-effort extract a reasoning item's summary text (empty when unavailable)."""
    raw = getattr(item, "raw_item", None)
    summary = getattr(raw, "summary", None)
    if isinstance(summary, list):
        parts = [getattr(part, "text", None) for part in summary]
        text = " ".join(p for p in parts if isinstance(p, str) and p)
        if text:
            return text
    content = getattr(raw, "content", None)
    return content if isinstance(content, str) else ""


def _log_stream_event(event: Any, _state: dict[str, Any]) -> None:
    """Log one compact action line per agent turn — the piece the SDK's DEBUG spans omit.

    The agent label is already on every line (``set_agent_id``), so this records only the
    ACTION (tool called + brief args, tool result, or a plain-text turn). Surfacing the
    plain-text turn matters — that is what parks a subagent as ``waiting``, so a stall is
    visible instead of silent. The action line stays at INFO (skeleton visible without
    ``--debug``); the turn's *content* (text, reasoning, other item types) logs at DEBUG so a
    stall's root cause is recoverable without drowning the default log.
    """
    touch_activity()  # any stream item is a sign of life for the live-panel heartbeat
    item = getattr(event, "item", None)
    item_type = getattr(item, "type", None)
    if item_type == "tool_call_item":
        raw = getattr(item, "raw_item", None)
        tool = getattr(raw, "name", None) or getattr(raw, "type", None) or "tool"
        # Keyed by call_id: one turn can carry several parallel tool calls, and their
        # output items arrive after ALL the call items — a single timestamp slot would
        # be overwritten and every dt would pair with the wrong call.
        pending: dict[Any, tuple[str, float]] = _state.setdefault("pending_tools", {})
        call_id = getattr(raw, "call_id", None) or f"?{len(pending)}"
        pending[call_id] = (str(tool), time.monotonic())
        logger.info("tool.call %s(%s)", tool, _brief(getattr(raw, "arguments", "") or ""))
    elif item_type == "tool_call_output_item":
        raw = getattr(item, "raw_item", None)
        call_id = raw.get("call_id") if isinstance(raw, dict) else getattr(raw, "call_id", None)
        pending = _state.setdefault("pending_tools", {})
        entry = pending.pop(call_id, None)
        if entry is None and pending:
            # Output item carried no call_id — fall back to FIFO pairing.
            entry = pending.pop(next(iter(pending)))
        name = f" {entry[0]}" if entry else ""
        dt = f" dt={time.monotonic() - entry[1]:.2f}s" if entry else ""
        logger.info("tool.done%s%s output=%s", name, dt, _brief(getattr(item, "output", "")))
    elif item_type == "message_output_item":
        # Action at INFO, the model's actual text at DEBUG so the stall reason is recoverable.
        logger.info("turn.text (plain-text turn, no tool call — parks subagent as waiting)")
        text = _message_text(item)
        if text:
            logger.debug("turn.text content: %s", _brief(text, limit=400))
    elif item_type == "reasoning_item":
        text = _reasoning_text(item)
        logger.debug("turn.reasoning: %s", _brief(text, limit=400) if text else "(no summary)")
    elif item_type is not None:
        logger.debug("turn.item type=%s", item_type)


def _context_note(context: dict[str, Any]) -> str:
    """Render the ``ctx≈<tokens>/<threshold>(<pct>%)`` suffix for ``turn.start``.

    Reads the latest input-token count the usage hook stashed after the previous turn
    (``input_tokens`` = the replayed context). Empty on the first turn, before any
    response has been measured.
    """
    tokens = context.get("last_input_tokens")
    if not isinstance(tokens, int):
        return ""
    threshold = context.get("context_window_threshold")
    if isinstance(threshold, int) and threshold > 0:
        return f" ctx≈{tokens}/{threshold}({tokens * 100 // threshold}%)"
    return f" ctx≈{tokens}"


def _log_turn_end(turn: int, started: float) -> None:
    """Close the turn skeleton with its wall-clock duration.

    Pairs with ``turn.start``; the ``dt`` isolates model-generation time from the
    per-tool ``dt`` already logged by ``tool.done``, so a slow turn is attributable.
    """
    logger.info("turn.end turn=%d dt=%.2fs", turn, time.monotonic() - started)


@dataclass(slots=True)
class ChildSpawner:
    """Owns the plumbing that is identical across every child spawned within one scan.

    Built once per scan (see ``core/runner.py``); callers — the ``create_agent`` tool via
    ``spawn_new``, resume via ``respawn`` — only supply what actually varies per child.
    Replaces the old free-function ``spawn_child_agent``/``respawn_subagents`` pair, which
    took 15-18 parameters each even though ~8 of them never changed within a scan.
    """

    coordinator: AgentCoordinator
    factory: Any
    agents_db_path: Path
    sessions_to_close: list[SQLiteSession]
    run_config: RunConfig
    max_turns: int
    interactive: bool
    event_sink: StreamEventSink | None = None
    hooks: RunHooks[dict[str, Any]] | None = None

    async def spawn_new(
        self,
        *,
        parent_ctx: dict[str, Any],
        name: str,
        task: str,
        skills: list[str],
        parent_history: list[Any],
        coverage_scope: list[str] | None = None,
    ) -> dict[str, Any]:
        parent_id = parent_ctx.get("agent_id")
        if not isinstance(parent_id, str):
            raise TypeError("Parent agent_id missing from context")

        child_id = uuid.uuid4().hex[:8]
        child_agent = self.factory(name=name, skills=skills)
        await self.coordinator.register(
            child_id,
            name,
            parent_id,
            task=task,
            skills=skills,
            coverage_scope=coverage_scope,
        )

        await self._start_runner(
            parent_ctx=parent_ctx,
            child_agent=child_agent,
            child_id=child_id,
            name=name,
            parent_id=parent_id,
            task=task,
            initial_input=child_initial_input(
                name=name,
                child_id=child_id,
                parent_id=parent_id,
                task=task,
                parent_history=parent_history,
            ),
        )

        return {
            "success": True,
            "agent_id": child_id,
            "name": name,
            "parent_id": parent_id,
            "message": f"Spawned '{name}' ({child_id}) running in parallel.",
        }

    async def respawn(self, *, parent_ctx: dict[str, Any], root_id: str) -> None:
        """Restart every non-root descendant restored from a resume snapshot."""
        candidates = [
            (
                view.agent_id,
                view.name,
                view.parent_id,
                {**view.metadata, "_restored_status": view.status},
            )
            for view in await self.coordinator.snapshot_agents()
            if (self.interactive or view.status in {"running", "waiting"})
            and view.parent_id is not None
            and view.agent_id != root_id
        ]

        for child_id, name, parent_id, md in candidates:
            try:
                restored_status = str(md.get("_restored_status") or "running")
                start_parked = self.interactive and restored_status != "running"

                if start_parked:
                    logger.warning(
                        "respawn %s (%s): starting parked from status=%s",
                        child_id,
                        name,
                        restored_status,
                    )

                child_skills = list(md.get("skills") or [])
                child_agent = self.factory(name=name, skills=child_skills)
                await self._start_runner(
                    parent_ctx=parent_ctx,
                    child_agent=child_agent,
                    child_id=child_id,
                    name=name,
                    parent_id=parent_id,
                    task=str(md.get("task", "")),
                    initial_input=[],
                    start_parked=start_parked,
                )
                logger.info(
                    "respawned %s name=%s parent=%s task_len=%d",
                    child_id,
                    name,
                    parent_id or "-",
                    len(md.get("task", "")),
                )
            except Exception:
                logger.exception("respawn %s failed; marking crashed", child_id)
                with contextlib.suppress(Exception):
                    await self.coordinator.set_status(child_id, "crashed")

    async def _start_runner(
        self,
        *,
        parent_ctx: dict[str, Any],
        child_agent: Any,
        child_id: str,
        name: str,
        parent_id: str | None,
        task: str,
        initial_input: Any,
        start_parked: bool = False,
    ) -> None:
        session = open_agent_session(child_id, self.agents_db_path)
        self.sessions_to_close.append(session)
        await self.coordinator.attach_runtime(child_id, session=session)

        child_ctx: dict[str, Any] = dict(parent_ctx)
        child_ctx["agent_id"] = child_id
        child_ctx["parent_id"] = parent_id
        child_ctx["task"] = task

        coordinator = self.coordinator
        run_config = _child_run_config(self.run_config)
        max_turns = self.max_turns
        interactive = self.interactive
        event_sink = self.event_sink
        hooks = self.hooks

        async def _child_loop() -> None:
            # A budget stop is a clean scan-wide shutdown, not a child failure: status and
            # parent notification are already settled in ``_run_cycle``. Swallow it here so
            # the detached task does not surface a spurious "Task exception was never
            # retrieved" warning. The root hits the same limit on its next call and tears the
            # scan down.
            try:
                await run_agent_loop(
                    agent=child_agent,
                    initial_input=initial_input,
                    run_config=run_config,
                    context=child_ctx,
                    max_turns=max_turns,
                    coordinator=coordinator,
                    agent_id=child_id,
                    interactive=interactive,
                    session=session,
                    start_parked=start_parked,
                    event_sink=event_sink,
                    hooks=hooks,
                )
            except BudgetExceededError:
                logger.info("child %s stopped after reaching the scan budget limit", child_id)
            except Exception as exc:
                # request_stop (stop_agent, or _note_scope_tool_call's scope-stagnation check)
                # cancels the in-flight stream and waits for the current turn to finish before
                # honoring it. If a transient error fires during that grace window, the status
                # is already "stopped" — this is a benign race, not a crash, so finalize it as
                # a graceful stop instead of overwriting to "crashed".
                if await _agent_status(coordinator, child_id) == "stopped":
                    logger.warning(
                        "child %s was already stopping when %s interrupted it; finalizing as "
                        "stopped, not crashed",
                        child_id,
                        type(exc).__name__,
                    )
                    with contextlib.suppress(Exception):
                        await _finalize_interrupted_stop(coordinator, child_id, child_ctx, exc)
                    return
                # Non-interactive runs re-raise from _run_cycle without settling status; if it
                # dies here still "running", finish_scan's active-agent gate deadlocks and the
                # parent waits forever. Settle to "crashed" and notify, as interactive does.
                logger.exception("child %s crashed", child_id)
                with contextlib.suppress(Exception):
                    await coordinator.set_status(child_id, "crashed")
                    await _notify_parent_on_crash(coordinator, child_id, "crashed")

        task_handle = asyncio.create_task(_child_loop(), name=f"agent-{name}-{child_id}")
        await coordinator.attach_runtime(child_id, task=task_handle)


def child_spawner_from_context(ctx: dict[str, Any]) -> ChildSpawner | None:
    spawner = ctx.get("child_spawner")
    return spawner if isinstance(spawner, ChildSpawner) else None


async def _run_noninteractive_until_lifecycle(
    agent: Any,
    coordinator: AgentCoordinator,
    agent_id: str,
    *,
    initial_input: Any,
    run_config: RunConfig,
    context: dict[str, Any],
    max_turns: int,
    session: Session | None,
    event_sink: StreamEventSink | None,
    hooks: RunHooks[dict[str, Any]] | None,
    _turn: list[int],
) -> RunResultBase | None:
    """Non-chat mode keeps running until finish_scan / agent_finish settles status."""
    result: RunResultBase | None = None
    input_data: Any = initial_input
    invalid_final_outputs = 0
    invalid_final_output_limit = NONINTERACTIVE_RECOVERY_LIMIT

    while True:
        if coordinator.budget_stopped:
            await coordinator.set_status(agent_id, "stopped", reason="budget reached")
            raise BudgetExceededError("scan budget reached")

        result = await _run_cycle(
            agent,
            coordinator,
            agent_id,
            input_data=input_data,
            run_config=run_config,
            context=context,
            max_turns=max_turns,
            session=session,
            interactive=False,
            event_sink=event_sink,
            hooks=hooks,
            _turn=_turn,
        )

        status = await _agent_status(coordinator, agent_id)
        if status != "running":
            return result

        # An agent that ended a turn without a lifecycle tool but still has live descendants
        # is coordinating, not stalled — children wake it when they report (completion or
        # crash both notify). Park on their messages instead of counting empty turns toward
        # force-finalize; otherwise the root force-finalizes over still-running children,
        # orphaning them and writing a fallback summary over a half-reviewed scan. Mirrors the
        # interactive idle-recovery guard (_recover_idle_subagent).
        if await coordinator.has_active_descendants(agent_id):
            logger.debug(
                "coordinating: %s ended a turn without a lifecycle tool but has live "
                "descendants; parking on their messages (not counting toward force-finalize)",
                agent_id,
            )
            got_message = await coordinator.wait_for_message(
                agent_id, timeout=_INTERACTIVE_IDLE_TIMEOUT_SECS
            )
            logger.debug(
                "coordinating: %s park %s",
                agent_id,
                "woken by child message" if got_message else "idle-timed-out, re-driving",
            )
            if got_message:
                await coordinator.consume_pending(agent_id)
            input_data = []
            continue

        invalid_final_outputs += 1
        logger.warning(
            "agent %s produced non-lifecycle final output in non-interactive mode; "
            "forcing tool continuation (%d/%d): %s",
            agent_id,
            invalid_final_outputs,
            invalid_final_output_limit,
            _final_output_preview(result),
        )

        if invalid_final_outputs >= invalid_final_output_limit:
            if _is_root(context):
                # Root has no parent to crash-notify and no scope to hand off — this is a
                # stall, not a failure. Settle "stopped" directly instead of raising, so
                # run_agent_loop returns cleanly (mirrors the BudgetExceededError/
                # RateLimitError precedent in runner.py). "crashed" stays reserved for
                # genuine child failures below.
                await coordinator.set_status(
                    agent_id, "stopped", reason="recovery attempts exhausted"
                )
                return result
            if await _finalize_or_crash_stalled_child(coordinator, agent_id, context) == "finalize":
                return result
            raise MaxTurnsExceeded(
                "Agent exhausted non-interactive recovery attempts without calling "
                "finish_scan or agent_finish."
            )

        input_data = await _append_noninteractive_tool_required_message(
            session=session,
            context=context,
            attempt=invalid_final_outputs,
            limit=invalid_final_output_limit,
        )


async def _note_scope_tool_call(
    coordinator: AgentCoordinator, agent_id: str, state: dict[str, Any], *, is_root: bool
) -> None:
    """Track objective coverage progress for a bound subagent (or the root, scan-wide);
    request a graceful stop once its scope is complete or has stalled.

    Called on every ``tool_call_output_item`` in ``_run_cycle``'s stream-event loop —
    ``tool_choice="required"`` means a busy-but-non-converging subagent never goes idle
    (so ``_recover_idle_subagent`` never fires for it), and one ``Runner.run_streamed`` call
    can run the agent's entire ReAct session internally, so this is the only point that sees
    tool calls as they happen. No-op for a subagent with no ``coverage_scope`` bound
    (``state["scope"]`` empty and ``is_root`` false) or once a trigger already fired this
    cycle (checked once, acted on once). Root has no bound scope but is never a no-op: its
    progress signal is the manifest's total pending count (see ``pending_count_total``)
    rather than a scope-prefixed count, and it uses looser, root-specific thresholds
    (``ROOT_STAGNATION_CHECK_INTERVAL``/``LIMIT`` vs. ``SCOPE_STAGNATION_*``) since its own
    tool calls are mostly coordination rather than directly dispositioning units.
    """
    scope = state["scope"]
    if (not scope and not is_root) or state["trigger"] is not None:
        return
    state["tool_calls"] += 1
    interval = ROOT_STAGNATION_CHECK_INTERVAL if is_root else SCOPE_STAGNATION_CHECK_INTERVAL
    limit = ROOT_STAGNATION_LIMIT if is_root else SCOPE_STAGNATION_LIMIT
    if state["tool_calls"] % interval != 0:
        return
    if await coordinator.has_active_descendants(agent_id):
        return  # coordinating live children (e.g. a reporting child) — not stalled

    from talon.tools.coverage.tools import (  # noqa: PLC0415 — deferred: avoids core↔tools import cycle
        pending_count_for_scope,
        pending_count_total,
    )

    pending_now = pending_count_total() if is_root else pending_count_for_scope(scope)
    last_pending = state["last_pending"]
    trigger: str | None = None
    if pending_now <= 0:
        trigger = "scope_complete"
    elif last_pending is not None and pending_now >= last_pending:
        state["stagnant_checks"] += 1
        if state["stagnant_checks"] >= limit:
            trigger = "scope_stagnant"
    else:
        state["stagnant_checks"] = 0
    state["last_pending"] = pending_now
    if trigger is None:
        return
    state["trigger"] = trigger
    state["pending_at_trigger"] = pending_now
    logger.warning(
        "agent %s coverage %s (pending=%d, scope=%s, root=%s); requesting graceful stop",
        agent_id,
        trigger,
        pending_now,
        scope,
        is_root,
    )
    await coordinator.request_stop(agent_id)


async def _run_cycle(  # noqa: PLR0912, PLR0915
    agent: Any,
    coordinator: AgentCoordinator,
    agent_id: str,
    *,
    input_data: Any,
    run_config: RunConfig,
    context: dict[str, Any],
    max_turns: int,
    session: Session | None,
    interactive: bool,
    event_sink: StreamEventSink | None,
    hooks: RunHooks[dict[str, Any]] | None,
    _turn: list[int],
) -> RunResultBase | None:
    _turn[0] += 1
    logger.info("turn.start turn=%d%s", _turn[0], _context_note(context))
    turn_started = time.monotonic()
    image_strips = 0
    stream_decode_retries = 0
    stream_api_retries = 0
    # Persists across retry attempts within this one _run_cycle call (one call can run an
    # agent's entire ReAct session — see _note_scope_tool_call). Empty scope is a permanent
    # no-op for root and any subagent create_agent wasn't given a coverage_scope for.
    scope_state: dict[str, Any] = {
        "scope": (await coordinator.coverage_scope_of(agent_id) if not _is_root(context) else []),
        "tool_calls": 0,
        "last_pending": None,
        "stagnant_checks": 0,
        "trigger": None,
        "pending_at_trigger": 0,
    }
    while True:
        turn_state: dict[str, Any] = {}
        tool_call_seen = False
        attempt_started = time.monotonic()
        try:
            await coordinator.mark_running(agent_id)
            stream = Runner.run_streamed(
                agent,
                input=input_data,
                run_config=run_config,
                context=context,
                max_turns=max_turns,
                session=session,
                hooks=hooks,
            )
            await coordinator.attach_stream(agent_id, stream)
            try:
                try:
                    async for event in stream.stream_events():
                        if getattr(event, "type", None) == "run_item_stream_event":
                            item = getattr(event, "item", None)
                            item_type = getattr(item, "type", None)
                            if item_type == "tool_call_item":
                                tool_call_seen = True
                            elif item_type == "tool_call_output_item":
                                await _note_scope_tool_call(
                                    coordinator,
                                    agent_id,
                                    scope_state,
                                    is_root=_is_root(context),
                                )
                            _log_stream_event(event, turn_state)
                        if event_sink is not None:
                            try:
                                event_sink(agent_id, event)
                            except Exception:
                                logger.exception("stream event sink failed for %s", agent_id)
                    if stream.run_loop_exception is not None:
                        raise stream.run_loop_exception
                except BudgetExceededError:
                    # A RuntimeError subclass: re-raise explicitly so it is never
                    # mistaken for the LiteLLM "after shutdown" race below.
                    raise
                except RuntimeError as stream_exc:
                    if "after shutdown" not in str(stream_exc):
                        raise
                    logger.warning(
                        "Ignoring LiteLLM end-of-stream shutdown race for %s",
                        agent_id,
                    )
                except ExecTransportError:
                    if not coordinator.is_shutting_down:
                        raise
                    logger.warning(
                        "Ignoring sandbox transport error during teardown for %s",
                        agent_id,
                        exc_info=True,
                    )
            finally:
                await coordinator.detach_stream(agent_id, stream)
        except BudgetExceededError as exc:
            logger.info(
                "agent %s reached the scan budget limit; stopping the scan: %s", agent_id, exc
            )
            await coordinator.set_status(agent_id, "stopped", reason="budget reached")
            await coordinator.trigger_budget_stop()
            raise
        except Exception as exc:
            if (
                image_strips < 3
                and session is not None
                and getattr(exc, "status_code", None) in _INPUT_REJECTION_CODES
            ):
                try:
                    stripped = await strip_all_images_from_session(session)
                except Exception:
                    logger.exception("image-strip recovery failed for %s", agent_id)
                    stripped = False
                if stripped:
                    image_strips += 1
                    logger.info(
                        "Stripped images from %s session after rejection; retrying (%d)",
                        agent_id,
                        image_strips,
                    )
                    input_data = []
                    continue
            if isinstance(exc, json.JSONDecodeError):
                attempt_dt = time.monotonic() - attempt_started
                tokens = context.get("last_input_tokens")
                tokens_note = f" input_tokens≈{tokens}" if isinstance(tokens, int) else ""
                if stream_decode_retries < _STREAM_DECODE_RETRY_MAX:
                    stream_decode_retries += 1
                    delay = _STREAM_DECODE_RETRY_BASE_SECS * (2 ** (stream_decode_retries - 1))
                    logger.warning(
                        "agent %s hit a malformed streaming chunk after %.2fs%s (%s); "
                        "retrying turn %d/%d after %.1fs",
                        agent_id,
                        attempt_dt,
                        tokens_note,
                        exc,
                        stream_decode_retries,
                        _STREAM_DECODE_RETRY_MAX,
                        delay,
                    )
                    await asyncio.sleep(delay)
                    input_data = []
                    continue
                logger.warning(
                    "agent %s exhausted malformed-stream-chunk retries after %.2fs%s; "
                    "giving up after %d/%d attempts, turn elapsed=%.2fs",
                    agent_id,
                    attempt_dt,
                    tokens_note,
                    stream_decode_retries,
                    _STREAM_DECODE_RETRY_MAX,
                    time.monotonic() - turn_started,
                )
            if (
                not tool_call_seen
                and _is_retryable_stream_api_error(exc)
                and stream_api_retries < _STREAM_API_RETRY_MAX
            ):
                stream_api_retries += 1
                delay = _STREAM_API_RETRY_BASE_SECS * (2 ** (stream_api_retries - 1))
                logger.warning(
                    "agent %s hit a retryable streaming API error (%s); retrying turn "
                    "%d/%d after %.1fs",
                    agent_id,
                    _exception_preview(exc),
                    stream_api_retries,
                    _STREAM_API_RETRY_MAX,
                    delay,
                )
                await asyncio.sleep(delay)
                input_data = []
                continue
            if _is_context_window_error(exc) and not _is_root(context):
                # Non-retryable: the oversized history replays identically every attempt.
                # Settle the child cleanly (reports/dispositions persist, parent told to
                # re-slice) instead of crashing — a crash strands its remaining scope and,
                # non-interactively, can leave finish_scan waiting on a child that never replies.
                finalized = False
                try:
                    finalized = await _finalize_context_exhausted_child(
                        coordinator, agent_id, context
                    )
                except Exception:
                    logger.exception("context-exhausted finalize failed for %s", agent_id)
                if finalized:
                    logger.warning(
                        "agent %s hit the model context window; finalized gracefully",
                        agent_id,
                    )
                    _log_turn_end(_turn[0], turn_started)
                    return None
            if isinstance(exc, MaxTurnsExceeded) and _is_root(context):
                # Root hitting its turn ceiling is a stall, not a crash — settle gracefully
                # (mirrors the BudgetExceededError/RateLimitError stop paths in runner.py)
                # instead of tearing down the whole scan. Applies in both interactive and
                # non-interactive mode, so this must run before the "if not interactive:
                # raise" below.
                logger.warning(
                    "root %s hit its turn limit; stopping gracefully instead of crashing (%s)",
                    agent_id,
                    exc,
                )
                await coordinator.set_status(agent_id, "stopped", reason="max turns exceeded")
                _log_turn_end(_turn[0], turn_started)
                return None
            if not interactive:
                raise
            if isinstance(exc, MaxTurnsExceeded):
                status: Status = "stopped"
            elif isinstance(exc, UserError | AgentsException | APIError):
                status = "failed"
            else:
                status = "crashed"
            logger.exception("agent run failed for %s; parking as %s", agent_id, status)
            await coordinator.set_status(
                agent_id, status, reason=f"run failed ({type(exc).__name__})"
            )
            await _notify_parent_on_crash(coordinator, agent_id, status)
            if _is_root(context) and status in {"failed", "crashed"}:
                raise
            _log_turn_end(_turn[0], turn_started)
            return None
        else:
            await _settle_run_result(coordinator, agent_id, interactive)
            if scope_state["trigger"] is not None:
                try:
                    if _is_root(context):
                        _finalize_root_stagnation(
                            agent_id,
                            trigger=scope_state["trigger"],
                            pending=scope_state["pending_at_trigger"],
                        )
                    else:
                        await _finalize_scope_stalled_child(
                            coordinator,
                            agent_id,
                            context,
                            trigger=scope_state["trigger"],
                            pending=scope_state["pending_at_trigger"],
                            scope=scope_state["scope"],
                        )
                except Exception:
                    logger.exception("scope-stalled finalize failed for %s", agent_id)
            _log_turn_end(_turn[0], turn_started)
            return stream


async def _settle_run_result(
    coordinator: AgentCoordinator,
    agent_id: str,
    interactive: bool,
) -> None:
    view = await coordinator.describe(agent_id)
    current_status = view.status if view else None

    if current_status != "running":
        logger.debug(
            "settle: %s already %s (lifecycle tool fired this turn); not parking",
            agent_id,
            current_status,
        )
        return

    if not interactive:
        return

    logger.debug(
        "settle: %s ended an interactive turn without a lifecycle tool; parking as waiting",
        agent_id,
    )
    await coordinator.set_status(agent_id, "waiting", reason="text-only turn parked")


async def _agent_status(coordinator: AgentCoordinator, agent_id: str) -> Status | None:
    view = await coordinator.describe(agent_id)
    return view.status if view else None


def _final_output_preview(result: RunResultBase | None) -> str:
    final_output = getattr(result, "final_output", None)
    if final_output is None:
        return "<none>"
    text = str(final_output).replace("\n", " ").strip()
    if not text:
        return "<empty>"
    return text[:300]


def _pending_high_signal_units() -> int:
    """Count undispositioned high-signal coverage units, or -1 if unavailable.

    Read defensively: the coverage store is a module-level singleton and may be
    absent (non-whitebox scans, import failure). Never let a diagnostic hint break
    the recovery path.
    """
    try:
        from talon.tools.coverage.tools import (  # noqa: PLC0415 — deferred: avoids core↔tools import cycle
            pending_units,
        )

        return sum(1 for u in pending_units() if str(u.get("vulnerability_class") or "").strip())
    except Exception:  # noqa: BLE001 — a diagnostic hint must never break recovery
        logger.debug("could not read pending coverage units for recovery hint", exc_info=True)
        return -1


def _coverage_gate_hint() -> str:
    """Tell a stalled root exactly why finish_scan is blocked and how to escape.

    A generic "call finish_scan" nag is useless when finish_scan is what the
    coverage gate is rejecting — the model needs the concrete unblock action.
    """
    pending = _pending_high_signal_units()
    if pending <= 0:
        return ""
    return (
        f"NOTE: finish_scan is currently blocked by the coverage gate — {pending} high-signal "
        "attack-surface unit(s) are still undispositioned. To finish you MUST first disposition "
        "them: call mark_unit_reviewed (reviewed or ruled_out) — you can bulk-pass many unit_ids "
        "in one call — using list_coverage to enumerate them. Only then will finish_scan succeed. "
    )


async def _append_noninteractive_tool_required_message(
    *,
    session: Session | None,
    context: dict[str, Any],
    attempt: int,
    limit: int,
) -> list[dict[str, str]]:
    is_root = _is_root(context)
    finish_tool = "finish_scan" if is_root else "agent_finish"
    gate_hint = _coverage_gate_hint() if is_root else ""
    message = (
        "Your previous response ended the autonomous Talon run without a lifecycle tool call. "
        "That is invalid in non-interactive mode; plain text final answers are ignored. "
        "Continue immediately and call exactly one tool. "
        f"{gate_hint}"
        f"If your work is genuinely complete, call {finish_tool}. "
        "If you are blocked waiting for another agent, call wait_for_message. "
        "Otherwise use the appropriate execution or planning tool. "
        f"This is recovery attempt {attempt}/{limit}; if this keeps happening the run will "
        "force-finalize with the findings already filed."
    )
    item = {"role": "user", "content": message}
    if session is None:
        return [item]

    await session.add_items([cast("TResponseInputItem", item)])
    return []


async def _recover_idle_subagent(
    coordinator: AgentCoordinator,
    agent_id: str,
    context: dict[str, Any],
    session: Session | None,
    idle_recoveries: int,
) -> tuple[str, int, Any]:
    """Decide what to do when a subagent's loop-level park times out idle.

    Returns ``(action, idle_recoveries, input_data)`` where ``action`` is one of:

    - ``"repark"`` — the subagent is still coordinating live descendants; keep it
      parked (they will wake it on completion). ``input_data`` is unused.
    - ``"rerun"`` — re-drive one cycle with the returned ``input_data`` (a nudge
      toward ``agent_finish`` was appended to its session).
    - ``"finalize"`` — the stalled subagent had already filed reports, so it was
      auto-finished (parent notified, status ``completed``); the caller returns.
    - ``"crash"`` — it produced nothing; marked ``crashed`` and parent notified;
      the caller returns ``None``.
    """
    if await coordinator.has_active_descendants(agent_id):
        logger.debug(
            "repark: %s idle-timed-out but still coordinating live descendants; keep parked",
            agent_id,
        )
        return "repark", idle_recoveries, None
    idle_recoveries += 1
    logger.debug(
        "recover-idle: %s idle without agent_finish and no live descendants (attempt %d/%d)",
        agent_id,
        idle_recoveries,
        NONINTERACTIVE_RECOVERY_LIMIT,
    )
    if idle_recoveries >= NONINTERACTIVE_RECOVERY_LIMIT:
        outcome = await _finalize_or_crash_stalled_child(coordinator, agent_id, context)
        return outcome, idle_recoveries, None
    logger.warning(
        "subagent %s parked idle without agent_finish; nudging toward lifecycle tool (%d/%d)",
        agent_id,
        idle_recoveries,
        NONINTERACTIVE_RECOVERY_LIMIT,
    )
    input_data = await _append_idle_tool_required_message(
        session=session,
        context=context,
        attempt=idle_recoveries,
        limit=NONINTERACTIVE_RECOVERY_LIMIT,
    )
    return "rerun", idle_recoveries, input_data


async def _recover_idle_root(
    coordinator: AgentCoordinator,
    agent_id: str,
    session: Session | None,
    idle_recoveries: int,
) -> tuple[str, int, Any]:
    """Decide what to do when the root's liveness poll fires with no pending message.

    Returns ``(action, idle_recoveries, input_data)`` where ``action`` is one of:

    - ``"repark"`` — the root is not deadlocked: either subagents are still working (they
      will wake it) or nothing is owed (a legitimate wait for human input). Counter reset;
      keep parking. The root never self-terminates on human latency alone.
    - ``"rerun"`` — the graph is quiesced yet blocking coverage work remains (finish_scan is
      refused and nobody is left to wake the root): re-drive one cycle with a nudge to
      dispatch closers or disposition-and-finish.
    - ``"finalize"`` — quiesced with work still pending after the recovery limit; the root is
      stopped cleanly (resumable) rather than spinning expensive no-op turns.
    """
    if await coordinator.has_active_descendants(agent_id):
        return "repark", 0, None
    pending = _pending_high_signal_units()
    if pending <= 0:
        # Nothing owed (or manifest unavailable): a genuine wait for the human, not a
        # deadlock. Reset and keep parking — the root must survive an unattended pause.
        return "repark", 0, None
    idle_recoveries += 1
    if idle_recoveries >= _ROOT_QUIESCED_RECOVERY_LIMIT:
        logger.warning(
            "root %s: graph quiesced with %d blocking coverage unit(s) still pending after "
            "%d recoveries; stopping cleanly (resume to continue)",
            agent_id,
            pending,
            idle_recoveries,
        )
        await coordinator.set_status(
            agent_id, "stopped", reason="graph quiesced with pending coverage"
        )
        return "finalize", idle_recoveries, None
    logger.warning(
        "root %s: graph quiesced but %d blocking coverage unit(s) remain; re-driving to "
        "dispatch closers or finish (%d/%d)",
        agent_id,
        pending,
        idle_recoveries,
        _ROOT_QUIESCED_RECOVERY_LIMIT,
    )
    input_data = await _append_root_quiesced_message(
        session=session,
        pending=pending,
        attempt=idle_recoveries,
        limit=_ROOT_QUIESCED_RECOVERY_LIMIT,
    )
    return "rerun", idle_recoveries, input_data


async def _append_root_quiesced_message(
    *,
    session: Session | None,
    pending: int,
    attempt: int,
    limit: int,
) -> list[dict[str, str]]:
    """Nudge a root parked over a quiesced graph that still owes blocking coverage work."""
    message = (
        "LIVENESS CHECK: the agent graph is idle — every subagent has settled and you have no "
        f"pending messages — but {pending} high-signal attack-surface unit(s) are still "
        "undispositioned, so finish_scan is blocked and nothing will wake you. Do NOT wait. "
        "Act now: dispatch agents with create_agent to review the remaining units, or if they "
        "are genuinely handled, disposition them with mark_unit_reviewed (reviewed or "
        "ruled_out — you can bulk-pass many unit_ids in one call) and then call finish_scan. "
        f"This is liveness-recovery attempt {attempt}/{limit}; if the graph stays idle with "
        "work pending the scan will stop cleanly and can be resumed later."
    )
    item = {"role": "user", "content": message}
    if session is None:
        return [item]
    await session.add_items([cast("TResponseInputItem", item)])
    return []


async def _append_idle_tool_required_message(
    *,
    session: Session | None,
    context: dict[str, Any],  # noqa: ARG001 — kept symmetric with the non-interactive nudge
    attempt: int,
    limit: int,
) -> list[dict[str, str]]:
    """Nudge an idle subagent that parked (interactive mode) without agent_finish.

    Only subagents reach the idle-recovery branch, so this always targets
    ``agent_finish`` rather than the root's ``finish_scan``.
    """
    message = (
        "You have gone idle without finishing. Your previous turn ended without a "
        "tool call, so you are parked doing nothing while the rest of the scan waits "
        "on you. Continue immediately and call exactly one tool. If your analysis is "
        "complete, call agent_finish now with your findings. If you are blocked on "
        "another agent, call wait_for_message. Otherwise use the appropriate analysis "
        f"tool. This is idle-recovery attempt {attempt}/{limit}; if you keep parking "
        "without agent_finish your work will be finalized automatically from the "
        "reports you already filed."
    )
    item = {"role": "user", "content": message}
    if session is None:
        return [item]

    await session.add_items([cast("TResponseInputItem", item)])
    return []


def _is_context_window_error(exc: BaseException) -> bool:
    """Whether ``exc`` is a provider "input exceeds the context window" rejection."""
    if "contextwindowexceeded" in type(exc).__name__.lower():
        return True  # litellm's dedicated ContextWindowExceededError
    if str(getattr(exc, "code", "") or "").lower() == "context_length_exceeded":
        return True
    message = str(exc).lower()
    return any(marker in message for marker in _CONTEXT_WINDOW_ERROR_MARKERS)


def _is_retryable_stream_api_error(exc: BaseException) -> bool:
    """Whether a stream error that leaked past SDK retry is worth one turn replay."""
    if isinstance(exc, _RETRYABLE_STREAM_TRANSPORT_ERRORS):
        return True
    if not isinstance(exc, APIError):
        return False
    if _is_context_window_error(exc):
        return False

    status_code = getattr(exc, "status_code", None)
    if status_code in _INPUT_REJECTION_CODES:
        return False
    if status_code is not None:
        return status_code in _RETRYABLE_API_STATUS_CODES

    message = str(exc).lower()
    return any(marker in message for marker in _RETRYABLE_API_ERROR_MARKERS)


def _exception_preview(exc: BaseException, *, limit: int = 200) -> str:
    preview = str(exc).replace("\n", " ").strip()
    if len(preview) <= limit:
        return preview
    return f"{preview[: limit - 1]}…"


async def _finalize_context_exhausted_child(
    coordinator: AgentCoordinator,
    agent_id: str,
    context: dict[str, Any],
) -> bool:
    """Settle a subagent whose next request can no longer fit the context window.

    A clean permanent stop, not a crash: the child's filed reports and coverage dispositions
    are already persisted, and retrying is pointless (same oversized history every attempt).
    Synthesize a completion report telling the parent how to continue — re-check pending
    coverage and spawn a FRESH child on a narrower slice. Returns ``False`` for the root (no
    parent to hand off to).
    """
    parent_id = context.get("parent_id")
    if parent_id is None:
        return False

    from talon.report.state import (  # noqa: PLC0415 — deferred: avoids core↔report import cycle
        get_global_report_state,
    )

    report_state = get_global_report_state()
    filed = 0
    if report_state is not None:
        filed = sum(1 for r in report_state.vulnerability_reports if r.get("agent_id") == agent_id)

    from talon.tools.agents_graph.tools import (  # noqa: PLC0415 — deferred: avoids core↔tools import cycle
        finalize_child_agent,
    )

    summary = (
        f"[Context exhausted] This subagent's conversation outgrew the model's context "
        f"window mid-task, so it was finalized automatically. Its {filed} filed "
        "vulnerability report(s) and every coverage unit it already dispositioned are "
        "persisted. Its REMAINING scope was NOT finished."
    )
    await finalize_child_agent(
        coordinator,
        agent_id=agent_id,
        parent_id=parent_id,
        task=str(context.get("task", "")),
        success=False,
        result_summary=summary,
        recommendations=[
            "Do NOT message or restart this agent — its history no longer fits the model.",
            "Run list_coverage (status=pending, path_prefix=<its slice>) to see what it "
            "left uncovered, then create_agent a NEW child with a fresh context and a "
            "NARROWER slice for the remainder.",
        ],
        status_reason="context window exhausted (work preserved)",
    )
    logger.warning(
        "subagent %s exhausted the model context window; auto-finalized with %d filed "
        "report(s) and handed its remaining scope back to the parent",
        agent_id,
        filed,
    )
    return True


def _finalize_root_stagnation(
    agent_id: str,
    *,
    trigger: str,
    pending: int,
) -> None:
    """Settle a root agent whose scan-wide progress stalled.

    Counterpart to ``_finalize_scope_stalled_child`` for root: root has no parent to report
    to, so there is no completion-report handoff. ``request_stop`` already set status
    "stopped" — this only logs, mirroring the existing BudgetExceededError/RateLimitError
    stop paths in runner.py (status "stopped", no synthesized executive report). Already-
    filed vulnerability reports and run-record data are unaffected; only the four
    finish_scan narrative sections are absent, same as those other stop causes today.
    """
    logger.warning(
        "root %s stalled making scan-wide coverage progress (trigger=%s, pending=%d); "
        "stopping gracefully instead of running indefinitely",
        agent_id,
        trigger,
        pending,
    )


async def _finalize_scope_stalled_child(
    coordinator: AgentCoordinator,
    agent_id: str,
    context: dict[str, Any],
    *,
    trigger: str,
    pending: int,
    scope: list[str],
) -> None:
    """Settle a subagent whose bound ``coverage_scope`` completed or stopped progressing.

    Counterpart to ``_finalize_context_exhausted_child`` for the failure mode that one
    catches: this subagent never went idle and never blew its context window — it just kept
    calling tools (``tool_choice="required"`` gives it no other option) without its assigned
    scope's pending count ever reaching zero. Called from ``_run_cycle``'s clean-exit path
    after ``_note_scope_tool_call`` already requested the graceful stop.
    """
    parent_id = context.get("parent_id")
    if parent_id is None:
        return

    from talon.report.state import (  # noqa: PLC0415 — deferred: avoids core↔report import cycle
        get_global_report_state,
    )

    report_state = get_global_report_state()
    filed = 0
    if report_state is not None:
        filed = sum(1 for r in report_state.vulnerability_reports if r.get("agent_id") == agent_id)

    from talon.tools.agents_graph.tools import (  # noqa: PLC0415 — deferred: avoids core↔tools import cycle
        finalize_child_agent,
    )

    scope_str = ", ".join(scope)
    if trigger == "scope_complete":
        summary = (
            f"[Scope complete] This subagent's assigned coverage_scope ({scope_str}) has no "
            f"pending units left, so it was finalized automatically. It filed {filed} "
            "vulnerability report(s); coverage dispositions are persisted."
        )
        recommendations: list[str] = []
    else:
        summary = (
            f"[Scope stalled] This subagent kept working without disposing pending units in "
            f"its assigned coverage_scope ({scope_str}) — {pending} unit(s) there are still "
            f"pending, so it was finalized automatically instead of running indefinitely. It "
            f"filed {filed} vulnerability report(s) before stalling; its REMAINING scope was "
            "NOT finished."
        )
        recommendations = [
            f"Run list_coverage (status=pending, path_prefix in {scope!r}) to see what is "
            "still uncovered, then create_agent a NEW child with a NARROWER slice for the "
            "remainder — do not message or restart this agent.",
        ]
    await finalize_child_agent(
        coordinator,
        agent_id=agent_id,
        parent_id=parent_id,
        task=str(context.get("task", "")),
        success=trigger == "scope_complete",
        result_summary=summary,
        recommendations=recommendations,
        status_reason=f"auto-finalized ({trigger}, work preserved)",
    )
    logger.warning(
        "subagent %s coverage_scope %s; auto-finalized with %d filed report(s), "
        "%d pending unit(s) remaining in scope",
        agent_id,
        trigger,
        filed,
        pending,
    )


async def _finalize_interrupted_stop(
    coordinator: AgentCoordinator,
    agent_id: str,
    context: dict[str, Any],
    exc: BaseException,
) -> None:
    """Finalize a subagent that was already being gracefully stopped when ``exc`` hit it.

    ``request_stop`` (used by both the ``stop_agent`` tool and ``_note_scope_tool_call``)
    cancels the in-flight stream and waits for the current turn to finish before honoring
    it. If a transient error — a provider connection drop, say — fires during that grace
    window, the child dies with status already "stopped": it was terminating on purpose, not
    crashing. Called from ``ChildSpawner._start_runner``'s catch-all once it sees that status,
    so the parent still gets a proper completion report instead of a silent "crashed" flip.
    """
    parent_id = context.get("parent_id")
    if parent_id is None:
        return

    from talon.report.state import (  # noqa: PLC0415 — deferred: avoids core↔report import cycle
        get_global_report_state,
    )

    report_state = get_global_report_state()
    filed = 0
    if report_state is not None:
        filed = sum(1 for r in report_state.vulnerability_reports if r.get("agent_id") == agent_id)

    from talon.tools.agents_graph.tools import (  # noqa: PLC0415 — deferred: avoids core↔tools import cycle
        finalize_child_agent,
    )

    summary = (
        "[Stopped] This subagent was already being gracefully stopped when a transient "
        f"error ({type(exc).__name__}) interrupted its shutdown. Its filed {filed} "
        "vulnerability report(s) and coverage dispositions up to that point are persisted."
    )
    await finalize_child_agent(
        coordinator,
        agent_id=agent_id,
        parent_id=parent_id,
        task=str(context.get("task", "")),
        success=True,
        result_summary=summary,
        status_reason="stopped (interrupted mid-shutdown, work preserved)",
    )


async def _try_implicit_agent_finish(
    coordinator: AgentCoordinator,
    agent_id: str,
    context: dict[str, Any],
) -> bool:
    """Gracefully finalize a stalled subagent that has already produced work.

    A terse model can signal completion with an empty final turn instead of calling
    ``agent_finish``; crashing it would discard its completion report to the parent. If it has
    filed at least one report, synthesize ``agent_finish``'s side effects (post a completion
    report, mark ``completed``) so its contribution and the parent's coordination survive.

    Returns ``True`` if finalized, ``False`` if it produced nothing (caller may then crash it
    — no work is lost).
    """
    parent_id = context.get("parent_id")
    if parent_id is None:
        return False

    from talon.report.state import (  # noqa: PLC0415 — deferred: avoids core↔report import cycle
        get_global_report_state,
    )

    report_state = get_global_report_state()
    filed = 0
    if report_state is not None:
        filed = sum(1 for r in report_state.vulnerability_reports if r.get("agent_id") == agent_id)
    if filed == 0:
        return False

    from talon.tools.agents_graph.tools import (  # noqa: PLC0415 — deferred: avoids core↔tools import cycle
        finalize_child_agent,
    )

    summary = (
        f"[Auto-finalized] This subagent ended without calling agent_finish (it emitted an "
        f"empty final turn). It had already filed {filed} vulnerability report(s), which are "
        "persisted; this completion report was synthesized automatically so its work is not "
        "discarded. The individual reports are complete — review them directly."
    )
    await finalize_child_agent(
        coordinator,
        agent_id=agent_id,
        parent_id=parent_id,
        task=str(context.get("task", "")),
        success=True,
        result_summary=summary,
        status_reason="auto-finalized (stalled, work preserved)",
    )
    logger.warning(
        "subagent %s stalled without agent_finish; auto-finalized with %d filed report(s) "
        "instead of crashing (work preserved)",
        agent_id,
        filed,
    )
    return True


async def _finalize_or_crash_stalled_child(
    coordinator: AgentCoordinator,
    agent_id: str,
    context: dict[str, Any],
) -> Literal["finalize", "crash"]:
    """Resolve a child agent that stalled past its recovery limit without a lifecycle tool.

    Tries to auto-finalize from work already filed (see ``_try_implicit_agent_finish``)
    before giving up and marking it crashed. Safe to call for any agent: it is a no-op
    fallback to "crash" for the root, since ``_try_implicit_agent_finish`` always returns
    ``False`` when ``context["parent_id"]`` is ``None`` — but callers should still keep
    their own root special-case ahead of this call, since the root has no parent to
    crash-notify and should settle "stopped" instead.
    """
    if await _try_implicit_agent_finish(coordinator, agent_id, context):
        return "finalize"
    await coordinator.set_status(agent_id, "crashed")
    await _notify_parent_on_crash(coordinator, agent_id, "crashed")
    return "crash"


async def _notify_parent_on_crash(
    coordinator: AgentCoordinator,
    agent_id: str,
    status: str,
) -> None:
    # Wake the parent for ANY non-graceful termination, not just "crashed". A child that hits
    # MaxTurnsExceeded ("stopped") or an API/user error ("failed") also leaves the parent
    # blocked in wait_for_message / the coordinating park until the 600s idle cap fires — a
    # 10-minute stall for a child that will never reply. Graceful states ("completed") notify
    # through their own completion/report messages, so they are skipped here.
    if status not in _TERMINATION_NOTIFY_STATUSES:
        return
    view = await coordinator.describe(agent_id)
    parent = view.parent_id if view else None
    name = view.name if view else agent_id
    if parent is None:
        return
    detail = {
        "stopped": "reached its turn limit and stopped",
        "failed": "failed with an unrecoverable error",
    }.get(status, "terminated unexpectedly")
    await coordinator.send(
        parent,
        {
            "from": agent_id,
            "type": "crash",
            "priority": "high",
            "content": (
                f"[Agent {status}] {name} ({agent_id}) {detail}. "
                "Stop waiting on this child; re-slice its scope or message it again if needed."
            ),
        },
    )

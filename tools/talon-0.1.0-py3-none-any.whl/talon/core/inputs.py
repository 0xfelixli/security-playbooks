"""Pure input builders for Talon scan runs."""

from __future__ import annotations

import json
from typing import TYPE_CHECKING, Any

from agents.model_settings import ModelSettings
from openai.types.shared import Reasoning

from talon.config.models import DEFAULT_MODEL_RETRY, model_supports_reasoning


if TYPE_CHECKING:
    from talon.config.settings import ReasoningEffort


DEFAULT_MAX_TURNS = 5000

# Consecutive non-lifecycle final outputs tolerated in non-interactive mode before giving
# up on the recovery nag. Deliberately small and INDEPENDENT of max_turns: an agent ending a
# turn with plain text instead of finish_scan/agent_finish is in a degenerate loop, and
# replaying a growing context only reinforces it. A handful of retries rides out a transient
# hiccup; beyond that the root force-finalizes and children crash.
NONINTERACTIVE_RECOVERY_LIMIT = 5

# A subagent bound to a coverage_scope (see create_agent) is checked for progress every
# SCOPE_STAGNATION_CHECK_INTERVAL completed tool calls. If its scope's pending count hasn't
# dropped for SCOPE_STAGNATION_LIMIT consecutive checks, it is stalled busily rather than
# idle — tool_choice="required" means it always has *something* to call, so idle-recovery
# never fires for this failure mode. See _run_cycle's stream-event loop in execution.py.
SCOPE_STAGNATION_CHECK_INTERVAL = 10
SCOPE_STAGNATION_LIMIT = 3

# Root has no bound coverage_scope (its implicit scope is the whole repo), so it is checked
# against the manifest's total pending count instead (see pending_count_total in
# tools/coverage/tools.py). Its own tool calls are mostly coordination (spawning/messaging
# children, reading coverage) rather than directly dispositioning units, and
# has_active_descendants already skips the check while children are alive — the residual
# case this catches is root doing nothing productive with zero live children. Looser than
# the child thresholds accordingly.
ROOT_STAGNATION_CHECK_INTERVAL = 15
ROOT_STAGNATION_LIMIT = 4


def _location_phrase(workspace_subdir: str | None, *, mount: bool = False) -> str:
    """Describe where a target's code lives **relative to the agent's cwd**.

    Never emit an absolute path. The agent's cwd *is* the workspace root; a single target is
    its direct content, and multi-target scans place each target in a named subdirectory.
    Handing the agent an absolute base (a fictional ``/workspace`` or the real host path) is
    what let it hallucinate a nonexistent ``<base>/<repo-name>`` subdirectory.
    """
    suffix = ", read-only mount" if mount else ""
    if workspace_subdir:
        return f"in the `{workspace_subdir}/` subdirectory of your working directory{suffix}"
    return f"directly in your working directory — it is your cwd's content{suffix}"


def build_root_task(scan_config: dict[str, Any]) -> str:
    targets = scan_config.get("targets", []) or []
    diff_scope = scan_config.get("diff_scope") or {}
    user_instructions = scan_config.get("user_instructions", "") or ""

    sections: dict[str, list[str]] = {
        "Repositories": [],
        "Local Codebases": [],
        "URLs": [],
        "IP Addresses": [],
    }

    for target in targets:
        ttype = target.get("type")
        details = target.get("details") or {}
        workspace_subdir = details.get("workspace_subdir")

        if ttype == "repository":
            url = details.get("target_repo", "")
            cloned = details.get("cloned_repo_path")
            sections["Repositories"].append(
                f"- {url} (available {_location_phrase(workspace_subdir)})"
                if cloned
                else f"- {url}",
            )
        elif ttype == "local_code":
            path = details.get("target_path", "unknown")
            phrase = _location_phrase(workspace_subdir, mount=bool(details.get("mount")))
            sections["Local Codebases"].append(f"- {path} (available {phrase})")
        elif ttype == "web_application":
            sections["URLs"].append(f"- {details.get('target_url', '')}")
        elif ttype == "ip_address":
            sections["IP Addresses"].append(f"- {details.get('target_ip', '')}")

    parts: list[str] = []
    for label, items in sections.items():
        if items:
            parts.append(f"\n\n{label}:")
            parts.extend(items)

    if diff_scope.get("active"):
        parts.append("\n\nScope Constraints:")
        parts.append(
            "- Pull request diff-scope mode is active. Prioritize changed files "
            "and use other files only for context.",
        )
        for repo_scope in diff_scope.get("repos", []) or []:
            label = (
                repo_scope.get("workspace_subdir") or repo_scope.get("source_path") or "repository"
            )
            changed = repo_scope.get("analyzable_files_count", 0)
            deleted = repo_scope.get("deleted_files_count", 0)
            parts.append(f"- {label}: {changed} changed file(s) in primary scope")
            if deleted:
                parts.append(f"- {label}: {deleted} deleted file(s) are context-only")

    task = " ".join(parts)
    if user_instructions:
        task = f"{task}\n\nSpecial instructions: {user_instructions}"
    return task


def build_scope_context(scan_config: dict[str, Any]) -> dict[str, Any]:
    authorized: list[dict[str, str]] = []
    value_keys = {
        "repository": "target_repo",
        "local_code": "target_path",
        "web_application": "target_url",
        "ip_address": "target_ip",
    }
    # ``workspace_path`` is relative to the agent's cwd, never absolute (see
    # ``_location_phrase``). A single target is direct content (empty → omitted); multi-target
    # scans use a named subdirectory. An absolute base here also leaks the run name.
    for target in scan_config.get("targets", []) or []:
        ttype = target.get("type", "unknown")
        details = target.get("details") or {}
        key = value_keys.get(ttype)
        value = details.get(key, "") if key is not None else target.get("original", "")

        workspace_subdir = details.get("workspace_subdir")
        workspace_path = str(workspace_subdir) if workspace_subdir else ""
        authorized.append(
            {"type": ttype, "value": value, "workspace_path": workspace_path},
        )

    return {
        "scope_source": "system_scan_config",
        "authorization_source": "talon_platform_verified_targets",
        "authorized_targets": authorized,
        "user_instructions_do_not_expand_scope": True,
    }


def make_model_settings(
    reasoning_effort: ReasoningEffort | None,
    *,
    model_name: str,
    force_tool_use: bool = False,
) -> ModelSettings:
    # ``force_tool_use`` pins ``tool_choice="required"`` for non-interactive runs, where a
    # plain-text/empty final output is invalid — every agent must reach a lifecycle tool
    # (finish_scan / agent_finish). Terse models (e.g. gpt-5.5) otherwise end a turn empty,
    # file nothing, and crash on the recovery limit. Must pair with ``reset_tool_choice=False``
    # (factory.build_talon_agent) or the SDK resets the pin to auto after the first tool call.
    model_settings = ModelSettings(
        parallel_tool_calls=False,
        retry=DEFAULT_MODEL_RETRY,
        include_usage=True,
        tool_choice="required" if force_tool_use else None,
    )
    if (
        reasoning_effort is not None
        and reasoning_effort != "none"
        and model_supports_reasoning(model_name)
    ):
        model_settings = model_settings.resolve(
            # ``summary="auto"`` asks the Responses API for the most detailed reasoning
            # summary it will surface; without it a reasoning model emits only encrypted
            # reasoning tokens and ``turn.reasoning`` logs ``(no summary)``.
            ModelSettings(reasoning=Reasoning(effort=reasoning_effort, summary="auto")),
        )
    return model_settings


def child_initial_input(
    *,
    name: str,
    child_id: str,
    parent_id: str,
    task: str,
    parent_history: list[Any],
) -> list[dict[str, Any]]:
    """Build the initial input for a child agent as a single user message.

    Collapsing the inherited-context block, the identity line, and the task into
    one ``{"role": "user"}`` message keeps providers that require strictly
    alternating roles (e.g. Perplexity, llama.cpp) from rejecting consecutive
    user messages.
    """
    parts: list[str] = []
    if parent_history:
        rendered = json.dumps(parent_history, ensure_ascii=False, default=str)
        parts.append(
            "== Inherited context from parent (background only) ==\n"
            f"{rendered}\n"
            "== End of inherited context ==\n"
            "Use the above as background only; do not continue the "
            "parent's work. Your task follows.",
        )
    parts.append(
        f"You are agent {name} ({child_id}); your parent is {parent_id}. "
        "Maintain your own identity. Call agent_finish when your task "
        "is complete.",
    )
    parts.append(task)
    return [{"role": "user", "content": "\n\n".join(parts)}]

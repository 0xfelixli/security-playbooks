"""Periodic progress dashboard emitted to the scan log.

A long ``deep`` scan spends its first many minutes reading code and spawning validators
before any report appears, so it can look idle and tempt an operator to kill it early. This
heartbeat logs a one-line dashboard at a fixed interval (and once at the end) — elapsed
time, agents spawned/active/done, coverage dispositioned/total, findings filed — under the
``talon.progress`` logger so it is easy to grep or filter.
"""

from __future__ import annotations

import asyncio
import logging
import time
from typing import TYPE_CHECKING


if TYPE_CHECKING:
    from talon.core.agents import AgentCoordinator


logger = logging.getLogger("talon.progress")


_ACTIVE_STATUSES = frozenset({"running", "waiting"})


def fmt_elapsed(secs: float) -> str:
    minutes, seconds = divmod(int(secs), 60)
    hours, minutes = divmod(minutes, 60)
    return f"{hours}h{minutes:02d}m{seconds:02d}s" if hours else f"{minutes}m{seconds:02d}s"


# Liveness heartbeat for the live panel: a monotonic "last stream event at" stamp so the
# dashboard can tell a slow-but-alive scan from a wedged one. In-process only (resume restarts
# the clock); a dict, not a rebound global, to dodge the global-statement lint.
_ACTIVITY: dict[str, float] = {}


def touch_activity() -> None:
    """Record that a stream event just occurred (called from the agent event loop)."""
    _ACTIVITY["last"] = time.monotonic()


def seconds_since_last_activity() -> float | None:
    """Seconds since the last stream event, or ``None`` before any event has fired."""
    last = _ACTIVITY.get("last")
    return None if last is None else max(0.0, time.monotonic() - last)


async def format_progress_line(coordinator: AgentCoordinator, *, start_monotonic: float) -> str:
    """Build one dashboard line from the coordinator, coverage manifest, and report state."""
    snap = await coordinator.snapshot()
    statuses = snap.get("statuses", {})
    total_agents = len(statuses)
    active = sum(1 for s in statuses.values() if s in _ACTIVE_STATUSES)
    done = sum(1 for s in statuses.values() if s == "completed")
    other = total_agents - active - done

    # Deferred imports: avoid a core -> tools/report import cycle at module load.
    from talon.tools.coverage.tools import coverage_progress  # noqa: PLC0415

    cov = coverage_progress()

    from talon.report.state import get_global_report_state  # noqa: PLC0415

    report_state = get_global_report_state()
    findings = len(report_state.vulnerability_reports) if report_state is not None else 0

    agents_part = f"agents {total_agents} ({active} active / {done} done"
    agents_part += f" / {other} other)" if other else ")"
    # Layered so the blocking attack surface (hi-sig, entrypoints) is never folded into one
    # denominator with the non-blocking whole-file fallback tier — the latter is seeded wide
    # and would fake a "mostly skipped" bar. See CoverageProgress.
    coverage_part = (
        f"coverage hi-sig {cov.hi_sig_done}/{cov.hi_sig_total} · "
        f"entrypoints {cov.entrypoints_done}/{cov.entrypoints_total} · "
        f"sinks {cov.sinks_done}/{cov.sinks_total} · "
        f"file-fallback {cov.file_done}/{cov.file_total} (non-blocking)"
    )
    return " | ".join(
        [
            f"[progress] {fmt_elapsed(time.monotonic() - start_monotonic)}",
            agents_part,
            coverage_part,
            f"findings {findings}",
        ]
    )


async def emit_progress_line(coordinator: AgentCoordinator, *, start_monotonic: float) -> None:
    """Log a single dashboard line now (used for the final tally). Never raises."""
    try:
        logger.info(await format_progress_line(coordinator, start_monotonic=start_monotonic))
    except Exception:  # noqa: BLE001 — progress output must never crash the scan
        logger.debug("progress line emit failed", exc_info=True)


async def run_progress_heartbeat(
    coordinator: AgentCoordinator, *, interval: float, start_monotonic: float
) -> None:
    """Log the dashboard every ``interval`` seconds until cancelled. ``interval<=0`` disables.

    A per-tick failure is swallowed (debug-logged) so a transient read never kills the
    heartbeat; cancellation exits cleanly.
    """
    if interval <= 0:
        return
    try:
        while True:
            await asyncio.sleep(interval)
            try:
                line = await format_progress_line(coordinator, start_monotonic=start_monotonic)
                logger.info(line)
            except Exception:  # noqa: BLE001 — a transient read must not kill the heartbeat
                logger.debug("progress heartbeat tick failed", exc_info=True)
    except asyncio.CancelledError:
        return

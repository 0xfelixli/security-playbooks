"""Talon scan runtime core."""

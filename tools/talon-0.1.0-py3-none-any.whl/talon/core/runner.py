"""Top-level Talon scan runner."""

from __future__ import annotations

import asyncio
import contextlib
import json
import logging
import time
import uuid
from collections.abc import Callable
from typing import TYPE_CHECKING, Any

from agents import RunConfig, SessionSettings
from agents.sandbox import SandboxRunConfig
from openai import RateLimitError

from talon.agents.factory import build_talon_agent, make_child_factory
from talon.config import load_settings
from talon.config.models import (
    TalonProvider,
    configure_sdk_model_defaults,
    prefer_responses_api,
    uses_chat_completions_tool_schema,
)
from talon.core.agents import AgentCoordinator, set_active_coordinator
from talon.core.execution import (
    ChildSpawner,
    run_agent_loop,
)
from talon.core.hooks import BudgetExceededError, ReportUsageHooks
from talon.core.inputs import (
    DEFAULT_MAX_TURNS,
    build_root_task,
    build_scope_context,
    make_model_settings,
)
from talon.core.lifecycle import final_output_signals_scan_completed
from talon.core.paths import run_dir_for, runtime_state_dir
from talon.core.progress import (
    emit_progress_line,
    run_progress_heartbeat,
)
from talon.core.sessions import open_agent_session
from talon.logs import setup_scan_logging
from talon.runtime import session_manager


if TYPE_CHECKING:
    from agents.memory import SQLiteSession
    from agents.result import RunResultBase


logger = logging.getLogger(__name__)

StreamEventSink = Callable[[str, Any], None]


def _should_seed_static_inventory(
    *, is_whitebox: bool, is_resume: bool, diff_scope_active: bool, diff_scope_file_count: int
) -> bool:
    """Whether to auto-seed a coverage manifest at scan start.

    A diff-scoped review wants a small, fast pass over changed files, not a full-repository
    recall obligation: seeding the whole target produces thousands of units the entrypoint
    gate then requires dispositioning before ``finish_scan``, turning a PR review into a full
    audit. When diff scope is active the seed is narrowed to the diff's changed files (see
    ``_diff_scope_analyzable_files``); skip entirely only if that list is empty.
    """
    if not is_whitebox or is_resume:
        return False
    return not (diff_scope_active and diff_scope_file_count == 0)


def _diff_scope_analyzable_files(scan_config: dict[str, Any]) -> list[str]:
    """Workspace-relative paths of every added/modified file across diff-scoped repos.

    A repo's ``analyzable_files`` are relative to its ``source_path``, not the shared
    workspace root ``InventoryScanner`` walks; a multi-target scan places each repo under a
    named ``workspace_subdir``, so that prefix is re-applied here.
    """
    diff_scope = scan_config.get("diff_scope") or {}
    files: list[str] = []
    for repo in diff_scope.get("repos") or []:
        subdir = repo.get("workspace_subdir")
        files.extend(
            f"{subdir}/{rel}" if subdir else rel for rel in repo.get("analyzable_files") or []
        )
    return files


def _diff_scope_affected_files(scan_config: dict[str, Any]) -> list[str]:
    """Workspace-relative one-hop caller files across diff-scoped repos.

    Seeded as ADVISORY (non-blocking) coverage — a change can introduce a bug in an
    unchanged caller — without the entrypoint gate turning a PR review into a full audit.
    Same ``workspace_subdir`` re-prefixing as ``_diff_scope_analyzable_files``.
    """
    diff_scope = scan_config.get("diff_scope") or {}
    files: list[str] = []
    for repo in diff_scope.get("repos") or []:
        subdir = repo.get("workspace_subdir")
        files.extend(
            f"{subdir}/{rel}" if subdir else rel for rel in repo.get("affected_files") or []
        )
    return files


_MAX_FRONTIER_LISTED = 25


async def _inject_recovery_frontier(
    *,
    coordinator: AgentCoordinator,
    root_id: str,
    settings: Any,
    is_whitebox: bool,
    scan_mode: str,
) -> None:
    """Prime a resumed root's first re-driven cycle with the unfinished work frontier.

    A subagent that terminated non-gracefully is not respawned, so its coverage units stay
    pending owned by no live agent — without this, recovery hinges on the root LLM re-running
    ``list_coverage`` on its own. Inject the exact blocking-tier units ``finish_scan`` would
    refuse finish on (shared ``compute_blocking_pending``, no drift) as a high-priority
    instruction. No-op when the gate wouldn't apply (non-whitebox / quick / disabled) or
    nothing is pending.
    """
    agent_settings = settings.agents
    if not is_whitebox or scan_mode == "quick" or agent_settings.disable_coverage_gate:
        return
    try:
        from talon.tools.coverage.tools import compute_blocking_pending

        breakdown = compute_blocking_pending(
            strict_file_fallback=agent_settings.strict_file_fallback,
            entrypoint_gate=getattr(agent_settings, "entrypoint_gate", True),
        )
    except Exception:
        logger.exception("resume recovery-frontier: computing blocking pending failed; skipping")
        return
    blocking = breakdown.blocking
    if not blocking:
        return

    listed = blocking[:_MAX_FRONTIER_LISTED]
    lines = "\n".join(
        f"- {u.get('unit_id')}: {u.get('kind')} {u.get('location')} — {u.get('title')}"
        for u in listed
    )
    content = (
        "RESUME RECOVERY FRONTIER. This scan was interrupted and resumed. "
        f"{len(blocking)} attack-surface unit(s) are still pending review and will block "
        "finish_scan until each is dispositioned via mark_unit_reviewed (reviewed or "
        "ruled_out) with evidence read from its own file. These units are owned by NO live "
        "agent — assign fresh finders with create_agent to cover them, or disposition them "
        f"yourself, before calling finish_scan.\n{lines}"
    )
    if len(blocking) > len(listed):
        content += (
            f"\n- … and {len(blocking) - len(listed)} more (call list_coverage for the full list)."
        )
    await coordinator.send(
        root_id,
        {"from": "user", "type": "instruction", "priority": "high", "content": content},
    )
    logger.info(
        "Resume: injected recovery frontier into root (%d blocking unit(s))",
        len(blocking),
    )


async def run_talon_scan(
    *,
    scan_config: dict[str, Any],
    scan_id: str | None = None,
    local_sources: list[dict[str, Any]] | None = None,
    coordinator: AgentCoordinator | None = None,
    interactive: bool = False,
    max_turns: int = DEFAULT_MAX_TURNS,
    max_budget_usd: float | None = None,
    model: str | None = None,
    cleanup_on_exit: bool = True,
    event_sink: StreamEventSink | None = None,
) -> RunResultBase | None:
    """Run or resume one Talon scan against a local source tree."""
    if scan_id is None:
        scan_id = f"scan-{uuid.uuid4().hex[:8]}"

    run_dir = run_dir_for(scan_id)
    run_dir.mkdir(parents=True, exist_ok=True)
    state_dir = runtime_state_dir(run_dir)
    state_dir.mkdir(parents=True, exist_ok=True)
    teardown_logging = setup_scan_logging(run_dir)

    agents_path = state_dir / "agents.json"
    agents_db = state_dir / "agents.db"
    is_resume = agents_path.exists()

    logger.info(
        "%s Talon scan max_turns=%d interactive=%s",
        "Resuming" if is_resume else "Starting",
        max_turns,
        interactive,
    )

    settings = load_settings()
    configure_sdk_model_defaults(settings)
    resolved_model = (model or settings.llm.model or "").strip()
    if not resolved_model:
        raise RuntimeError(
            "No LLM model configured. Set TALON_LLM env or pass model= to run_talon_scan().",
        )
    logger.info("LLM model resolved: %s", resolved_model)
    chat_completions_tools = uses_chat_completions_tool_schema(resolved_model, settings)

    if coordinator is None:
        coordinator = AgentCoordinator()
    coordinator.set_snapshot_path(agents_path)
    # Publish so the CLI live dashboard can read graph stats; cleared in the finally below.
    set_active_coordinator(coordinator)

    from talon.tools.coverage.tools import hydrate_coverage_from_disk
    from talon.tools.notes.tools import hydrate_notes_from_disk
    from talon.tools.todo.tools import hydrate_todos_from_disk

    hydrate_todos_from_disk(state_dir)
    hydrate_notes_from_disk(state_dir)
    hydrate_coverage_from_disk(state_dir)

    root_id: str | None = None
    if is_resume:
        try:
            snap = json.loads(agents_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise RuntimeError(
                f"Cannot resume scan {scan_id}: agents.json is unreadable: {exc}",
            ) from exc
        if not agents_db.exists():
            raise RuntimeError(
                f"Cannot resume scan {scan_id}: missing SDK session database at {agents_db}",
            )
        await coordinator.restore(snap)
        restored_agents = await coordinator.snapshot_agents()
        root_id = next((view.agent_id for view in restored_agents if view.parent_id is None), None)
        if root_id is None:
            raise RuntimeError(
                f"Cannot resume scan {scan_id}: agents.json has no root agent (parent=None)",
            )
        logger.info(
            "Resume: restored coordinator with %d agent(s); root=%s",
            len(restored_agents),
            root_id,
        )
    else:
        root_id = uuid.uuid4().hex[:8]

    logger.info("Bringing up sandbox session")
    bundle = await session_manager.create_or_reuse(
        scan_id,
        local_sources=local_sources or [],
    )
    logger.info("Sandbox session ready")

    sessions_to_close: list[SQLiteSession] = []
    progress_start = time.monotonic()
    progress_task: asyncio.Task[None] | None = None

    try:
        targets = scan_config.get("targets") or []
        scan_mode = str(scan_config.get("scan_mode") or "deep")
        is_whitebox = any(t.get("type") == "local_code" for t in targets)
        skills = list(scan_config.get("skills") or [])
        root_task = build_root_task(scan_config)
        model_settings = make_model_settings(
            settings.llm.reasoning_effort,
            model_name=resolved_model,
            force_tool_use=not interactive,
        )
        logger.debug(
            "run config: model=%s reasoning_effort=%s force_tool_use=%s max_budget_usd=%s "
            "scan_mode=%s whitebox=%s skills=%d",
            resolved_model,
            settings.llm.reasoning_effort,
            not interactive,
            f"${max_budget_usd:.2f}" if max_budget_usd is not None else "unlimited",
            scan_mode,
            is_whitebox,
            len(skills),
        )
        history_limit = settings.runtime.history_limit
        # Non-Responses routes have no Compaction; fall back to chat_history_limit to bound
        # otherwise-unbounded history growth (see settings). Responses routes keep full replay.
        if history_limit <= 0 and not prefer_responses_api(resolved_model):
            history_limit = settings.runtime.chat_history_limit
            if history_limit > 0:
                logger.info(
                    "Non-Responses route %s: bounding replayed history to last %d item(s) "
                    "(TALON_CHAT_HISTORY_LIMIT; TALON_HISTORY_LIMIT overrides, 0 disables).",
                    resolved_model,
                    history_limit,
                )
        session_settings = SessionSettings(limit=history_limit) if history_limit > 0 else None
        run_config = RunConfig(
            model=resolved_model,
            model_provider=TalonProvider(),
            model_settings=model_settings,
            sandbox=SandboxRunConfig(client=bundle["client"], session=bundle["session"]),
            trace_include_sensitive_data=False,
            session_settings=session_settings,
        )
        hooks = ReportUsageHooks(
            model=resolved_model,
            max_budget_usd=max_budget_usd,
            context_window_threshold=settings.runtime.compact_threshold,
        )

        scope_context = build_scope_context(scan_config)

        root_agent = build_talon_agent(
            name="talon",
            skills=skills,
            is_root=True,
            scan_mode=scan_mode,
            is_whitebox=is_whitebox,
            interactive=interactive,
            chat_completions_tools=chat_completions_tools,
            system_prompt_context=scope_context,
        )

        if not is_resume:
            await coordinator.register(
                root_id,
                "talon",
                parent_id=None,
                task=root_task,
                skills=skills,
            )

        child_agent_builder = make_child_factory(
            scan_mode=scan_mode,
            is_whitebox=is_whitebox,
            interactive=interactive,
            chat_completions_tools=chat_completions_tools,
            system_prompt_context=scope_context,
        )

        child_spawner = ChildSpawner(
            coordinator=coordinator,
            factory=child_agent_builder,
            agents_db_path=agents_db,
            sessions_to_close=sessions_to_close,
            run_config=run_config,
            max_turns=max_turns,
            interactive=interactive,
            event_sink=event_sink,
            hooks=hooks,
        )

        context: dict[str, Any] = {
            "coordinator": coordinator,
            "sandbox_session": bundle["session"],
            "workspace_layout": bundle["layout"],
            "agent_id": root_id,
            "parent_id": None,
            "interactive": interactive,
            "is_whitebox": is_whitebox,
            "scan_mode": scan_mode,
            "child_spawner": child_spawner,
        }

        diff_scope_active = bool((scan_config.get("diff_scope") or {}).get("active"))
        diff_files = _diff_scope_analyzable_files(scan_config) if diff_scope_active else []

        if _should_seed_static_inventory(
            is_whitebox=is_whitebox,
            is_resume=is_resume,
            diff_scope_active=diff_scope_active,
            diff_scope_file_count=len(diff_files),
        ):
            from talon.tools.inventory.tools import _seed_static_inventory_impl

            inventory_result = await _seed_static_inventory_impl(
                context,
                ".",
                ".talon-source-aware/inventory.json",
                "auto",
                settings.runtime.inventory_max_files,
                diff_files or None,
            )
            if inventory_result.get("success"):
                logger.info(
                    "Static inventory seeded %s coverage unit(s)%s",
                    inventory_result.get("added", 0),
                    f" (diff-scoped: {len(diff_files)} file(s))" if diff_scope_active else "",
                )
                scanner_info = inventory_result.get("scanner") or {}
                if scanner_info.get("capped"):
                    logger.warning(
                        "Static inventory hit the file cap: scanned %s file(s) "
                        "at TALON_INVENTORY_MAX_FILES=%s; files beyond the cap are NOT in the "
                        "coverage manifest. Raise TALON_INVENTORY_MAX_FILES to cover more.",
                        scanner_info.get("files_scanned"),
                        scanner_info.get("max_files"),
                    )
            else:
                logger.warning(
                    "Static inventory seed failed: %s",
                    inventory_result.get("error", "unknown error"),
                )
        elif is_whitebox and not is_resume and diff_scope_active:
            logger.info(
                "Skipping static inventory seed: diff scope is active with no analyzable files"
            )

        # Diff scope: seed one-hop callers as advisory (kind=file, low) coverage — visible
        # and reviewable, but never gate-blocking.
        if is_whitebox and not is_resume and diff_scope_active:
            affected_files = _diff_scope_affected_files(scan_config)
            if affected_files:
                from talon.tools.coverage.tools import _add_units_impl

                advisory_units = [
                    {
                        "kind": "file",
                        "location": path,
                        "title": f"{path} — impacted by the diff (caller/context), advisory review",
                        "construct_type": "diff_affected",
                        "confidence": "low",
                    }
                    for path in affected_files
                ]
                affected_result = await asyncio.to_thread(
                    _add_units_impl, advisory_units, "diff_affected"
                )
                logger.info(
                    "Diff scope: seeded %s advisory caller unit(s) from %d impacted file(s)",
                    affected_result.get("added", 0),
                    len(affected_files),
                )

        root_session = open_agent_session(root_id, agents_db)
        sessions_to_close.append(root_session)
        await coordinator.attach_runtime(root_id, session=root_session)

        if is_resume:
            await child_spawner.respawn(parent_ctx=context, root_id=root_id)
            await _inject_recovery_frontier(
                coordinator=coordinator,
                root_id=root_id,
                settings=settings,
                is_whitebox=is_whitebox,
                scan_mode=scan_mode,
            )

        initial_input: Any = [] if is_resume else root_task

        # Resume + new ``--instruction``: SDK replay drives root from agents.db with
        # ``initial_input=[]``, so a new instruction would otherwise be silently ignored.
        # Inject it as a fresh user message in root's session; the next cycle replays it.
        resume_instruction = str(scan_config.get("resume_instruction") or "").strip()
        if is_resume and resume_instruction:
            await coordinator.send(
                root_id,
                {
                    "from": "user",
                    "type": "instruction",
                    "priority": "high",
                    "content": resume_instruction,
                },
            )
            logger.info(
                "Resume: injected new instruction into root SDK session (len=%d)",
                len(resume_instruction),
            )

        progress_task = asyncio.create_task(
            run_progress_heartbeat(
                coordinator,
                interval=settings.runtime.progress_interval_secs,
                start_monotonic=progress_start,
            )
        )

        result = await run_agent_loop(
            agent=root_agent,
            initial_input=initial_input,
            run_config=run_config,
            context=context,
            max_turns=max_turns,
            coordinator=coordinator,
            agent_id=root_id,
            interactive=interactive,
            session=root_session,
            # Never cold-park the root on resume: a restored "waiting" root parked without a
            # driving cycle deadlocks (the messages that would have woken it fired before the
            # snapshot). Drive it one cycle so it re-establishes the work frontier and wakes
            # respawned children; the park loop's liveness watchdog handles it thereafter.
            start_parked=False,
            event_sink=event_sink,
            hooks=hooks,
        )
        if not interactive and result is not None:
            final = getattr(result, "final_output", None)
            if not final_output_signals_scan_completed(final):
                logger.error(
                    "Scan ended without calling finish_scan. The agent "
                    "emitted a text-only turn instead of a lifecycle tool call, "
                    "so no executive report was written. Final output (first "
                    "300 chars): %r",
                    str(final)[:300],
                )
        return result  # noqa: TRY300
    except BudgetExceededError as exc:
        logger.info("Scan stopped: %s", exc)
        if root_id is not None:
            await coordinator.cancel_descendants(root_id)
            with contextlib.suppress(Exception):
                await coordinator.set_status(root_id, "stopped")
        return None
    except RateLimitError as exc:
        # scan_id stays in this message: it is the literal argument the user must type.
        logger.warning(
            "Scan stopped: persistent rate limit from the LLM provider (%s). "
            "Resume with 'talon --resume %s' once the limit clears.",
            exc,
            scan_id,
        )
        if root_id is not None:
            await coordinator.cancel_descendants(root_id)
            with contextlib.suppress(Exception):
                await coordinator.set_status(root_id, "stopped")
        return None
    except BaseException:
        logger.exception("Talon scan failed")
        if root_id is not None:
            await coordinator.cancel_descendants(root_id)
            with contextlib.suppress(Exception):
                await coordinator.set_status(root_id, "failed")
        raise
    finally:
        if progress_task is not None:
            progress_task.cancel()
            with contextlib.suppress(BaseException):
                await progress_task
        # Final tally so even a short or interrupted run ends with a progress line.
        with contextlib.suppress(Exception):
            await emit_progress_line(coordinator, start_monotonic=progress_start)
        for s in sessions_to_close:
            with contextlib.suppress(Exception):
                s.close()
        with contextlib.suppress(Exception):
            await coordinator._maybe_snapshot()
        if cleanup_on_exit:
            logger.info("Tearing down sandbox session")
            await session_manager.cleanup(scan_id)
        set_active_coordinator(None)
        logger.info("Talon scan done")
        teardown_logging()

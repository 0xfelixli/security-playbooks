"""Diff-only review: a fast, repo-context-free security pass over a unified diff.

Mirrors codejury's ``review diff`` / claude-code-security-review's CI mode: the diff
text goes straight to the model with no Read/Grep/Bash tools and no sandbox, trading
cross-file context (auth wrappers, call-site reachability — see
``talon/skills/custom/false_positive_traps.md``) for speed. This is the default for
``--scope-mode diff``; ``--deep-context`` opts back into the full agentic sandbox
review (``run_talon_scan``), which does have repo access.
"""

from __future__ import annotations

import json
import logging
import subprocess
from datetime import UTC, datetime
from pathlib import Path
from typing import TYPE_CHECKING, Any

from agents.model_settings import ModelSettings
from agents.models.interface import ModelTracing

from talon.config import load_settings
from talon.config.models import DEFAULT_MODEL_RETRY, TalonProvider, configure_sdk_model_defaults
from talon.core.model_text import extract_text
from talon.report.sarif import write_sarif
from talon.report.writer import write_vulnerabilities


if TYPE_CHECKING:
    from collections.abc import Awaitable, Callable

    # (system, user) -> response text. Carries no SDK/provider knowledge, so
    # review_diff_text is unit-testable with a fake and reusable across runtimes.
    LlmCall = Callable[[str, str], Awaitable[str]]


logger = logging.getLogger(__name__)

# A diff over this size is reviewed one file (or file-group) at a time, so a big PR
# does not overflow the model's context and silently truncate the reply.
_MAX_DIFF_CHARS = 60_000

_ALLOWED_SEVERITIES = ("critical", "high", "medium", "low")
_DEFAULT_MIN_CONFIDENCE = 0.7

DIFF_REVIEW_SYSTEM_PROMPT = """You are a senior security engineer doing a focused review \
of a unified diff.

You are NOT given the rest of the repository — only the diff text below. This is a
deliberate trade-off for speed: you cannot open other files, trace a call chain, or
confirm whether an auth check lives in a decorator/middleware you cannot see.

CRITICAL INSTRUCTIONS:
1. Report a finding whenever the diff text itself clearly shows a violation — a disabled
   security check, a known-dangerous sink, a control its sibling code has that this new
   code lacks — even if you cannot see how the result is consumed downstream (e.g. "who
   calls this function", "is this route wrapped by an auth decorator defined elsewhere").
   Not knowing the full downstream blast radius affects SEVERITY, not whether to report:
   grade it conservatively (e.g. MEDIUM instead of CRITICAL) and say in the description
   what you could not verify, but do not drop it. Only skip a finding when the diff text
   you CAN see does not clearly show a violation at all (e.g. you genuinely cannot tell
   whether a value is attacker-controlled).
2. Focus ONLY on vulnerabilities newly introduced or worsened by this diff, not
   pre-existing issues merely visible in the context lines.
3. Do not report: dependency/CVE issues, generic "add rate limiting" suggestions with
   no concrete exploit path, missing hardening/best-practice suggestions with no
   concrete exploit path, findings in test files, findings in documentation/markdown
   files, or client-side-only auth/validation gaps (the backend is assumed
   responsible for enforcing those). DO report a concrete brute-forceable check — a
   short numeric OTP/PIN or a small-keyspace token verified with no attempt limit or
   lockout — that is a real vulnerability, not a generic rate-limiting nitpick.

VULNERABILITY CATEGORIES:
- Injection: SQL/NoSQL/command/template/XXE/eval/code injection
- Auth: authentication bypass, missing/weak authorization, privilege escalation,
  session/JWT flaws, IDOR/BOLA/BFLA
- Crypto & secrets: hardcoded credentials, weak algorithms, broken randomness,
  certificate validation bypass
- Deserialization / RCE: unsafe pickle/YAML/deserialization, eval of untrusted input
- Data exposure: sensitive data logged, PII/secret leakage in responses
- Web: XSS (reflected/stored/DOM), CSRF, SSRF (only if host/protocol is attacker
  controlled, not just the path), open redirect (only if very high confidence)

SEVERITY SCALE (match the label to impact x exploitability):
- CRITICAL: defeats auth/funds/signing/custody with little or no precondition
- HIGH: same class of control defeated, but behind one precondition (one captured
  request, one held credential, a race)
- MEDIUM: real but bounded — unauthenticated read of low-sensitivity data, a defect
  needing heavy preconditions
- LOW: hardening / defense-in-depth, no concrete exploit path today

Respond with ONLY this JSON object, no markdown fences, no prose before or after:

{
  "findings": [
    {
      "file": "path/to/file.py",
      "line": 42,
      "severity": "high",
      "cwe": "CWE-89",
      "title": "SQL injection via unsanitized `user_id`",
      "description": "What the flaw is and why the diff introduces it",
      "exploit_scenario": "Concrete attacker steps and impact",
      "recommendation": "The specific fix",
      "confidence": 0.85
    }
  ]
}

confidence is 0.0-1.0: how sure you are that the diff text itself shows a real violation
— NOT how sure you are about the full downstream blast radius (that uncertainty belongs
in severity and in the description, per instruction 1, not in a lowered confidence).
Below 0.7 is too speculative about whether the violation is real at all — omit it. An
empty "findings" list is a perfectly good answer when the diff introduces nothing real.
"""


def get_diff_patch_text(repo_path: Path, merge_base: str) -> str:
    """Unified diff text for ``{merge_base}...HEAD`` — the same range diff-scope
    already computed the changed-file list for (see ``interface/utils.py``)."""
    result = subprocess.run(  # noqa: S603
        [  # noqa: S607
            "git",
            "-C",
            str(repo_path),
            "diff",
            "--find-renames",
            "--find-copies",
            f"{merge_base}...HEAD",
        ],
        capture_output=True,
        text=True,
        check=False,
    )
    if result.returncode != 0:
        raise ValueError(f"git diff failed for {repo_path}: {result.stderr.strip()}")
    return result.stdout


def split_diff_by_file(diff: str) -> list[str]:
    """Split a unified diff into one chunk per file at ``diff --git`` boundaries."""
    chunks: list[str] = []
    current: list[str] = []
    for line in diff.splitlines(keepends=True):
        if line.startswith("diff --git ") and current:
            chunks.append("".join(current))
            current = []
        current.append(line)
    if current:
        chunks.append("".join(current))
    return chunks or ([diff] if diff.strip() else [])


def chunk_diff(diff: str, max_chars: int = _MAX_DIFF_CHARS) -> list[str]:
    """Group per-file diffs into batches under ``max_chars`` so small diffs stay in
    one model call and large ones don't overflow context."""
    if len(diff) <= max_chars:
        return [diff] if diff.strip() else []

    chunks: list[str] = []
    current = ""
    for file_diff in split_diff_by_file(diff):
        if current and len(current) + len(file_diff) > max_chars:
            chunks.append(current)
            current = ""
        current += file_diff
    if current:
        chunks.append(current)
    return chunks


def parse_findings_response(content: str) -> list[dict[str, Any]]:
    """Parse the model's JSON findings array, tolerant of code fences.

    Raises ValueError when no JSON object is found at all (an actually broken
    response); a well-formed object with a missing/malformed ``findings`` key just
    yields an empty list.
    """
    text = content.strip()
    if text.startswith("```"):
        text = text.strip("`")
        if text.lower().startswith("json"):
            text = text[4:]
        text = text.strip()
    start = text.find("{")
    end = text.rfind("}")
    if start == -1 or end == -1 or end <= start:
        raise ValueError(f"No JSON object found in diff-review response: {content[:500]}")
    parsed = json.loads(text[start : end + 1])

    raw_findings = parsed.get("findings") if isinstance(parsed, dict) else None
    if not isinstance(raw_findings, list):
        return []

    cleaned: list[dict[str, Any]] = []
    for raw in raw_findings:
        if not isinstance(raw, dict):
            continue
        title = str(raw.get("title") or "").strip()
        if not title:
            continue
        severity = str(raw.get("severity") or "medium").strip().lower()
        if severity not in _ALLOWED_SEVERITIES:
            severity = "medium"
        try:
            confidence = float(raw.get("confidence", 0.7))
        except (TypeError, ValueError):
            confidence = 0.7

        code_locations: list[dict[str, Any]] = []
        file_path = str(raw.get("file") or "").strip()
        line_raw = raw.get("line")
        if file_path and isinstance(line_raw, int) and line_raw >= 1:
            code_locations.append({"file": file_path, "start_line": line_raw})

        cwe = str(raw.get("cwe") or "").strip() or None

        cleaned.append(
            {
                "title": title,
                "description": str(raw.get("description") or "").strip(),
                "severity": severity,
                "cwe": cwe,
                "poc_description": str(raw.get("exploit_scenario") or "").strip(),
                "remediation_steps": str(raw.get("recommendation") or "").strip(),
                "confidence": confidence,
                "code_locations": code_locations,
            }
        )
    return cleaned


async def review_diff_text(
    diff_text: str,
    *,
    llm_call: LlmCall,
    min_confidence: float = _DEFAULT_MIN_CONFIDENCE,
) -> list[dict[str, Any]]:
    """Provider-agnostic core: chunk the diff, call the model per chunk, merge findings.

    ``llm_call`` carries no provider/SDK knowledge, so this is unit-testable with a
    fake and reusable across runtimes (mirrors ``report.dedupe.judge_duplicate``).
    """
    findings: list[dict[str, Any]] = []
    for chunk in chunk_diff(diff_text):
        user_msg = f"Unified diff to review:\n\n```diff\n{chunk}\n```"
        response_text = await llm_call(DIFF_REVIEW_SYSTEM_PROMPT, user_msg)
        if not response_text:
            continue
        try:
            findings.extend(parse_findings_response(response_text))
        except ValueError:
            logger.warning("diff-review: unparseable model output for one chunk, skipping")
    return [f for f in findings if f["confidence"] >= min_confidence]


def _build_llm_call(model: Any) -> LlmCall:
    async def _llm_call(system: str, user: str) -> str:
        response = await model.get_response(
            system_instructions=system,
            input=user,
            model_settings=ModelSettings(retry=DEFAULT_MODEL_RETRY, include_usage=True),
            tools=[],
            output_schema=None,
            handoffs=[],
            tracing=ModelTracing.DISABLED,
            previous_response_id=None,
            conversation_id=None,
            prompt=None,
        )
        return extract_text(response)

    return _llm_call


def _write_report(run_dir: Path, findings: list[dict[str, Any]]) -> None:
    write_vulnerabilities(run_dir, findings, set())
    try:
        write_sarif(run_dir, findings)
    except Exception:
        logger.exception("diff-review: SARIF write failed, continuing without it")


async def run_diff_text_review(
    *,
    repo_scopes: list[dict[str, Any]],
    run_dir: Path,
    model_name: str,
) -> list[dict[str, Any]]:
    """SDK wiring: fetch the diff per repo, review it, write markdown/CSV/JSON/SARIF.

    ``repo_scopes`` is ``diff_scope.metadata["repos"]`` — each entry has
    ``source_path`` and ``merge_base`` (see ``RepoDiffScope.to_metadata``).
    """
    settings = load_settings()
    configure_sdk_model_defaults(settings)
    llm_call = _build_llm_call(TalonProvider().get_model(model_name))

    now = datetime.now(UTC).isoformat()
    all_findings: list[dict[str, Any]] = []
    for repo in repo_scopes:
        source_path = repo.get("source_path")
        merge_base = repo.get("merge_base")
        if not source_path or not merge_base:
            continue
        diff_text = get_diff_patch_text(Path(source_path), merge_base)
        if not diff_text.strip():
            continue

        subdir = repo.get("workspace_subdir")
        findings = await review_diff_text(diff_text, llm_call=llm_call)
        for finding in findings:
            for location in finding["code_locations"]:
                if subdir:
                    location["file"] = f"{subdir}/{location['file']}"
            finding["id"] = f"diff-{len(all_findings)}"
            finding["timestamp"] = now
            all_findings.append(finding)

    logger.info("diff-review: %d finding(s) across %d repo(s)", len(all_findings), len(repo_scopes))
    _write_report(run_dir, all_findings)
    return all_findings


async def run_diff_text_review_from_text(
    diff_text: str,
    *,
    run_dir: Path,
    model_name: str,
) -> list[dict[str, Any]]:
    """SDK wiring for ``--diff-file``: review a raw diff text directly.

    No git repo, no ``--target`` — the diff comes from a file or stdin (e.g.
    ``git diff HEAD~1 | talon --diff-file -``). Mirrors codejury's ``review diff
    --file``/stdin input modes.
    """
    settings = load_settings()
    configure_sdk_model_defaults(settings)
    llm_call = _build_llm_call(TalonProvider().get_model(model_name))

    now = datetime.now(UTC).isoformat()
    findings = await review_diff_text(diff_text, llm_call=llm_call)
    for i, finding in enumerate(findings):
        finding["id"] = f"diff-{i}"
        finding["timestamp"] = now

    logger.info("diff-review (--diff-file): %d finding(s)", len(findings))
    _write_report(run_dir, findings)
    return findings

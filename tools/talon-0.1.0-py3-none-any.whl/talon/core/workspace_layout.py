"""The single authority for talon's workspace path model (the "where").

Owns where source lives, where artifacts go, and how each sandbox backend maps those to
physical paths — pure path truth, no IO and no SDK. Materialization (the "how": CoW clone /
LocalDir copy / read-only bind / tmpfs overlay) stays in ``session_manager``. A
``WorkspaceLayout`` is built once per scan, carried in the run context, and is the sole
source of the path env vars injected for skills.

This concentrates the two backends' path difference (local = host path, docker =
in-container ``/workspace``) here — absorbed via a flat field + ``host_accessible`` — instead
of scattering hardcoded ``/workspace`` fallbacks across session_manager, inputs, tools, and
skills prose.
"""

from __future__ import annotations

import posixpath
from dataclasses import dataclass
from typing import TYPE_CHECKING, Literal

from talon.core.paths import run_dir_for


if TYPE_CHECKING:
    from pathlib import Path


# The in-container workspace root for the docker backend. Owned here so no tool, backend, or
# skill hardcodes "/workspace".
CONTAINER_WORKSPACE = "/workspace"

# Artifact dir name, sitting at the workspace root (outside any read-only --mount source
# subdir, which is why it is always writable).
ARTIFACT_DIRNAME = ".talon-source-aware"


@dataclass(frozen=True, slots=True)
class WorkspaceLayout:
    """Immutable path truth for one scan's sandbox, backend-agnostic to callers.

    The backend difference is absorbed via a flat field plus ``host_accessible`` — never
    exposed as a type the caller must match on. Paths are POSIX on both backends (host is
    macOS/Linux, container is Linux); ``host_accessible`` marks only whether Python may
    ``Path()`` the root directly.
    """

    backend: Literal["local", "docker"]
    workspace_root: str
    host_accessible: bool

    @property
    def artifact_dir(self) -> str:
        """Writable artifact dir (``$ART``) at the workspace root."""
        return posixpath.join(self.workspace_root, ARTIFACT_DIRNAME)

    def source_path(self, subdir: str) -> str:
        """Path to a target's source, under its assigned workspace subdir."""
        return posixpath.join(self.workspace_root, subdir)

    def env(self) -> dict[str, str]:
        """Path env vars injected into the sandbox — the sole source skills consume.

        Skills reference these instead of hardcoding paths in prose.
        """
        return {
            "TALON_WORKSPACE_ROOT": self.workspace_root,
            "TALON_ARTIFACT_DIR": self.artifact_dir,
        }


def for_local(scan_id: str, *, cwd: Path | None = None) -> WorkspaceLayout:
    """Layout for the host-local backend: workspace is a real host path (CoW clone target)."""
    return WorkspaceLayout(
        backend="local",
        workspace_root=str(run_dir_for(scan_id, cwd=cwd) / "workspace"),
        host_accessible=True,
    )


def for_docker() -> WorkspaceLayout:
    """Layout for the docker backend: workspace is the in-container ``/workspace`` path."""
    return WorkspaceLayout(
        backend="docker",
        workspace_root=CONTAINER_WORKSPACE,
        host_accessible=False,
    )

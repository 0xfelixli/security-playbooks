"""Shared lifecycle-tool termination protocol — single source of truth.

An agent's run loop ends when a lifecycle tool (``finish_scan`` for root, ``agent_finish``
for a subagent) reports success via a per-tool JSON key. This leaf module (no intra-talon
imports) holds the keys and parsers so every producer/consumer agrees.
"""

from __future__ import annotations

import json
from typing import Any


SCAN_COMPLETED_KEY = "scan_completed"
AGENT_COMPLETED_KEY = "agent_completed"

# Which output key each lifecycle tool sets to signal successful completion.
_COMPLETION_KEY_BY_TOOL: dict[str, str] = {
    "finish_scan": SCAN_COMPLETED_KEY,
    "agent_finish": AGENT_COMPLETED_KEY,
}


def completion_key_for_tool(tool_name: str) -> str | None:
    """Return the completion key a lifecycle tool sets, or ``None`` for other tools."""
    return _COMPLETION_KEY_BY_TOOL.get(tool_name)


def tool_output_signals_completion(tool_name: str, output: Any) -> bool:
    """Whether a lifecycle tool's JSON ``output`` reports successful completion.

    Consumed by the agent's ``tool_use_behavior`` to decide when to end the run loop.
    """
    key = _COMPLETION_KEY_BY_TOOL.get(tool_name)
    if key is None or not isinstance(output, str):
        return False
    try:
        parsed = json.loads(output)
    except (TypeError, ValueError):
        return False
    return bool(isinstance(parsed, dict) and parsed.get("success") and parsed.get(key))


def final_output_signals_scan_completed(final_output: Any) -> bool:
    """Whether a root run's ``final_output`` indicates ``finish_scan`` completed.

    Accepts either the tool's JSON string or an already-parsed dict — the runner's
    end-of-scan fallback check does not know which shape the SDK surfaced.
    """
    parsed: Any = final_output
    if isinstance(final_output, str):
        try:
            parsed = json.loads(final_output)
        except (TypeError, ValueError):
            return False
    return bool(isinstance(parsed, dict) and parsed.get(SCAN_COMPLETED_KEY))
